<?php $__env->startSection('title', 'Trang Chủ'); ?>
<?php $__env->startSection('sidebar'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="section" id="slider-wp">
        <div class="section-detail">
            <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
                <img src="<?php echo e(asset('uploads/'.$model->thumb)); ?>" alt="">
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="section" id="support-wp">
        <div class="section-detail">
            <ul class="list-item clearfix">
                <li>
                    <div class="thumb">
                        <img src="<?php echo e(asset('client/images/icon-1.png')); ?>">
                    </div>
                    <h3 class="title">Miễn phí vận chuyển</h3>
                    <p class="desc">Tới tận tay khách hàng</p>
                </li>
                <li>
                    <div class="thumb">
                        <img src="<?php echo e(asset('client/images/icon-2.png')); ?>">
                    </div>
                    <h3 class="title">Tư vấn 24/7</h3>
                    <p class="desc">1900.9999</p>
                </li>
                <li>
                    <div class="thumb">
                        <img src="<?php echo e(asset('client/images/icon-3.png')); ?>">
                    </div>
                    <h3 class="title">Tiết kiệm hơn</h3>
                    <p class="desc">Với nhiều ưu đãi cực lớn</p>
                </li>
                <li>
                    <div class="thumb">
                        <img src="<?php echo e(asset('client/images/icon-4.png')); ?>">
                    </div>
                    <h3 class="title">Thanh toán nhanh</h3>
                    <p class="desc">Hỗ trợ nhiều hình thức</p>
                </li>
                <li>
                    <div class="thumb">
                        <img src="<?php echo e(asset('client/images/icon-5.png')); ?>">
                    </div>
                    <h3 class="title">Đặt hàng online</h3>
                    <p class="desc">Thao tác đơn giản</p>
                </li>
            </ul>
        </div>
    </div>
    <div class="section" id="feature-product-wp">
        <div class="section-head">
            <h3 class="section-title">Sản phẩm nổi bật</h3>
        </div>
        <div class="section-detail">
            <ul class="list-item">
                <?php if($hotProducts->count() > 0): ?>
                    <?php $__currentLoopData = $hotProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('productDetail', ['productCatSlug' => Str::slug($model->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id])); ?>"
                                title="" class="thumb img-container">
                                <img src="<?php echo e(asset('uploads/' . $model->thumb)); ?>">
                            </a>
                            <a href="<?php echo e(route('productDetail', ['productCatSlug' => Str::slug($model->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id])); ?>"
                                title="" class="product-name"><?php echo e($model->name); ?></a>
                            <?php if($model->discount > 0): ?>
                                <div class="price">
                                    <span class="new"><?php echo e(number_format($model->discount, 0, ',', '.') . ' đ'); ?></span>
                                    <span class="old"><?php echo e(number_format($model->price, 0, ',', '.') . ' đ'); ?></span>
                                </div>
                            <?php else: ?>
                                <div class="price">
                                    <span class="new"><?php echo e(number_format($model->price, 0, ',', '.') . ' đ'); ?></span>
                                    
                                </div>
                            <?php endif; ?>
                            <?php if($model->status === '2'): ?>
                                <div class="price">
                                    <span class="text-danger" style="color:red">Hết Hàng</span>
                                </div>
                            <?php else: ?>
                                <div class="action clearfix">
                                    <button class="add-cart" data-id="<?php echo e($model->id); ?>" data-toggle="modal"
                                        data-target="#success_tic">Thêm Giỏ Hàng</button>
                                    <a href="<?php echo e(route('checkout', ['id' => [$model->id], 'buynow' => 'ok'])); ?>"
                                        title="Mua ngay" class="buy-now fl-right">Mua
                                        ngay</a>
                                </div>
                            <?php endif; ?>
                            <?php if($model->discount>0): ?>
                            <div class="discount-label">
                                <span>-<?php echo e(floor((($model->price-$model->discount)/$model->price)*100)); ?>%</span>
                                <span class="label-text">Giảm giá</span>
                            </div>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
        </div>
    </div>
    <div class="section" id="list-product-wp">
        <div class="section-head">
            <h3 class="section-title">Điện thoại</h3>
        </div>
        <div class="section-detail">
            <ul class="list-item clearfix">
                <?php if($phones->count() > 0): ?>
                    <?php $__currentLoopData = $phones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('productDetail', ['productCatSlug' => Str::slug($model->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id])); ?>"
                                title="" class="thumb img-container">
                                <img src="<?php echo e(asset('uploads/' . $model->thumb)); ?>">
                            </a>
                            <a href="<?php echo e(route('productDetail', ['productCatSlug' => Str::slug($model->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id])); ?>"
                                title="" class="product-name"><?php echo e($model->name); ?></a>
                            <?php if($model->discount > 0): ?>
                                <div class="price">
                                    <span class="new"><?php echo e(number_format($model->discount, 0, ',', '.') . ' đ'); ?></span>
                                    <span class="old"><?php echo e(number_format($model->price, 0, ',', '.') . ' đ'); ?></span>
                                </div>
                            <?php else: ?>
                                <div class="price">
                                    <span class="new"><?php echo e(number_format($model->price, 0, ',', '.') . ' đ'); ?></span>
                                    
                                </div>
                            <?php endif; ?>
                            <?php if($model->status === '2'): ?>
                                <div class="price">
                                    <span class="text-danger" style="color:red">Hết Hàng</span>
                                </div>
                            <?php else: ?>
                                <div class="action clearfix">
                                    <button class="add-cart" data-id="<?php echo e($model->id); ?>" data-toggle="modal"
                                        data-target="#success_tic">Thêm Giỏ Hàng</button>
                                    <a href="<?php echo e(route('checkout', ['id' => [$model->id], 'buynow' => 'ok'])); ?>"
                                        title="Mua ngay" class="buy-now fl-right">Mua
                                        ngay</a>
                                </div>
                            <?php endif; ?>

                            <?php if($model->discount>0): ?>
                            <div class="discount-label">
                                <span>-<?php echo e(floor((($model->price-$model->discount)/$model->price)*100)); ?>%</span>
                                <span class="label-text">Giảm giá</span>
                            </div>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
        </div>
        <a href="<?php echo e(route('productByCat.show', ['slug' => 'dien-thoai', 'id' => 1])); ?>" class="all-products">Xem tất cả
            sản phẩm</a>
    </div>

    <div class="section" id="list-product-wp">
        <div class="section-head">
            <h3 class="section-title">Laptop</h3>
        </div>
        <div class="section-detail">
            <ul class="list-item clearfix">
                <?php if($laps->count() > 0): ?>
                    <?php $__currentLoopData = $laps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('productDetail', ['productCatSlug' => Str::slug($model->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id])); ?>"
                                title="" class="thumb img-container">
                                <img src="<?php echo e(asset('uploads/' . $model->thumb)); ?>">
                            </a>
                            <a href="<?php echo e(route('productDetail', ['productCatSlug' => Str::slug($model->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id])); ?>"
                                title="" class="product-name"><?php echo e($model->name); ?></a>
                            <?php if($model->discount > 0): ?>
                                <div class="price">
                                    <span class="new"><?php echo e(number_format($model->discount, 0, ',', '.') . ' đ'); ?></span>
                                    <span class="old"><?php echo e(number_format($model->price, 0, ',', '.') . ' đ'); ?></span>
                                </div>
                            <?php else: ?>
                                <div class="price">
                                    <span class="new"><?php echo e(number_format($model->price, 0, ',', '.') . ' đ'); ?></span>
                                    
                                </div>
                            <?php endif; ?>
                            <?php if($model->status === '2'): ?>
                                <div class="price">
                                    <span class="text-danger" style="color:red">Hết Hàng</span>
                                </div>
                            <?php else: ?>
                                <div class="action clearfix">
                                    <button class="add-cart" data-id="<?php echo e($model->id); ?>" data-toggle="modal"
                                        data-target="#success_tic">Thêm Giỏ Hàng</button>
                                    <a href="<?php echo e(route('checkout', ['id' => [$model->id], 'buynow' => 'ok'])); ?>"
                                        title="Mua ngay" class="buy-now fl-right">Mua
                                        ngay</a>
                                </div>
                            <?php endif; ?>
                            <?php if($model->discount>0): ?>
                            <div class="discount-label">
                                <span>-<?php echo e(floor((($model->price-$model->discount)/$model->price)*100)); ?>%</span>
                                <span class="label-text">Giảm giá</span>
                            </div>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
        </div>
        <a href="<?php echo e(route('productByCat.show', ['slug' => 'laptop', 'id' => 2])); ?>" class="all-products">Xem tất cả sản
            phẩm</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        // $(document).ready(function(){
        //     $("button.add-cart").click(function(){
        //         let id = $(this).attr('data-id');
        //         href = "<?php echo e(route('checkout')); ?>?id="+id+"buynow=ok";
        //         $("a#modal-buynow").attr('href',href);
        //     })
        // })
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Xop-pi.com/resources/views/client/home.blade.php ENDPATH**/ ?>