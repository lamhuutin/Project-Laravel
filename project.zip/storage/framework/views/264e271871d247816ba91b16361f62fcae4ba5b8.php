<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-5">
        <div class="row">
            <div class="col">
                <div class="card text-white bg-primary mb-3" style="max-width: 18rem;">
                    <div class="card-header">ĐƠN HÀNG THÀNH CÔNG</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($count[0]); ?></h5>
                        <p class="card-text text-uppercase">Đơn hàng thành công</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card text-white bg-danger mb-3" style="max-width: 18rem;">
                    <div class="card-header">ĐANG XỬ LÝ</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($count[1]); ?></h5>
                        <p class="card-text text-uppercase">đang vận chuyển</p>
                    </div>
                </div>
            </div>

            <div class="col">
                <div class="card text-white bg-success mb-3" style="max-width: 18rem;">
                    <div class="card-header">DOANH SỐ</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e(number_format($count[2], 0, ',', '.') . ' Đ'); ?></h5>
                        <p class="card-text text-uppercase">Doanh số hệ thống</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card text-white bg-dark mb-3" style="max-width: 18rem;">
                    <div class="card-header">ĐƠN HÀNG HỦY</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($count[3]); ?></h5>
                        <p class="card-text text-uppercase">Số đơn đã hủy</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- end analytic  -->
        <div class="card">
            <div class="card-header font-weight-bold">
                ĐƠN HÀNG MỚI
            </div>

            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Mã Đơn</th>
                            <th scope="col">Khách hàng</th>
                            
                            <th scope="col">Số lượng</th>
                            <th scope="col">Giá trị</th>
                            <th scope="col">Trạng thái</th>
                            <th scope="col">Thời gian</th>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin.order.edit', 'admin.order.destroy'])): ?>
                                <th scope="col">Tác vụ</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($data->count() > 0): ?>
                            <?php
                                $t = 1;
                            ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($t++); ?></th>
                                    <td><?php echo e($model->code); ?></td>
                                    <td>
                                        <?php echo e($model->name); ?> <br>
                                        <?php echo e($model->phone); ?>

                                    </td>
                                    
                                    <td><?php echo e($model->total_product); ?></td>
                                    <td><?php echo e(number_format($model->total_price, 0, ',', '.') . ' đ'); ?></td>
                                    <td><span
                                            class="badge badge-<?php
$color = ['đã xác nhận'=>'info','đang vận chuyển'=>'warning','hoàn thành'=>'success','đã huỷ'=>'danger'];
                                    echo $color[$model->status]; ?> text-capitalize"><?php echo e($model->status); ?></span>
                                    </td>
                                    <td><?php echo e($model->created_at); ?></td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin.order.edit', 'admin.order.destroy'])): ?>
                                        <td>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.order.edit')): ?>
                                                <a href="<?php echo e(route('admin.order.edit', ['id' => $model->id])); ?>"
                                                    class="btn btn-success btn-sm rounded-0 text-white" type="button"
                                                    data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                        class="fa fa-edit"></i></a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.order.destroy')): ?>
                                                <a href="<?php echo e(route('admin.order.destroy', ['id' => $model->id])); ?>"
                                                    class="btn btn-danger btn-sm rounded-0 text-white" type="button"
                                                    data-toggle="tooltip" data-placement="top" title="Delete"><i
                                                        class="fa fa-trash"></i></a>
                                            <?php endif; ?>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <?php endif; ?>
                    </tbody>
                </table>
                <nav aria-label="Page navigation example">
                    <?php echo e($data->links()); ?>

                </nav>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Xop-pi.com/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>