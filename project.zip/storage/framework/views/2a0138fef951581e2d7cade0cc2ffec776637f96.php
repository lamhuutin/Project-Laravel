<?php $__env->startSection('title', 'Thêm danh mục sản phẩm'); ?>
<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <?php if(session('status')): ?>
            <div class="alert alert-success text-capitalize font-italic">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('fail')): ?>
            <div class="alert alert-danger text-capitalize font-italic">
                <?php echo e(session('fail')); ?>

            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-4">
                <div class="card">
                    <div class="card-header font-weight-bold">
                        Danh mục sản phẩm
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.productCat.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="name">Tên danh mục sản phẩm</label>
                                <input class="form-control" type="text" name="name" id="name">
                            </div>
                            <div class="form-group">
                                <label for="">Chọn danh mục cha</label>
                                <select class="form-control" name="parent_id" id="">
                                    <option value="0">Đặt làm danh mục cha</option>
                                    <?php if(isset($data) && count($data) > 0): ?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($model->id); ?>">
                                                <?php echo e(str_repeat('-', $model->level) . ' ' . $model->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Thêm mới</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-8">
                <div class="card">
                    <div class="card-header font-weight-bold">
                        Danh sách
                    </div>
                    <div class="card-body" style="height:40rem; overflow:auto">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Tên Danh Mục</th>
                                    <th scope="col">Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(isset($data) && count($data) > 0): ?>
                                    <?php
                                        $t = 1;
                                    ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($t++); ?></th>
                                            <td><?php echo e(str_repeat('-', $model->level) . ' ' . $model->name); ?></td>
                                            <td class="d-flex"><a
                                                    href="<?php echo e(route('admin.productCat.edit', ['productCat' => $model->id])); ?>"
                                                    class="btn btn-success btn-sm rounded-0 mr-2" type="button"
                                                    data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                        class="fa fa-edit"></i></a>
                                                <form
                                                    action="<?php echo e(route('admin.productCat.destroy', ['productCat' => $model->id])); ?>"
                                                    method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button class="btn btn-danger btn-sm rounded-0" type="submit"
                                                    data-toggle="tooltip" data-placement="top" title="Delete"><i
                                                        class="fa fa-trash"></i></button>
                                                </form>
                                               
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <td colspan="3" class="text-danger text-capitalize font-italic">Không có danh mục sản
                                        phẩm</td>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Xop-pi.com/resources/views/admin/productCat/create.blade.php ENDPATH**/ ?>