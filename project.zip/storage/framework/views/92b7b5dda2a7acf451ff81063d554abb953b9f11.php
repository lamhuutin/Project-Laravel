<!DOCTYPE html>
<html>

<head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?php echo e(asset('client/css/bootstrap/bootstrap-theme.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('client/css/bootstrap/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('client/reset.css')); ?> " rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('client/css/carousel/owl.carousel.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('client/css/carousel/owl.theme.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('client/css/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('client/style.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('client/responsive.css')); ?>" rel="stylesheet" type="text/css" />

    <script src="<?php echo e(asset('client/js/jquery-2.2.4.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('client/js/elevatezoom-master/jquery.elevatezoom.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('client/js/bootstrap/bootstrap.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('client/js/carousel/owl.carousel.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('client/js/main.js')); ?>" type="text/javascript"></script>
    
</head>

<body>
    <div id="site">
        <div id="container">
            <div id="header-wp">
                <div id="head-top" class="clearfix">
                    <div class="wp-inner">
                        <a href="" title="" id="payment-link" class="fl-left">Hình thức thanh toán</a>
                        <div id="main-menu-wp" class="fl-right">
                            <ul id="main-menu" class="clearfix">
                                <li>
                                    <a href="<?php echo e(route('home.page')); ?>" title="">Trang chủ</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('showListPost')); ?>" title="">Blog</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('showPage', ['pageSlug' => 'trang-gioi-thieu', 'id' => 3])); ?>"
                                        title="">Giới thiệu</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('showPage', ['pageSlug' => 'trang-lien-he', 'id' => 4])); ?>"
                                        title="">Liên hệ</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div id="head-body" class="clearfix">
                    <div class="wp-inner">
                        <a href="<?php echo e(route('home.page')); ?>" title="" id="logo" class="fl-left"
                            style="font-size: 2.5rem;line-height: 3.5rem">Xop-Pi</a>
                        <div id="search-wp" class="fl-left">
                            <form id="form-search" method="" action="<?php echo e(route('search')); ?>">
                                <input type="text" name="keyword" id="s"
                                    data-route="<?php echo e(route('searchAjax')); ?>"
                                    placeholder="Nhập từ khóa tìm kiếm tại đây!">
                                <button type="submit" id="sm-s">Tìm kiếm</button>
                                <div id="search-ajax">

                                </div>
                            </form>
                        </div>
                        <div id="action-wp" class="fl-right">
                            <div id="advisory-wp" class="fl-left">
                                <span class="title">Tư vấn</span>
                                <span class="phone">0987.654.321</span>
                            </div>
                            <div id="btn-respon" class="fl-right"><i class="fa fa-bars" aria-hidden="true"></i>
                            </div>
                            <a href="<?php echo e(route('cart')); ?>" title="giỏ hàng" id="cart-respon-wp" class="fl-right">
                                <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                <span id="num">2</span>
                            </a>
                            <div id="cart-wp" class="fl-right">
                                <div id="btn-cart">
                                    <a href="<?php echo e(route('cart')); ?>" style="color:white"><i class="fa fa-shopping-cart"
                                            aria-hidden="true"></i></a>
                                    <span id="num"><?php echo e(Cart::count() ? Cart::count() : ''); ?></span>
                                </div>
                                <div id="dropdown">
                                    <p class="desc" id="total_qty">Có <span><?php echo e(Cart::count() ? Cart::count() : 0); ?>

                                            sản
                                            phẩm</span> trong giỏ hàng</p>
                                    <ul class="list-cart">
                                        <?php if(Cart::count() > 0): ?>
                                            <?php
                                                $t = 0;
                                            ?>
                                            <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $t++;
                                                ?>
                                                <?php if($t <= 4): ?>
                                                    <li class="clearfix">
                                                        <a href="<?php echo e(route('productDetail', ['productCatSlug' => Str::slug($model->options->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id])); ?>"
                                                            title="" class="thumb fl-left">
                                                            <img src="<?php echo e(asset('uploads/' . $model->options->thumb)); ?>"
                                                                alt="">
                                                        </a>
                                                        <div class="info fl-right">
                                                            <a href="" title=""
                                                                class="product-name"><?php echo e($model->name); ?></a>
                                                            <?php if($model->options->discount > 0): ?>
                                                                <div class="price">
                                                                    <span class="new"
                                                                        style="color:#0984e3"><?php echo e(number_format($model->options->discount, 0, ',', '.') . ' đ'); ?></span><br>
                                                                    <span class="old"
                                                                        style="color:#999; text-decoration:line-through"><?php echo e(number_format($model->options->price, 0, ',', '.') . ' đ'); ?></span>
                                                                </div>
                                                            <?php else: ?>
                                                                <div class="price">
                                                                    <span
                                                                        class="new"><?php echo e(number_format($model->options->price, 0, ',', '.') . ' đ'); ?></span>
                                                                </div>
                                                            <?php endif; ?>
                                                            <p class="qty">Số lượng:
                                                                <span
                                                                    id="cart_qty_<?php echo e($model->id); ?>"><?php echo e($model->qty); ?></span>
                                                            </p>
                                                        </div>
                                                    </li>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($t > 4): ?>
                                                <a href="<?php echo e(route('cart')); ?>">Xem tất cả sản phẩm...</a>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>
                                    </ul>
                                    <div class="total-price clearfix">
                                        <p class="title fl-left">Tổng:</p>
                                        <p class="price fl-right" id="total_price"><?php echo e(Cart::total() . ' đ'); ?></p>
                                    </div>
                                    <div class="action-cart clearfix">
                                        <a href="<?php echo e(route('cart')); ?>" title="Giỏ hàng" class="view-cart fl-left">Giỏ
                                            hàng</a>
                                        <?php
                                            $id = [];
                                            foreach(Cart::content() as $model){
                                                $id[]=$model->id;
                                            }
                                        ?>
                                        <a href="<?php echo e(route('checkout',['id'=>$id])); ?>" title="Thanh toán"
                                            class="checkout fl-right">Thanh
                                            toán</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="main-content-wp" class="home-page clearfix">
                <div class="wp-inner">
                    <?php echo $__env->yieldContent('breadcrumb'); ?>
                    <div class="main-content fl-right">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                    <div class="sidebar fl-left">
                        <div class="section" id="category-product-wp">
                            <div class="section-head">
                                <h3 class="section-title">Danh mục sản phẩm</h3>
                            </div>
                            <div class="secion-detail">
                                <?php echo $menu; ?>

                            </div>
                        </div>
                        <div class="section" id="selling-wp">
                            <div class="section-head">
                                <h3 class="section-title">Sản phẩm bán chạy</h3>
                            </div>
                            <div class="section-detail">
                                <ul class="list-item">
                                    <?php if($hotProducts->count() > 0): ?>
                                        <?php $__currentLoopData = $hotProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="clearfix">
                                                <a href="<?php echo e(route('productDetail', ['productCatSlug' => Str::slug($model->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id])); ?>"
                                                    title="" class="thumb fl-left">
                                                    <img src="<?php echo e(asset('uploads/' . $model->thumb)); ?>"
                                                        alt="">
                                                </a>
                                                <div class="info fl-right">
                                                    <a href="<?php echo e(route('productDetail', ['productCatSlug' => Str::slug($model->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id])); ?>"
                                                        title="" class="product-name"><?php echo e($model->name); ?></a>
                                                    <?php if($model->discount > 0): ?>
                                                        <div class="price">
                                                            <span
                                                                class="new"><?php echo e(number_format($model->discount, 0, ',', '.') . ' đ'); ?></span><br>
                                                            <span
                                                                class="old"><?php echo e(number_format($model->price, 0, ',', '.') . ' đ'); ?></span>
                                                        </div>
                                                    <?php else: ?>
                                                        <div class="price">
                                                            <span
                                                                class="new"><?php echo e(number_format($model->price, 0, ',', '.') . ' đ'); ?></span>
                                                            
                                                        </div>
                                                    <?php endif; ?>
                                                    <a href="<?php echo e(route('checkout', ['id' => [$model->id], 'buynow' => 'ok'])); ?>"
                                                        title="Mua ngay" class="buy-now">Mua
                                                        ngay</a>
                                                </div>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="success_tic" class="modal modal-dialog-centered fade" role="dialog">
                <div class="modal-dialog">
                    <!-- Modal content-->
                    <div class="modal-content">
                        <a class="close" href="#" data-dismiss="modal">&times;</a>
                        <div class="page-body">
                            <div class="head mb-2">
                                <h2 style="margin-top:5px;">Đã thêm sản phẩm vào giỏ hàng</h2>
                            </div>
                            <h1 style="text-align:center;">
                                <div class="checkmark-circle">
                                    <div class="background"></div>
                                    <div class="checkmark draw"></div>
                                </div>
                                <h1>
                                    <div style="display: flex; justify-content:space-around; margin-top:40px">
                                        <a href="<?php echo e(route('cart')); ?>">Xem Giỏ hàng</a> <a id="modal-buynow"
                                            href="">Thanh Toán Ngay</a>
                                    </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="footer-wp">
                <div id="foot-body">
                    <div class="wp-inner clearfix">
                        <div class="block" id="info-company">
                            <h3 class="title">Xop-Pi</h3>
                            <p class="desc">Xop-Pi luôn cung cấp luôn là sản phẩm chính hãng có thông tin rõ ràng,
                                chính sách ưu đãi cực lớn cho khách hàng có thẻ thành viên.</p>
                            <div id="payment">
                                <div class="thumb">
                                    <img src="<?php echo e(asset('client/images/img-foot.png')); ?>" alt="">
                                </div>
                            </div>
                        </div>
                        <div class="block menu-ft" id="info-shop">
                            <h3 class="title">Thông tin cửa hàng</h3>
                            <ul class="list-item">
                                <li>
                                    <p>Đ.3/2 - Xuân Khánh - Ninh Kiều - Cần Thơ</p>
                                </li>
                                <li>
                                    <p>123.456.789 - 987.654.321</p>
                                </li>
                                <li>
                                    <p>XopPi@gmail.com</p>
                                </li>
                            </ul>
                        </div>
                        <div class="block menu-ft policy" id="info-shop">
                            <h3 class="title">Chính sách mua hàng</h3>
                            <ul class="list-item">
                                <li>
                                    <a href="" title="">Quy định - chính sách</a>
                                </li>
                                <li>
                                    <a href="" title="">Chính sách bảo hành - đổi trả</a>
                                </li>
                                <li>
                                    <a href="" title="">Chính sách hội viện</a>
                                </li>
                                <li>
                                    <a href="" title="">Giao hàng - lắp đặt</a>
                                </li>
                            </ul>
                        </div>
                        <div class="block" id="newfeed">
                            <h3 class="title">Bảng tin</h3>
                            <p class="desc">Đăng ký với chung tôi để nhận được thông tin ưu đãi sớm nhất</p>
                            <div id="form-reg">
                                <form method="POST" action="">
                                    <input type="email" name="email" id="email"
                                        placeholder="Nhập email tại đây">
                                    <button type="submit" id="sm-reg">Đăng ký</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="foot-bot">
                    <div class="wp-inner">
                        <p id="copyright">© Bản quyền thuộc về Xop-Pi</p>
                    </div>
                </div>
            </div>
        </div>

        <div id="menu-respon">
            <a href="?page=home" title="" class="logo">Xop-Pi</a>
            <div id="menu-respon-wp">
                <?php echo $menu; ?>

                
            </div>
        </div>
        <div id="btn-top"><img src="<?php echo e(asset('client/images/icon-to-top.png')); ?>" alt="" /></div>
        <div id="fb-root"></div>
        <script>
            (function(d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id))
                    return;
                js = d.createElement(s);
                js.id = id;
                js.src = "//connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v2.8&appId=849340975164592";
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));
            //xử lý tìm kiếm bằng ajax
            $(document).ready(function() {
                $("div#menu-respon-wp > ul").attr('id', 'main-menu-respon');
                //thêm sản phẩm bằng jax
                $('button.add-cart').click(function() {
                    let product_id = $(this).attr('data-id');
                    let product_qty = $(this).attr('data-qty');
                    product_qty = product_qty ? product_qty : 1;
                    $.ajax({
                        url: "<?php echo e(route('addCart')); ?>?id=" + product_id + "&qty=" + product_qty,
                        method: "get",
                        dataType: "json",
                        success: function(data) {
                            $('ul.list-cart').html(data.list_cart);
                            $('p#total_qty').html(
                                `<span>Có ${data.total_qty} sản phẩm trong giỏ hàng</span>`);
                            $('p#total_price').text(data.total_price);
                            $('span#num').text(data.total_qty);
                        },
                        error: function(xhr, ajaxOptions, thrownError) {
                            alert(xhr.status);
                            alert(thrownError);
                        }
                    })
                })
                $("button.add-cart").click(function() {
                    let id = $(this).attr('data-id');
                    href = "<?php echo e(route('checkout')); ?>?id%5B0%5D=" + id;
                    $("a#modal-buynow").attr('href', href);
                })
            })
        </script>
        <script src="<?php echo e(asset('client/js/search.js')); ?>"></script>
        <?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Xop-pi.com/resources/views/layouts/client.blade.php ENDPATH**/ ?>