<?php $__env->startSection('title', 'Chi Tiết Sản Phẩm'); ?>
<?php $__env->startSection('sidebar'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="section" id="detail-product-wp">
        <div class="section-detail clearfix">
            <div class="thumb-wp fl-left">
                <a href="" title="" id="main-thumb" style="">
                    <img id="zoom" style="max-width:350px; min-height:350px; padding:10px 5px"
                        src="<?php echo e(asset('uploads/' . $product->thumb)); ?>"
                        data-zoom-image="<?php echo e(asset('uploads/' . $product->thumb)); ?>" />
                </a>
                <div id="list-thumb">
                    <?php $__currentLoopData = $product->images_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="" data-image="<?php echo e(asset('uploads/' . $item)); ?>"
                            data-zoom-image="<?php echo e(asset('uploads/' . $item)); ?>">
                            <img id="zoom" src="<?php echo e(asset('uploads/' . $item)); ?>" />
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="thumb-respon-wp fl-left">
                <img src="<?php echo e(asset('uploads/' . $product->thumb)); ?>" alt="">
            </div>
            <div class="info fl-right">
                <h3 class="product-name"><?php echo e($product->name); ?></h3>
                <div class="desc">
                    <?php echo $product->desc; ?>

                </div>
                <div class="num-product">
                    <span class="title">Sản phẩm: </span>
                    <?php if($product->status === '2'): ?>
                        <span class="status" style="color: red">hết hàng</span>
                    <?php else: ?>
                        <span class="status">Còn hàng</span>
                    <?php endif; ?>
                </div>
                <?php if($product->discount > 0): ?>
                    <p class="price" style="font-size:20px"><?php echo e(number_format($product->discount, 0, ',', '.') . ' đ'); ?>

                        <span class="text-muted"
                            style="text-decoration:line-through; color:#999"><?php echo e(number_format($product->price, 0, ',', '.') . ' đ'); ?></span>
                    </p>
                <?php else: ?>
                    <p class="price" style="font-size:15px"><?php echo e(number_format($product->price, 0, ',', '.') . ' đ'); ?></p>
                <?php endif; ?>
                <?php if($product->status != 2): ?>
                    <div id="num-order-wp">
                        <a title="" id="minus"><i class="fa fa-minus"></i></a>
                        <input type="text" name="num-order" value="1" id="num-order">
                        <a title="" id="plus"><i class="fa fa-plus"></i></a>
                    </div>
                    <button class="add-cart" id="add-cart" data-id="<?php echo e($product->id); ?>" data-qty="1"
                        data-toggle="modal" data-target="#success_tic">Thêm Giỏ Hàng</button>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="section" id="post-product-wp">
        <div class="section-head">
            <h3 class="section-title">Mô tả sản phẩm</h3>
        </div>
        <div class="section-detail product-content">
            <?php echo $product->content; ?>

        </div>
    </div>
    <div class="section" id="same-category-wp">
        <div class="section-head">
            <h3 class="section-title text-uppercase">sản phẩm cùng danh mục</h3>
        </div>
        <div class="section-detail">
            <ul class="list-item">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="same-category" style="height: 400px">
                        <a href="<?php echo e(route('productDetail', ['productCatSlug' => Str::slug($model->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id])); ?>"
                            title="" class="thumb img-container">
                            <img src="<?php echo e(asset('uploads/' . $model->thumb)); ?>">
                        </a>
                        <a href="<?php echo e(route('productDetail', ['productCatSlug' => Str::slug($model->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id])); ?>"
                            title="" class="product-name"><?php echo e($model->name); ?></a>
                        <?php if($model->discount > 0): ?>
                            <div class="price">
                                <span class="new"><?php echo e(number_format($model->discount, 0, ',', '.') . ' đ'); ?></span>
                                <span class="old"><?php echo e(number_format($model->price, 0, ',', '.') . ' đ'); ?></span>
                            </div>
                        <?php else: ?>
                            <div class="price">
                                <span class="new"><?php echo e(number_format($model->price, 0, ',', '.') . ' đ'); ?></span>
                            </div>
                        <?php endif; ?>
                        <?php if($model->status === '2'): ?>
                            <div class="price">
                                <span class="text-danger" style="color:red">Hết Hàng</span>
                            </div>
                        <?php else: ?>
                            <div class="action clearfix">
                                <a href="?page=cart" title="Thêm giỏ hàng" class="add-cart fl-left">Thêm
                                    giỏ hàng</a>
                                <a href="?page=checkout" title="Mua ngay" class="buy-now fl-right">Mua
                                    ngay</a>
                            </div>
                        <?php endif; ?>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Xop-pi.com/resources/views/client/product/detail.blade.php ENDPATH**/ ?>