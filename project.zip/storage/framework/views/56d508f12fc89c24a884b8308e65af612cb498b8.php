<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Classic Login Form Example</title>
  <link href="https://fonts.googleapis.com/css?family=Assistant:400,700" rel="stylesheet"><link rel="stylesheet" href="<?php echo e(asset('asset_admin/css/login.css')); ?>">

</head>
<body>
<!-- partial:index.partial.html -->
<?php echo $__env->yieldContent('content'); ?>

<footer>
  
</footer>
<!-- partial -->
  

</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Xop-pi.com/resources/views/layouts/appLogin.blade.php ENDPATH**/ ?>