<?php $__env->startSection('title', 'Tạo sản phẩm'); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('asset_admin/js/product.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <?php if(session('status')): ?>
            <div class="alert alert-success text-capitalize text-italic">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header font-weight-bold">
                Thêm sản phẩm
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.product.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label for="name">Tên sản phẩm</label>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-capitalize text-danger font-ilatic"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input class="form-control" type="text" value="<?php echo e(old('name')); ?>" name="name" id="name">
                            </div>
                            <div class="form-group">
                                <label for="price">Giá <span class="text-muted font-italic">(số ghi liền không để ký tự
                                        '.' hoặc ',' ngăn cách vd: 100000)</span></label>
                                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-capitalize text-danger font-ilatic"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input class="form-control" value="<?php echo e(old('price')); ?>" type="text" name="price" id="price">
                            </div>
                            <div class="form-group">
                                <label for="discount">Giá khuyến mãi <span class="text-muted font-italic">(Bắt buộc nhỏ hơn
                                        giá, có thể để trống)</span></label>
                                <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-capitalize text-danger font-ilatic"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input class="form-control" value="<?php echo e(old('discount')); ?>" type="text" name="discount" id="discount">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="desc">Mô tả sản phẩm <span class="text-muted font-italic">(có thể bổ sung
                                        sau, thông số như GAM, Chip, Hệ Điều Hành,... sau mỗi thông số nên xuống hàng)</span></label>
                                <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-capitalize text-danger font-ilatic"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <textarea name="desc" class="form-control content" id="desc" cols="30" style="resize:none; overflow:auto; height:300px"
                                    rows="8"><?php echo e(old('desc')); ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="file_thumb">Ảnh đại diện sản phẩm</label>
                        <?php $__errorArgs = ['file_thumb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-capitalize text-danger font-ilatic"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <input type="file" name="file_thumb" id="file_thumb" class="form-control">
                    </div>
                    <div class="box_thumb">

                    </div>
                    <div class="form-group">
                        <label for="images">Danh sách ảnh chi tiết sản phẩm <span class="text-muted font-italic">(có thể
                                tải nhiều
                                ảnh)</span></label>
                        <?php $__errorArgs = ['images.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-capitalize text-danger font-ilatic"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <input type="file" name="images[]" multiple id="images" class="form-control">
                    </div>
                    <div class="box_images d-flex flex-wrap">

                    </div>
                    <div class="form-group">
                        <label for="content">Chi tiết sản phẩm <span class="text-muted font-italic">(có thể bổ sung
                                sau)</span></label>
                        <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-capitalize text-danger font-ilatic"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <textarea name="content" style="height: 800px" class="form-control content" id="intro" cols="30" rows="5"><?php echo e(old('content')); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="">Danh mục</label>
                        <select class="form-control" name="productCat_id" id="">
                            <option value="0">-- Chọn danh mục --</option>
                            <?php if(isset($data) && count($data) > 0): ?>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($model->id); ?>">
                                        <?php echo e(str_repeat('-', $model->level) . ' ' . $model->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Trạng thái</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="status" id="exampleRadios1" value="0"
                                checked>
                            <label class="form-check-label" for="exampleRadios1">
                                Chờ duyệt
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="status" id="exampleRadios2"
                                value="1">
                            <label class="form-check-label" for="exampleRadios2">
                                Công khai (còn hàng)
                            </label>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Thêm mới</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Xop-pi.com/resources/views/admin/product/create.blade.php ENDPATH**/ ?>