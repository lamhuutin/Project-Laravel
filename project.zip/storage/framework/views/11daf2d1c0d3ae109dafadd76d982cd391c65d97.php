<?php $__env->startSection('title', 'Danh sách sản phẩm'); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('asset_admin/js/index.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <?php $__errorArgs = ['action'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger text-capitalize font-italic">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php $__errorArgs = ['id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger text-capitalize font-italic">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php if(session('status')): ?>
            <div class="alert alert-success text-capitalize font-italic">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
                <h5 class="m-0 ">Danh sách sản phẩm</h5>
                <div class="form-search form-inline">
                    <form action="#">
                        <input type="text" name="keyword" class="form-control form-search" placeholder="Tìm kiếm">
                        <input type="submit" name="btn-search" value="Tìm kiếm" class="btn btn-primary">
                    </form>
                </div>
            </div>
            <div class="card-body">
                <div class="analytic">
                    <a href="<?php echo e(request()->fullUrlWithQuery(['status' => '', 'keyword' => ''])); ?>" class="text-primary">Tất
                        cả
                        sản phẩm<span class="text-muted">(<?php echo e($count[0]); ?>)</span></a>
                    <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'trash', 'keyword' => ''])); ?>"
                        class="text-primary">Thùng rác<span class="text-muted">(<?php echo e($count[1]); ?>)</span></a>
                    
                </div>
                <form action="<?php echo e(route('admin.product.action')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.product.edit')): ?>
                        <div class="form-action form-inline py-3">
                            <select class="form-control mr-1" name="action" id="">
                                <option value="0">Chọn</option>
                                <?php if(request()->status === 'trash'): ?>
                                    <option value="restore">Đưa trở lại</option>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.product.destroy')): ?>
                                        <option value="forceDelete">Xoá Vĩnh Viễn</option>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <option value="hide">Chờ duyệt (ẩn)</option>
                                    <option value="active">Còn hàng (hiển thị)</option>
                                    <option value="sold">Hết hàng (hiển thị)</option>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.product.destroy')): ?>
                                        <option value="delete">Xoá</option>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </select>
                            <input type="submit" name="btn-search" value="Áp dụng" class="btn btn-primary">
                        </div>
                    <?php endif; ?>
                    <table class="table table-striped table-checkall">
                        <thead>
                            <tr>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.product.edit')): ?>
                                    <th scope="col">
                                        <input name="checkall" type="checkbox">
                                    </th>
                                <?php endif; ?>
                                <th scope="col">#</th>
                                <th scope="col">Ảnh</th>
                                <th scope="col">Tên sản phẩm</th>
                                <th scope="col">Giá</th>
                                <th scope="col">Danh mục</th>
                                
                                <th scope="col">Trạng thái</th>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin.product.edit', 'admin.page.destroy'])): ?>
                                    <th scope="col">Tác vụ</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($data) && $data->count() > 0): ?>
                                <?php
                                    $t = 1;
                                ?>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.product.edit')): ?>
                                            <td>
                                                <input type="checkbox" name="id[]" value="<?php echo e($model->id); ?>">
                                            </td>
                                        <?php endif; ?>
                                        <td><?php echo e($t++); ?></td>
                                        <td style="width:10%;height:auto"><img style="width:100%;height:auto"
                                                src="<?php echo e(asset('uploads/' . $model->thumb)); ?>" alt=""></td>
                                        <td style="width:30%"><a
                                                href="<?php echo e(route('admin.product.edit', ['product' => $model->id])); ?>"><?php echo e($model->name); ?></a>
                                        </td>
                                        <?php if($model->discount > 0): ?>
                                            <td>
                                                <p><?php echo e(number_format($model->discount, 0, '', '.') . ' đ'); ?></p>
                                                <small class="text-muted" style="text-decoration:line-through">
                                                    <?php echo e(number_format($model->price, 0, '', '.') . ' đ'); ?></small>
                                            </td>
                                        <?php else: ?>
                                            <td><?php echo e(number_format($model->price, 0, '', '.') . ' đ'); ?></td>
                                        <?php endif; ?>
                                        <td><?php echo e($model->productCat_name); ?></td>
                                        
                                        <?php if($model->status === '1'): ?>
                                            <td><span class="badge badge-success">Còn Hàng</span></td>
                                        <?php elseif($model->status === '2'): ?>
                                            <td><span class="badge badge-danger">Hết Hàng</span></td>
                                        <?php else: ?>
                                            <td><span class="badge badge-secondary">Chờ duyệt</span></td>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin.product.edit', 'admin.product.destroy'])): ?>
                                            <td>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.product.edit')): ?>
                                                    <?php if(request()->status === 'trash'): ?>
                                                        <a href="<?php echo e(route('admin.product.restore', ['id' => $model->id])); ?>"
                                                            class="btn btn-success btn-sm rounded-0 text-white" type="button"
                                                            data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                                class="fas fa-trash-restore"></i></a>
                                                    <?php else: ?>
                                                        <a href="<?php echo e(route('admin.product.edit', ['product' => $model->id])); ?>"
                                                            class="btn btn-success btn-sm rounded-0 text-white" type="button"
                                                            data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                                class="fa fa-edit"></i></a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.product.destroy')): ?>
                                                    <a href="#" class="btn btn-danger btn-sm rounded-0 text-white delete"
                                                        type="button"
                                                        data-delete="<?php echo e(request()->status === 'trash' ? 'xoá vĩnh viễn sản phẩm' : 'xoá sản phẩm'); ?>"
                                                        data-toggle="tooltip"
                                                        data-route="<?php echo e(route('admin.product.destroy', ['product' => $model->id, 'forceDelete' => request()->status === 'trash' ? 'ok' : ''])); ?>"
                                                        data-placement="top" title="Delete"><i class="fa fa-trash"></i></a>
                                                <?php endif; ?>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <td colspan="8" class="text-capitalize text-danger text-italic">Không tìm thấy sản phẩm
                                </td>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </form>
                <form action="" id="delete" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                </form>
                <nav aria-label="Page navigation example">
                    <div class="d-flex">
                        <?php echo e($data->links()); ?>

                    </div>
                </nav>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Xop-pi.com/resources/views/admin/product/index.blade.php ENDPATH**/ ?>