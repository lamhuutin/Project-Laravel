<?php $__env->startSection('title', 'Danh Sách Sản Phẩm'); ?>
<?php $__env->startSection('content'); ?>
    <div class="section" id="list-product-wp">
        <div class="section-head clearfix">
            <h3 class="section-title fl-left"><?php echo e(isset($productCat_name) ? $productCat_name : 'Danh sách sản phẩm'); ?></h3>
            <div class="filter-wp fl-right">
                
                <div class="form-filter">
                    <form method="" action="">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="data" value="<?php echo e(json_encode($data)); ?>">
                        <select name="action">
                            <option value="0">Sắp xếp</option>
                            <option value="hightolow">Giá cao đến thấp</option>
                            <option value="lowtohigh">Giá thấp đến cao</option>
                        </select>
                        
                    </form>
                </div>
            </div>
        </div>
        <div class="section-detail">
            <?php if($data->count() > 0): ?>
                <ul class="list-item clearfix" id="list-products">

                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('productDetail', ['productCatSlug' => Str::slug($model->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id])); ?>"
                                title="" class="thumb img-container">
                                <img src="<?php echo e(asset('uploads/' . $model->thumb)); ?>">
                            </a>
                            <a href="<?php echo e(route('productDetail', ['productCatSlug' => Str::slug($model->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id])); ?>"
                                title="" class="product-name"><?php echo e($model->name); ?></a>
                            <?php if($model->discount > 0): ?>
                                <div class="price">
                                    <span class="new"><?php echo e(number_format($model->discount, 0, ',', '.') . ' đ'); ?></span>
                                    <span class="old"><?php echo e(number_format($model->price, 0, ',', '.') . ' đ'); ?></span>
                                </div>
                            <?php else: ?>
                                <div class="price">
                                    <span class="new"><?php echo e(number_format($model->price, 0, ',', '.') . ' đ'); ?></span>
                                </div>
                            <?php endif; ?>
                            <?php if($model->status === '2'): ?>
                                <div class="price">
                                    <span class="text-danger" style="color:red">Hết Hàng</span>
                                </div>
                            <?php else: ?>
                                <div class="action clearfix">
                                    <button class="add-cart" data-id="<?php echo e($model->id); ?>" data-toggle="modal"
                                        data-target="#success_tic">Thêm Giỏ Hàng</button>
                                    <a href="<?php echo e(route('checkout', ['id' => [$model->id], 'buynow' => 'ok'])); ?>"
                                        title="Mua ngay" class="buy-now fl-right">Mua
                                        ngay</a>
                                </div>
                            <?php endif; ?>
                            <?php if($model->discount>0): ?>
                            <div class="discount-label">
                                <span>-<?php echo e(floor((($model->price-$model->discount)/$model->price)*100)); ?>%</span>
                                <span class="label-text">Giảm giá</span>
                            </div>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php else: ?>
                <p class="text-danger text-capitalize font-italic">Không tìm thấy sản phẩm</p>
            <?php endif; ?>
        </div>
    </div>
    <div class="section" id="paging-wp">
        <div class="section-detail">
            <div class="list-item clearfix">
                <?php echo e($data->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            var getUrlParameter = function getUrlParameter(sParam) {
                var sPageURL = window.location.search.substring(1),
                    sURLVariables = sPageURL.split('&'),
                    sParameterName,
                    i;

                for (i = 0; i < sURLVariables.length; i++) {
                    sParameterName = sURLVariables[i].split('=');

                    if (sParameterName[0] === sParam) {
                        return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
                    }
                }
                return false;
            };

            if (getUrlParameter('filter')) {
                let filter = getUrlParameter('filter');
                $("select[name='action']").val(filter).change();
                filter_product();
            }

            function filter_product() {
                let action = $("select[name='action']").val();
                let products = $("input[name=data]").val();
                let data = {
                    products: products,
                    action: action,
                }
                $.ajax({
                    url: "<?php echo e(route('filterAjax')); ?>",
                    method: 'post',
                    data: data,
                    dataType: 'json',
                    success: function(data) {
                        $("ul#list-products").html(data);
                    },
                    error: function(xhr, ajaxOptions, thrownError) {
                        alert(xhr.status);
                        alert(thrownError);
                    }
                })
            }

            $("select[name='action']").change(function() {
                let filter = $(this).val();
                if (filter !== '0') {
                    let queryParams = new URLSearchParams(window.location.search);
                    queryParams.set("filter", filter);
                    window.history.replaceState(null, null, "?" + queryParams.toString());
                    filter_product();
                }
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Xop-pi.com/resources/views/client/product/index.blade.php ENDPATH**/ ?>