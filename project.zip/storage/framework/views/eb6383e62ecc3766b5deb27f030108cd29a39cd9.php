<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    <div id="wrapper">
        <header class="p-3 bg-primary text-light text-capilatize text-center font-weight-bold mb-3">Hệ Thống Quản Trị Xop-Pi</header>
        <div id="content">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
   
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Xop-pi.com/resources/views/layouts/login.blade.php ENDPATH**/ ?>