let file_thumb = document.querySelector('input#file_thumb');
file_thumb.onchange = function () {
    if (document.querySelector('img.thumb')) document.querySelector('img.thumb').remove();
    if (!['png', 'jpeg', 'gif', 'jpg'].includes(this.files[0].name.split('.').pop().toLowerCase())) alert('file bạn vừa tải không phải dạng ảnh có đuôi jpg,jpeg,png,gif vui lòng tải lại');
    let reader = new FileReader();
    reader.onload = function (e) {
        let thumb = document.createElement('img');
        thumb.classList.add('thumb');
        thumb.setAttribute('src', e.target.result);
        document.querySelector('div.box_thumb').appendChild(thumb);
    }
    reader.readAsDataURL(this.files[0]);
}

let file_images = document.querySelector('input#images');
file_images.onchange = function () {
    let old_files = document.querySelectorAll('img.images');
    if (old_files) {
        for (let item of old_files) {
            item.remove();
        }
    }
    for (let item of this.files) {
        if (!['png', 'jpeg', 'gif', 'jpg'].includes(item.name.split('.').pop().toLowerCase())) alert('danh sách file bạn vừa tải có file không phải dạng ảnh có đuôi jpg,jpeg,png,gif vui lòng tải lại');
        let reader = new FileReader();
        reader.onload = function (e) {
            let image = document.createElement('img');
            image.classList.add('images');
            image.setAttribute('src', e.target.result);
            document.querySelector('div.box_images').appendChild(image);
        }
        reader.readAsDataURL(item);
    }
}

let regex = /^[0-9]+$/;
let price = document.querySelector('input#price');
let discount = document.querySelector('input#discount');
discount.onchange = function(e){
    if(Number(this.value) > Number(price.value)) alert('Giá giảm phải nhỏ hơn gia sản phẩm ban đầu');
}

// let str = '232n3';

// if (regex.test(str)) {
//   console.log('Match found!');
// } else {
//   console.log('No match found.');
// }