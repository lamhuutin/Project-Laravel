$(document).ready(function(){
    let btn_delete = $('a.delete');
    let form_delete = $('form#delete');
    btn_delete.click(function(e){
        if(!confirm('bạn có chắc muốn ' + $(this).attr('data-delete'))) return false;
        let route = $(this).attr('data-route');
        form_delete.attr('action',route);
        form_delete.submit();
    })
});