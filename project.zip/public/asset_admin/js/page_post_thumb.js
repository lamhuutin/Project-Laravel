let input_thumb = document.querySelector('input.file_thumb');
input_thumb.onchange = function () {
    let ext = this.files[0].name.split('.').pop().toLowerCase();
    if(!['jpg','jpeg','png','gif'].includes(ext)){
        alert('file bạn vừa tải lên không phải file ảnh có đuôi jpg,jpeg,png,gif vui lòng tải lại file ảnh đúng định dạng');
        return false;
    } 
    let old_file_thumb = document.querySelector('img.thumb');
    if(old_file_thumb) old_file_thumb.remove();
    if (this.files[0]) {
        let reader = new FileReader();
        reader.onload = function (e) {
            let thumb = document.createElement('img');
            thumb.classList.add('thumb');
            thumb.setAttribute('src', e.target.result);
            document.querySelector('div.box_thumb').appendChild(thumb);
        }
        reader.readAsDataURL(this.files[0])
    }
}


