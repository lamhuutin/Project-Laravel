$(document).ready(function () {
  // alert('okok');
  //change route payment-method
    $('select#payment_method').change(function () {
      $payment_method = $(this).val();
      if ($payment_method === 'vnpay-payment') {
        let route_vnpay = $('form#form-pay').attr('data-route-vnpay');
        $('form#form-pay').attr('action', route_vnpay);
      }
      if ($payment_method === 'cod-payment') {
        let route_cod = $('form#form-pay').attr('data-route-cod');
        $('form#form-pay').attr('action', route_cod);
      }
      if ($payment_method === 'momo-payment') {
        let route_cod = $('form#form-pay').attr('data-route-momo');
        $('form#form-pay').attr('action', route_cod);
      }
    });
  // change qty and price
  let list_id = $('tr.order-total').attr('data-id');
  let route_updateCheckout = $('tr.order-total').attr('data-route');
  $('.plus').click(function () {
    let input_qty = $(this).prev();
    let value = parseInt(input_qty.val());
    value++;
    input_qty.val(value);
    let id = $(this).attr('data-id');
    let rowId = $(this).attr('data-rowId');
    $.ajax({
      url: route_updateCheckout + "?rowId=" + rowId + "&qty=" + input_qty
        .val() + "&list_id=" + list_id,
      method: 'get',
      dataType: 'json',
      success: function (data) {
        $('p#total-order').html(`<span>${data.total_order}</span>`);
        $('input#payment-vnpay').val(data.total_order_original);
        $("td#total-" + rowId).text(data.total);
        $('p#total_price_cart').text(data.total_price);
        $('span#cart_qty_' + id).text(value);
        $('p#total_qty').html(
          `<span>Có ${data.total_qty} sản phẩm trong giỏ hàng</span>`);
        $('span#num').text(data.total_qty);
      },
      error: function (xhr, ajaxOptions, thrownError) {
        alert(xhr.status);
        alert(thrownError);
      }
    })
  });

  $('.minus').click(function () {
    let input_qty = $(this).next();
    let value = parseInt(input_qty.val());
    if (value > 1) {
      value--;
      input_qty.val(value);
      let id = $(this).attr('data-id');
      let rowId = $(this).attr('data-rowId');
      $.ajax({
        url: route_updateCheckout + "?rowId=" + rowId + "&qty=" + input_qty
          .val() + "&list_id=" + list_id,
        method: 'get',
        dataType: 'json',
        success: function (data) {
          $('p#total-order').html(`<span>${data.total_order}</span>`);
          $('input#payment-vnpay').val(data.total_order_original);
          $("td#total-" + rowId).text(data.total);
          $('p#total_price_cart').text(data.total_price);
          $('span#cart_qty_' + id).text(value);
          $('p#total_qty').html(
            `<span>Có ${data.total_qty} sản phẩm trong giỏ hàng</span>`);
          $('span#num').text(data.total_qty);
        },
        error: function (xhr, ajaxOptions, thrownError) {
          alert(xhr.status);
          alert(thrownError);
        }
      })
    }
  });

  // Listen for changes in the "province" select box
  $('#province').on('change', function () {
    var province_id = $(this).val();
    // console.log(province_id);
    if (province_id) {
      // If a province is selected, fetch the districts for that province using AJAX
      let route_changeDistrict = $(this).attr('data-route');
      $.ajax({
        url: route_changeDistrict,
        method: 'GET',
        dataType: "json",
        data: {
          province_id: province_id
        },
        success: function (data) {
          // Clear the current options in the "district" select box
          $('#district').empty();

          // Add the new options for the districts for the selected province
          $.each(data, function (i, district) {
            // console.log(district);
            $('#district').append($('<option>', {
              value: district.id,
              text: district.name
            }));
          });
          // Clear the options in the "wards" select box
          $('#wards').empty();
        },
        error: function (xhr, textStatus, errorThrown) {
          console.log('Error: ' + errorThrown);
        }
      });
      $('#wards').empty();
    } else {
      // If no province is selected, clear the options in the "district" and "wards" select boxes
      $('#district').empty();
    }
  });

  // Listen for changes in the "district" select box
  $('#district').on('change', function () {
    var district_id = $(this).val();
    // console.log(district_id);
    if (district_id) {
      // If a district is selected, fetch the awards for that district using AJAX
      let route_changeWards = $(this).attr('data-route');
      $.ajax({
        url: route_changeWards,
        method: 'GET',
        dataType: "json",
        data: {
          district_id: district_id
        },
        success: function (data) {
          // console.log(data);
          // Clear the current options in the "wards" select box
          $('#wards').empty();
          // Add the new options for the awards for the selected district
          $.each(data, function (i, wards) {
            $('#wards').append($('<option>', {
              value: wards.id,
              text: wards.name
            }));
          });
        },
        error: function (xhr, textStatus, errorThrown) {
          console.log('Error: ' + errorThrown);
        }
      });
    } else {
      // If no district is selected, clear the options in the "award" select box
      $('#wards').empty();
    }
  });

  const urlParams = new URLSearchParams(window.location.search);
  // console.log(window.location.pathname);
  // console.log(urlParams.toString());
  urlParams.set('buynow', '');
  const newUrl = window.location.pathname + '?' + urlParams.toString();
  window.history.pushState({}, '', newUrl);
});

const urlParams = new URLSearchParams(window.location.search);
urlParams.set('buynow', '');
const newUrl = window.location.pathname + '?' + urlParams.toString();
window.history.pushState({}, '', newUrl);