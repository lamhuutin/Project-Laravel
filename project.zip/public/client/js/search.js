$(document).ready(function() {
    $('div#search-ajax').hide();
    $('input#s').keyup(function() {
        let text = $(this).val();
        let route = $(this).attr('data-route');
        if (text) {
            $.ajax({
                url: route + "?keyword=" + text,
                method: 'get',
                dataType: 'json',
                success: function(data) {
                    if (data === 'no') $('div#search-ajax').html(
                        "<p style='color:red; text-transform: capitalize;'>Không tìm thấy sản phẩm phù hợp</p>"
                    );
                    else if (data !== 'no') $('div#search-ajax').html(data);
                },
                error: function(xhr, ajaxOptions, thrownError) {
                    alert(xhr.status);
                    alert(thrownError);
                }
            })
            $('div#search-ajax').show();
        } else {
            $('div#search-ajax').hide();
        }
    })
})            