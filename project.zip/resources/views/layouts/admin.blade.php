<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/solid.min.css">
    <link rel="stylesheet" href=" {{ asset('asset_admin/css/style.css') }} ">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.tiny.cloud/1/a8dau1zq2nibzxyyes5tjequg6xt33vr5cbywjpdso2hh1gy/tinymce/4/tinymce.min.js"
        referrerpolicy="origin"></script>
    <script>
        var editor_config = {
            path_absolute: "http://localhost/Xop-pi.com/public/",
            selector: "textarea.content",
            plugins: [
                "advlist autolink lists link image charmap print preview hr anchor pagebreak",
                "searchreplace wordcount visualblocks visualchars code fullscreen",
                "insertdatetime media nonbreaking save table contextmenu directionality",
                "emoticons template paste textcolor colorpicker textpattern",
                "textcolor"
            ],
            toolbar: "insertfile undo redo | styleselect | bold italic| fontsizeselect |fontsizeselect | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media| forecolor backcolor",
            fontsize_formats: "8pt 10pt 12pt 14pt 18pt 24pt 36pt",
            height: "",
            fullscreen_native: true,
            textcolor_map: [
                "000000", "Black",
                "993300", "Burnt orange",
                "333300", "Dark olive",
                "003300", "Dark green",
                "003366", "Dark azure",
                "000080", "Navy Blue",
                "333399", "Indigo",
                "333333", "Very dark gray",
                "800000", "Maroon",
                "FF6600", "Orange",
                "808000", "Olive",
                "008000", "Green",
                "008080", "Teal",
                "0000FF", "Blue",
                "666699", "Grayish blue",
                "808080", "Gray",
                "FF0000", "Red",
                "FF9900", "Amber",
                "99CC00", "Yellow green",
                "339966", "Sea green",
                "33CCCC", "Turquoise",
                "3366FF", "Royal blue",
                "800080", "Purple",
                "999999", "Medium gray",
                "FF00FF", "Magenta",
                "FFCC00", "Gold",
                "FFFF00", "Yellow",
                "00FF00", "Lime",
                "00FFFF", "Aqua",
                "00CCFF", "Sky blue",
                "993366", "Red violet",
                "FFFFFF", "White",
                "FF99CC", "Pink",
                "FFCC99", "Peach",
                "FFFF99", "Light yellow",
                "CCFFCC", "Pale green",
                "CCFFFF", "Pale cyan",
                "99CCFF", "Light sky blue",
                "CC99FF", "Plum"
            ],
            relative_urls: false,
            file_browser_callback: function(field_name, url, type, win) {
                var x = window.innerWidth || document.documentElement.clientWidth || document.getElementsByTagName(
                    'body')[0].clientWidth;
                var y = window.innerHeight || document.documentElement.clientHeight || document
                    .getElementsByTagName('body')[0].clientHeight;

                var cmsURL = editor_config.path_absolute + 'laravel-filemanager?field_name=' + field_name;
                if (type == 'image') {
                    cmsURL = cmsURL + "&type=Images";
                } else {
                    cmsURL = cmsURL + "&type=Files";
                }

                tinyMCE.activeEditor.windowManager.open({
                    file: cmsURL,
                    title: 'Filemanager',
                    width: x * 0.8,
                    height: y * 0.8,
                    resizable: "yes",
                    close_previous: "no"
                });
            }
        };
        tinymce.init(editor_config);
    </script>
    <title>@yield('title')</title>
</head>

<body>
    <div id="warpper" class="nav-fixed">
        <nav class="topnav shadow navbar-light bg-white d-flex">
            <div class="navbar-brand"><a href="{{ route('admin.dashboard') }}">Admin Xop-pi</a></div>
            <div class="nav-right ">
                <div class="btn-group mr-auto">
                    <button type="button" class="btn dropdown" data-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false">
                        <i class="plus-icon fas fa-plus-circle"></i>
                    </button>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="?view=add-post">Thêm bài viết</a>
                        <a class="dropdown-item" href="?view=add-product">Thêm sản phẩm</a>
                        <a class="dropdown-item" href="?view=list-order">Thêm đơn hàng</a>
                    </div>
                </div>
                <div class="btn-group">
                    <button type="button" class="btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false">
                        {{ Auth::user()->name }}
                    </button>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a class="dropdown-item" href="{{ route('admin.user.edit', ['id' => Auth::id()]) }}">Tài
                            khoản</a>
                        <a class="dropdown-item" href="#"
                            onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">Thoát</a>
                        {!! Form::open(['route' => 'logout', 'method' => 'post', 'class' => 'd-none', 'id' => 'logout-form']) !!}
                        {!! Form::close() !!}
                        {{-- <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                            @csrf
                        </form> --}}
                    </div>
                </div>
            </div>
        </nav>
        <!-- end nav  -->
        <div id="page-body" class="d-flex">
            <div id="sidebar" class="bg-white">
                <ul id="sidebar-menu">
                    <li class="nav-link @if (session('module') == 'dashboard') active @endif">
                        <a href="{{ route('admin.dashboard') }}">
                            <div class="nav-link-icon d-inline-flex ">
                                <i class="far fa-folder"></i>
                            </div>
                            Dashboard
                        </a>
                        {{-- <i class="arrow fas fa-angle-right"></i> --}}
                    </li>
                    
                    @canany(['admin.slide.index', 'admin.slide.create', 'admin.slide.edit', 'admin.slide.destroy'])
                        <li class="nav-link @if (session('module') == 'slide') active @endif">
                            <a href="{{ route('admin.slide.index') }}">
                                <div class="nav-link-icon d-inline-flex">
                                    <i class="far fa-folder"></i>
                                </div>
                                Slide
                            </a>
                            <i class="arrow fas fa-angle-right"></i>

                            <ul class="sub-menu">
                                <li><a href="{{ route('admin.slide.create') }}">Thêm mới</a></li>
                                <li><a href="{{ route('admin.slide.index') }}">Danh sách</a></li>
                            </ul>
                        </li>
                    @endcanany

                    @canany(['admin.page.index', 'admin.page.create', 'admin.page.edit', 'admin.page.destroy'])
                        <li class="nav-link @if (session('module') == 'page') active @endif">
                            <a href="{{ route('admin.page.index') }}">
                                <div class="nav-link-icon d-inline-flex">
                                    <i class="far fa-folder"></i>
                                </div>
                                Trang
                            </a>
                            <i class="arrow fas fa-angle-right"></i>

                            <ul class="sub-menu">
                                <li><a href="{{ route('admin.page.create') }}">Thêm mới</a></li>
                                <li><a href="{{ route('admin.page.index') }}">Danh sách</a></li>
                            </ul>
                        </li>
                    @endcanany

                    @canany(['admin.post.index', 'admin.post.create', 'admin.post.edit', 'admin.post.destroy'])
                        <li class="nav-link @if (session('module') == 'post') active @endif ">
                            <a href="{{ route('admin.post.index') }}">
                                <div class="nav-link-icon d-inline-flex">
                                    <i class="far fa-folder"></i>
                                </div>
                                Bài viết
                            </a>
                            <i class="arrow fas fa-angle-right"></i>
                            <ul class="sub-menu">
                                <li><a href="{{ route('admin.post.create') }}">Thêm mới</a></li>
                                <li><a href="{{ route('admin.post.index') }}">Danh sách</a></li>
                                <li><a href="{{ route('admin.postCat.create') }}">Danh mục</a></li>
                            </ul>
                        </li>
                    @endcanany

                    @canany(['admin.product.index', 'admin.product.create', 'admin.product.edit',
                        'admin.product.destroy'])
                        <li class="nav-link @if (session('module') == 'product') active @endif">
                            <a href="{{ route('admin.product.index') }}">
                                <div class="nav-link-icon d-inline-flex">
                                    <i class="far fa-folder"></i>
                                </div>
                                Sản phẩm
                            </a>
                            <i class="arrow fas fa-angle-down"></i>
                            <ul class="sub-menu">
                                <li><a href="{{ route('admin.product.create') }}">Thêm mới</a></li>
                                <li><a href="{{ route('admin.product.index') }}">Danh sách</a></li>
                                <li><a href="{{ route('admin.productCat.create') }}">Danh mục</a></li>
                            </ul>
                        </li>
                    @endcanany

                    @canany(['admin.order.index', 'admin.order.create', 'admin.order.edit', 'admin.order.destroy'])
                        <li class="nav-link @if (session('module') == 'order') active @endif ">
                            <a href="{{ route('admin.order.index') }}">
                                <div class="nav-link-icon d-inline-flex">
                                    <i class="far fa-folder"></i>
                                </div>
                                Bán hàng
                            </a>
                            <i class="arrow fas fa-angle-right"></i>
                            <ul class="sub-menu">
                                <li><a href="{{ route('admin.order.index') }}">Đơn hàng</a></li>
                            </ul>
                        </li>
                    @endcanany

                    @canany(['admin.user.index', 'admin.user.create', 'admin.user.edit', 'admin.user.destroy'])
                        <li class="nav-link @if (session('module') == 'user') active @endif">
                            <a href="{{ route('admin.user.index') }}">
                                <div class="nav-link-icon d-inline-flex">
                                    <i class="far fa-folder"></i>
                                </div>
                                Users
                            </a>
                            <i class="arrow fas fa-angle-right"></i>

                            <ul class="sub-menu">
                                <li><a href="{{ route('admin.user.create') }}">Thêm mới</a></li>
                                <li><a href="{{ route('admin.user.index') }}">Danh sách</a></li>
                            </ul>
                        </li>
                    @endcanany

                    @canany(['admin.role.index', 'admin.role.create', 'admin.role.edit', 'admin.role.destroy'])
                        <li class="nav-link @if (session('module') == 'role') active @endif">
                            <a href="{{ route('admin.role.index') }}">
                                <div class="nav-link-icon d-inline-flex">
                                    <i class="far fa-folder"></i>
                                </div>
                                Phân Quyền
                            </a>
                            <i class="arrow fas fa-angle-right"></i>
                            <ul class="sub-menu">
                                <li><a href="{{ route('admin.role.create') }}">Tạo Quyền</a></li>
                                <li><a href="{{ route('admin.role.index') }}">Danh sách</a></li>
                            </ul>
                        </li>
                    @endcanany
                </ul>
            </div>
            <div id="wp-content">
                @yield('content')
            </div>
        </div>


    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="{{ asset('asset_admin/js/app.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
    @yield('script')
</body>

</html>
