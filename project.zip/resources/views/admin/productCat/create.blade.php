@extends('layouts.admin')
@section('title', 'Thêm danh mục sản phẩm')
@section('content')
    <div id="content" class="container-fluid">
        @if (session('status'))
            <div class="alert alert-success text-capitalize font-italic">
                {{ session('status') }}
            </div>
        @endif
        @if (session('fail'))
            <div class="alert alert-danger text-capitalize font-italic">
                {{ session('fail') }}
            </div>
        @endif
        <div class="row">
            <div class="col-4">
                <div class="card">
                    <div class="card-header font-weight-bold">
                        Danh mục sản phẩm
                    </div>
                    <div class="card-body">
                        <form action="{{ route('admin.productCat.store') }}" method="POST">
                            @csrf
                            <div class="form-group">
                                <label for="name">Tên danh mục sản phẩm</label>
                                <input class="form-control" type="text" name="name" id="name">
                            </div>
                            <div class="form-group">
                                <label for="">Chọn danh mục cha</label>
                                <select class="form-control" name="parent_id" id="">
                                    <option value="0">Đặt làm danh mục cha</option>
                                    @if (isset($data) && count($data) > 0)
                                        @foreach ($data as $model)
                                            <option value="{{ $model->id }}">
                                                {{ str_repeat('-', $model->level) . ' ' . $model->name }}</option>
                                        @endforeach
                                    @endif
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Thêm mới</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-8">
                <div class="card">
                    <div class="card-header font-weight-bold">
                        Danh sách
                    </div>
                    <div class="card-body" style="height:40rem; overflow:auto">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Tên Danh Mục</th>
                                    <th scope="col">Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if (isset($data) && count($data) > 0)
                                    @php
                                        $t = 1;
                                    @endphp
                                    @foreach ($data as $model)
                                        <tr>
                                            <th scope="row">{{ $t++ }}</th>
                                            <td>{{ str_repeat('-', $model->level) . ' ' . $model->name }}</td>
                                            <td class="d-flex"><a
                                                    href="{{ route('admin.productCat.edit', ['productCat' => $model->id]) }}"
                                                    class="btn btn-success btn-sm rounded-0 mr-2" type="button"
                                                    data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                        class="fa fa-edit"></i></a>
                                                <form
                                                    action="{{ route('admin.productCat.destroy', ['productCat' => $model->id]) }}"
                                                    method="post">
                                                    @csrf
                                                    @method('delete')
                                                    <button class="btn btn-danger btn-sm rounded-0" type="submit"
                                                    data-toggle="tooltip" data-placement="top" title="Delete"><i
                                                        class="fa fa-trash"></i></button>
                                                </form>
                                               
                                            </td>
                                        </tr>
                                    @endforeach
                                @else
                                    <td colspan="3" class="text-danger text-capitalize font-italic">Không có danh mục sản
                                        phẩm</td>
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
@endsection
