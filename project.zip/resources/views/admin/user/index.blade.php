@extends('layouts.admin')
@section('title', 'Danh Sách Admin')
@section('content')
    <div id="content" class="container-fluid">
        @if (session('status'))
            <div class="alert alert-success text-capitalize">
                {{ session('status') }}
            </div>
        @endif
        @if (session('fail'))
            <div class="alert alert-danger text-capitalize font-italic">
                {{ session('fail') }}
            </div>
        @endif
        <div class="card">
            <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
                <h5 class="m-0 ">Danh sách thành viên</h5>
                <div class="form-search form-inline">
                    <form action="#">
                        <input type="" class="form-control form-search" name="keyword"
                            value="{{ request()->keyword }}" placeholder="Tìm kiếm">
                        <input type="hidden" name="status" value="{{ request()->status }}">
                        <input type="submit" name="btn-search" value="Tìm kiếm" class="btn btn-primary">
                    </form>
                </div>
            </div>
            <div class="card-body">
                <div class="analytic">
                    <a href="{{ request()->fullUrlWithQuery(['status' => 'active', 'keyword' => '']) }}"
                        class="text-primary">Hoạt Động<span class="text-muted">({{ $count['active'] }})</span></a>
                    <a href="{{ request()->fullUrlWithQuery(['status' => 'trash', 'keyword' => '']) }}"
                        class="text-primary">Vô Hiệu Hoá<span class="text-muted">({{ $count['trash'] }})</span></a>
                </div>
                <form action="{{ route('admin.user.action') }}" method="post">
                    @csrf
                    <div class="form-action form-inline py-3">
                        <select class="form-control mr-1" id="" name="action">
                            <option value="0">-- Chọn Thao tác --</option>
                            @if (request()->status === 'trash')
                                <option value="forceDelete">Xoá vĩnh viễn</option>
                                <option value="restore">Đưa trở lại</option>
                            @else
                                <option value="delete">Xoá</option>
                                <option value="role">Cấp Quyền</option>
                            @endif
                        </select>
                        <input type="submit" name="btn-search" value="Áp dụng" class="btn btn-primary">
                    </div>
                    <table class="table table-striped table-checkall">
                        <thead>
                            <tr>
                                @can('admin.user.edit')
                                    <th>
                                        <input type="checkbox" name="checkall">
                                    </th>
                                @endcan
                                <th scope="col">#</th>
                                <th scope="col">Họ tên</th>
                                <th scope="col">Email</th>
                                <th scope="col">Quyền</th>
                                <th scope="col">Ngày tạo</th>
                                @canany(['admin.user.edit', 'admin.user.destroy'])
                                    <th scope="col">Tác vụ</th>
                                @endcanany

                            </tr>
                        </thead>
                        <tbody>
                            @if ($data->count() > 0)
                                @php
                                    $t = 1;
                                @endphp
                                @foreach ($data as $model)
                                    <tr>
                                        @can('admin.user.edit')
                                            <td>
                                                @if (Auth::id() != $model->id)
                                                    <input type="checkbox" name="id[]" value="{{ $model->id }}">
                                                @else
                                                    <i class="fa-solid fa-user-tie"></i>
                                                @endif
                                            </td>
                                        @endcan
                                        <th scope="row">{{ $t++ }}</th>
                                        <td>{{ $model->name }}</td>
                                        <td>{{ $model->email }}</td>
                                        <td>
                                            @if ($model->roles->count() > 0)
                                                @foreach ($model->roles as $role)
                                                    <span class="badge badge-warning"> {{ $role->name }}</span>
                                                @endforeach
                                            @endif
                                        </td>
                                        <td>{{ $model->created_at }}</td>
                                        @canany(['admin.user.edit', 'admin.user.destroy'])
                                            <td>
                                                @can('admin.user.edit')
                                                    @if (request()->status === 'trash')
                                                        <a href="{{ route('admin.user.restore', ['id' => $model->id]) }}"
                                                            class="btn btn-success btn-sm rounded-0 text-white" type="button"
                                                            data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                                class="fas fa-trash-restore"></i></a>
                                                    @else
                                                        <a href="{{ route('admin.user.edit', ['id' => $model->id]) }}"
                                                            class="btn btn-success btn-sm rounded-0 text-white" type="button"
                                                            data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                                class="fa fa-edit"></i></a>
                                                    @endif
                                                @endcan
                                                @can('admin.user.destroy')
                                                    @if (Auth::id() !== $model->id)
                                                        @if (request()->status === 'trash')
                                                            <a href="{{ route('admin.user.destroy', ['id' => $model->id, 'forceDelete' => 'ok']) }}"
                                                                class="btn btn-danger btn-sm rounded-0 text-white" type="button"
                                                                data-toggle="tooltip" data-placement="top" title="Delete"
                                                                onclick="return confirm('Bạn có chắc muốn xoá vĩnh viễn {{ $model->name }}'  )"><i
                                                                    class="fa fa-trash"></i></a>
                                                        @else
                                                            <a href="{{ route('admin.user.destroy', ['id' => $model->id]) }}"
                                                                class="btn btn-danger btn-sm rounded-0 text-white" type="button"
                                                                data-toggle="tooltip" data-placement="top" title="Delete"
                                                                onclick="return confirm('Bạn có chắc muốn xoá  {{ $model->name }}'  )"><i
                                                                    class="fa fa-trash"></i></a>
                                                        @endif
                                                    @endif
                                                @endcan
                                            </td>
                                        @endcanany

                                    </tr>
                                @endforeach
                            @else
                                <td colspan="7" class="text-danger fort-italic">Không tìm thấy user</td>
                            @endif
                        </tbody>
                    </table>
                </form>
                <nav aria-label="Page navigation example">
                    <div class="d-flex">
                        {!! $data->links() !!}
                    </div>
                </nav>
            </div>
        </div>
    </div>
@endsection
