@extends('layouts.admin')
@section('title', 'Thông Tin User')
@section('content')
    <div id="content" class="container-fluid">
        @if (session('status'))
            <div class="alert alert-success">
                {{ session('status') }}
            </div>
        @endif
        <div class="card">
            <div class="card-header font-weight-bold">
                @php
                    echo Auth::id() != $data->id ? "Thông tin user {$data->name}" : 'Chỉnh Sửa Thông Tin Cá Nhân';
                @endphp
            </div>
            <div class="card-body">
                {{-- <small class="text-muted text-capitalize font-italic">
                    @if (Auth::id() === $data->id)
                        bạn có thể để trống mật khẩu mới và xác nhận mật khẩu
                        nếu bạn chỉ muốn thay đổi họ và tên
                    @endif
                </small> --}}
                <form action="{{ route('admin.user.update', ['id' => $data->id]) }}" method="POST">
                    @csrf
                    <div class="form-group">
                        <label for="name">Họ và tên</label>
                        <input class="form-control" type="text" value="{{ $data->name }}" name="name" id="name"
                            @if (Auth::id() != $data->id) @disabled(true) @endif>
                    </div>
                    @error('name')
                        <small class="text-danger text-capitalize font-italic">{{ $message }}</small>
                    @enderror
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input class="form-control" type="text" name="email" value="{{ $data->email }}" id="email"
                            disabled>
                    </div>
                    <div class="form-group">
                        <label for="email">Kích Hoạt Ngày</label>
                        <input class="form-control" type="text" name="email" value="{{ $data->email_verified_at }}"
                            id="email" disabled>
                    </div>
                    @if (Auth::id() === $data->id)
                        <div class="form-group">
                            <label for="password">Mật Khẩu Mới <small>(có thể để trống nếu bạn không muốn thay đổi mật
                                    khẩu)</small></label>
                            <input class="form-control" type="password" name="password" id="password">
                        </div>
                        @error('password')
                            <small class="text-danger text-capitalize font-italic">{{ $message }}</small>
                        @enderror
                        <div class="form-group">
                            <label for="password_confirmation">Xác Nhận Mật khẩu</label>
                            <input class="form-control" type="password" name="password_confirmation"
                                id="password_confirmation">
                        </div>
                    @endif
                    <div class="form-group">
                        <label for="">Vai trò của user</label>
                        @if ($roles->count() > 0)
                            @foreach ($roles as $role)
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox"
                                        @if (in_array($role->id, $data->roles->pluck('id')->toArray())) @checked(true) @endif name="role[]"
                                        value="{{ $role->id }}" id="{{ $role->id }}">
                                    <label class="form-check-label" for="{{ $role->id }}">
                                        {{ $role->name }} ({{ $role->desc }})
                                    </label>
                                </div>
                            @endforeach
                            <button type="submit" class="btn btn-primary">Cập Nhật</button>
                        @endif
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
