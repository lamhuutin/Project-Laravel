@extends('layouts.admin')
@section('title', 'Tạo Slide')
@section('content')
    <div id="content" class="container-fluid">
        <div class="card">
            <div class="card-header font-weight-bold">
                Chỉnh Sửa Slide
            </div>
            <div class="card-body">
                <form action="{{ route('admin.slide.update',['slide'=>$data->id]) }}" method="post" enctype="multipart/form-data">
                    @csrf
                    @method('put')
                    <div class="form-group">
                        <label for="title">Tên Slide</label>
                        <input class="form-control" type="text" value="{{ $data->name }}" name="name"
                            id="title">
                        @error('name')
                            <small class="text-danger text-capitalize font-italic">{{ $message }}</small>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="file_thumb" class="">Ảnh <small class="text-muted">(nên chọn ảnh có tỷ lệ thấp
                                nhất 878x384, nếu kích thước ảnh quá lớn bạn có thể truy cập vào <a style="color: red"
                                    target="_blank" href="https://picresize.com/">Đây</a> để resize)</small></label>
                        <input type="file" name="file_thumb" class="form-control file_thumb" id="file_thumb">
                        @error('file_thumb')
                            <small class="text-danger text-capitalize font-italic">{{ $message }}</small>
                        @enderror
                    </div>
                    <div class="box_thumb" class="d-flex flex-wrap">
                        <img src="{{ asset('uploads/' . $data->thumb) }}" alt="" class="thumb">
                    </div>
                    <div class="form-group">
                        <label for="">Trạng thái</label>
                        <div class="form-check">
                            <input class="form-check-input" @if ($data->status === '0') @checked(true) @endif
                                type="radio" name="status" value="0" id="exampleRadios1" value="option1" checked>
                            <label class="form-check-label" for="exampleRadios1">
                                Chờ duyệt
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" @if ($data->status === '1') @checked(true) @endif
                                type="radio" name="status" value="1" id="exampleRadios2" value="option2">
                            <label class="form-check-label" for="exampleRadios2">
                                Công khai
                            </label>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Cập Nhật</button>
                </form>
            </div>
        </div>
    </div>
@endsection
@section('script')
    <script src="{{ asset('asset_admin/js/page_post_thumb.js') }}"></script>
@endsection
