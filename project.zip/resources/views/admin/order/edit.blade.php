@extends('layouts.admin')
@section('title', 'chi tiết đơn hàng')
@section('content')
    <div class="container-fluid py-5">
        <div class="card-header font-weight-bold">
            <h3 class="text-center text-primary">Chi Tiết Đơn Hàng</h3>
        </div>
        <!-- end analytic  -->
        <div class="card">
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            {{-- <th scope="col">Mã</th> --}}
                            <th scope="col">Ảnh</th>
                            {{-- <th scope="col">Sản phẩm</th> --}}
                            <th scope="col">Tên sản phẩm</th>
                            <th scope="col">Giá trị</th>
                            <th scope="col">Số lượng</th>
                            <th scope="col">Tổng giá</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php
                            $t = 1;
                        @endphp
                        @foreach ($data->order_detail->list_order as $model)
                            <tr>
                                <th scope="row">{{ $t++ }}</th>
                                {{-- <td>1213</td> --}}
                                <td style="width:150px">
                                    <img style="width:100%" src="{{ asset('uploads/' . $model->options->thumb) }}"
                                        alt="">
                                </td>
                                {{-- <td><a href="#">Samsung Galaxy A51 (8GB/128GB)</a></td> --}}
                                <td>{{ $model->name }}</td>
                                <td>{{ number_format($model->price, 0, ',', '.') . ' đ' }}</td>
                                <td><span class="badge badge-warning">{{ $model->qty }}</span></td>
                                <td>{{ number_format($model->price * $model->qty, 0, ',', '.') . ' đ' }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                <p class="text-capitalize font-weight-bold text-danger position-relative" style="left: 70%">Tổng Giá Trị Đơn
                    Hàng: {{ number_format($data->total_price, 0, ',', '.') . ' đ' }}</p>
                <nav aria-label="Page navigation example">
                    <div>
                        <h3 class="text-center text-primary">Thông tin Khách hàng và địa chỉ</h3>
                        <p class="font-weight-bold text-primary">Tên Khách hàng: <span
                                class="text-dark">{{ $data->name }}</span> </p>
                        <p class="font-weight-bold text-primary">Email: <span class="text-dark">{{ $data->email }}</span>
                        </p>
                        <p class="font-weight-bold text-primary">SĐT: <span class="text-dark">{{ $data->phone }}</span>
                        </p>
                        <p class="font-weight-bold text-primary">Địa Chỉ: <span
                                class="text-dark">{{ $data->address_shipping }}</span> </p>
                            
                        <p class="font-weight-bold text-primary">Phương Thức Thanh Toán: <span class="text-dark">@php
                            $method = ['cod-payment'=>'Thanh Toán Khi Nhận Hàng','vnpay-payment'=>'Đã Thanh Toán Bằng VnPay','momo-payment'=>'Đã Thanh Toán Bằng MoMo'];
                            echo $method[$data->payment_method];
                        @endphp</span>
                        <p class="font-weight-bold text-primary">Ghi Chú: <span class="text-dark">{{ $data->note }}</span>
                        </p>
                    </div>
                </nav>
                <form action="{{ route('admin.order.update', ['id' => $data->id]) }}" method="post" style="width:18%">
                    @csrf
                    <div class="input-group">
                        <label for="" class="font-weight-bold">Trạng Thái Đơn Hàng</label>
                        <select name="status" class="custom-select" id="">
                            <option @if ($data->status === 'đã xác nhận') @selected(true) @endif value="đã xác nhận">Đã Xác Nhận
                            </option>
                            <option @if ($data->status === 'đang vận chuyển') @selected(true) @endif value="đang vận chuyển">Đang
                                Vận Chuyển</option>
                            <option @if ($data->status === 'hoàn thành') @selected(true) @endif value="hoàn thành">Hoàn Thành
                            </option>
                            <option @if ($data->status === 'đã huỷ') @selected(true) @endif value="đã huỷ">Đã Huỷ</option>
                        </select>
                    </div>
                    <div class="form-group mt-3">
                        <button type="submit" class="btn btn-primary">Cập Nhật</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
