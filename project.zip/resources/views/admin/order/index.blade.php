@extends('layouts.admin')
@section('title', 'Danh Sách Đơn Hàng')
@section('content')
    <div id="content" class="container-fluid">
        @error('action')
            <div class="alert alert-danger text-capitalize font-italic">
                {{ $message }}
            </div>
        @enderror
        @error('id')
            <div class="alert alert-danger text-capitalize font-italic">
                {{ $message }}
            </div>
        @enderror
        @if (session('status'))
            <div class="alert alert-success text-capitalize font-italic">
                {{ session('status') }}
            </div>
        @endif
        @if (session('fail'))
            <div class="alert alert-danger text-capitalize font-italic">
                {{ session('fail') }}
            </div>
        @endif
        <div class="card">
            <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
                <h5 class="m-0 ">Danh Sách Đơn Hàng</h5>
                <div class="form-search form-inline">
                    <form action="">
                        <input type="text" name="keyword" class="form-control form-search" placeholder="Tìm kiếm">
                        <input type="hidden" name="status" value="{{ request()->status }}">
                        <input type="hidden" name="order_type" value="{{ request()->order_type }}">
                        <input type="submit" name="btn-search" value="Tìm kiếm" class="btn btn-primary">
                    </form>
                </div>
            </div>
            <div class="card-body">
                <div class="analytic">
                    <a href="{{ request()->fullUrlWithQuery(['status' => '', 'keyword' => '', 'order_type' => '']) }}"
                        class="text-primary">
                        Hiện hành<span class="text-muted">({{ $count[0] }})</span></a>
                    <a href="{{ request()->fullUrlWithQuery(['status' => '', 'keyword' => '', 'order_type' => 'đã xác nhận']) }}"
                        class="text-primary">Đã Xác Nhận<span class="text-muted">({{ $count[1] }})</span></a>
                    <a href="{{ request()->fullUrlWithQuery(['status' => '', 'keyword' => '', 'order_type' => 'đang vận chuyển']) }}"
                        class="text-primary">Đang Vận Chuyển<span class="text-muted">({{ $count[2] }})</span></a>
                    <a href="{{ request()->fullUrlWithQuery(['status' => '', 'keyword' => '', 'order_type' => 'hoàn thành']) }}"
                        class="text-primary">Hoàn Thành<span class="text-muted">({{ $count[3] }})</span></a>
                    <a href="{{ request()->fullUrlWithQuery(['status' => '', 'keyword' => '', 'order_type' => 'đã huỷ']) }}"
                        class="text-primary">Đã Huỷ<span class="text-muted">({{ $count[4] }})</span></a>
                    <a href="{{ request()->fullUrlWithQuery(['status' => 'trash', 'keyword' => '', 'order_type' => '']) }}"
                        class="text-primary">Thùng rác<span class="text-muted">({{ $count[5] }})</span></a>
                </div>
                <form action="{{ route('admin.order.action') }}" method="post">
                    @csrf
                    @can('admin.order.edit')
                        <div class="form-action form-inline py-3">
                            <select class="form-control mr-1" name="action" id="">
                                <option value="0">-- Chọn Thao tác --</option>
                                @if (request()->status == 'trash')
                                    <option value="restore">Đưa trở lại</option>
                                    @can('admin.order.destroy')
                                        <option value="forceDelete">Xoá vĩnh viễn</option>
                                    @endcan
                                @else
                                    <option value="đã xác nhận">Đã Xác Nhận</option>
                                    <option value="đang vận chuyển">Đang vận chuyển</option>
                                    <option value="hoàn thành">Hoàn Thành</option>
                                    <option value="đã huỷ">Đã Huỷ</option>
                                    @can('admin.order.destroy')
                                        <option value="delete">Xoá</option>
                                    @endcan
                                @endif
                            </select>
                            <input type="submit" name="btn-search" value="Áp dụng" class="btn btn-primary">
                        </div>
                    @endcan

                    <table class="table table-striped table-checkall">
                        <thead>
                            <tr>
                                @can('admin.order.edit')
                                    <th scope="col">
                                        <input name="checkall" type="checkbox">
                                    </th>
                                @endcan
                                <th scope="col">#</th>
                                <th scope="col">Mã Đơn</th>
                                <th scope="col">Khách hàng</th>
                                <th scope="col">Số lượng</th>
                                <th scope="col">Giá trị</th>
                                <th scope="col">Trạng thái</th>
                                <th scope="col">Thời gian</th>
                                @canany(['admin.order.edit', 'admin.order.destroy'])
                                    <th scope="col">Tác vụ</th>
                                @endcanany
                            </tr>
                        </thead>
                        <tbody>
                            @if ($data->count() > 0)
                                @php
                                    $t = 1;
                                @endphp
                                @foreach ($data as $model)
                                    <tr>
                                        @can('admin.order.edit')
                                            <td>
                                                <input type="checkbox" name="id[]" value="{{ $model->id }}">
                                            </td>
                                        @endcan
                                        <td scope="row">{{ $t++ }}</td>
                                        <td>{{ $model->code }}</td>
                                        <td>{{ $model->name }} <br>
                                            {{ $model->phone }}</td>
                                        <td>{{ $model->total_product }}</td>
                                        <td>{{ number_format($model->total_price, 0, ',', '.') . ' đ' }}</td>
                                        <td><span
                                                class="badge badge-@php
$color = ['đã xác nhận'=>'info','đang vận chuyển'=>'warning','hoàn thành'=>'success','đã huỷ'=>'danger'];
                                            echo $color[$model->status]; @endphp text-capitalize">{{ $model->status }}</span>
                                        </td>
                                        <td>{{ $model->created_at }}</td>
                                        @canany(['admin.order.edit', 'admin.order.destroy'])
                                            <td>
                                                @can('admin.order.edit')
                                                    @if (request()->status === 'trash')
                                                        <a href="{{ route('admin.order.restore', ['id' => $model->id]) }}"
                                                            class="btn btn-success btn-sm rounded-0" type="button"
                                                            data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                                class="fas fa-trash-restore"></i></a>
                                                    @else
                                                        <a href="{{ route('admin.order.edit', ['id' => $model->id]) }}"
                                                            class="btn btn-success btn-sm rounded-0" type="button"
                                                            data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                                class="fa fa-edit"></i></a>
                                                    @endif
                                                @endcan
                                                @can('admin.order.destroy')
                                                    <a href="{{ route('admin.order.destroy', ['id' => $model->id, 'forceDelete' => request()->status == 'trash' ? 'ok' : '']) }}"
                                                        class="btn btn-danger btn-sm rounded-0 text-white" type="button"
                                                        data-toggle="tooltip" data-placement="top" title="Delete"><i
                                                            class="fa fa-trash"></i></a>
                                                @endcan
                                            </td>
                                        @endcanany

                                    </tr>
                                @endforeach
                            @else
                                <td colspan="8" class="text-danger font-italic">Không tìm thấy bài viết</td>
                            @endif
                        </tbody>
                    </table>
                </form>
                <form action="" method="post" id="delete">
                    @csrf
                    @method('delete')
                </form>
                <nav aria-label="Page navigation example">
                    <div class="d-flex">
                        {{ $data->links() }}
                    </div>
                </nav>
            </div>
        </div>
    </div>
@endsection
