@extends('layouts.admin')
@section('title', 'Tạo sản phẩm')
@section('script')
    <script src="{{ asset('asset_admin/js/product.js') }}"></script>
@endsection
@section('content')
    <div id="content" class="container-fluid">
        @if (session('status'))
            <div class="alert alert-success text-capitalize text-italic">
                {{ session('status') }}
            </div>
        @endif
        <div class="card">
            <div class="card-header font-weight-bold">
                Thêm sản phẩm
            </div>
            <div class="card-body">
                <form action="{{ route('admin.product.store') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label for="name">Tên sản phẩm</label>
                                @error('name')
                                    <small class="text-capitalize text-danger font-ilatic">{{ $message }}</small>
                                @enderror
                                <input class="form-control" type="text" value="{{ old('name') }}" name="name" id="name">
                            </div>
                            <div class="form-group">
                                <label for="price">Giá <span class="text-muted font-italic">(số ghi liền không để ký tự
                                        '.' hoặc ',' ngăn cách vd: 100000)</span></label>
                                @error('price')
                                    <small class="text-capitalize text-danger font-ilatic">{{ $message }}</small>
                                @enderror
                                <input class="form-control" value="{{ old('price') }}" type="text" name="price" id="price">
                            </div>
                            <div class="form-group">
                                <label for="discount">Giá khuyến mãi <span class="text-muted font-italic">(Bắt buộc nhỏ hơn
                                        giá, có thể để trống)</span></label>
                                @error('discount')
                                    <small class="text-capitalize text-danger font-ilatic">{{ $message }}</small>
                                @enderror
                                <input class="form-control" value="{{ old('discount') }}" type="text" name="discount" id="discount">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="desc">Mô tả sản phẩm <span class="text-muted font-italic">(có thể bổ sung
                                        sau, thông số như GAM, Chip, Hệ Điều Hành,... sau mỗi thông số nên xuống hàng)</span></label>
                                @error('desc')
                                    <small class="text-capitalize text-danger font-ilatic">{{ $message }}</small>
                                @enderror
                                <textarea name="desc" class="form-control content" id="desc" cols="30" style="resize:none; overflow:auto; height:300px"
                                    rows="8">{{ old('desc') }}</textarea>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="file_thumb">Ảnh đại diện sản phẩm</label>
                        @error('file_thumb')
                            <small class="text-capitalize text-danger font-ilatic">{{ $message }}</small>
                        @enderror
                        <input type="file" name="file_thumb" id="file_thumb" class="form-control">
                    </div>
                    <div class="box_thumb">

                    </div>
                    <div class="form-group">
                        <label for="images">Danh sách ảnh chi tiết sản phẩm <span class="text-muted font-italic">(có thể
                                tải nhiều
                                ảnh)</span></label>
                        @error('images.*')
                            <small class="text-capitalize text-danger font-ilatic">{{ $message }}</small>
                        @enderror
                        <input type="file" name="images[]" multiple id="images" class="form-control">
                    </div>
                    <div class="box_images d-flex flex-wrap">

                    </div>
                    <div class="form-group">
                        <label for="content">Chi tiết sản phẩm <span class="text-muted font-italic">(có thể bổ sung
                                sau)</span></label>
                        @error('content')
                            <small class="text-capitalize text-danger font-ilatic">{{ $message }}</small>
                        @enderror
                        <textarea name="content" style="height: 800px" class="form-control content" id="intro" cols="30" rows="5">{{ old('content') }}</textarea>
                    </div>
                    <div class="form-group">
                        <label for="">Danh mục</label>
                        <select class="form-control" name="productCat_id" id="">
                            <option value="0">-- Chọn danh mục --</option>
                            @if (isset($data) && count($data) > 0)
                                @foreach ($data as $model)
                                    <option value="{{ $model->id }}">
                                        {{ str_repeat('-', $model->level) . ' ' . $model->name }}
                                    </option>
                                @endforeach
                            @endif
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Trạng thái</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="status" id="exampleRadios1" value="0"
                                checked>
                            <label class="form-check-label" for="exampleRadios1">
                                Chờ duyệt
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="status" id="exampleRadios2"
                                value="1">
                            <label class="form-check-label" for="exampleRadios2">
                                Công khai (còn hàng)
                            </label>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Thêm mới</button>
                </form>
            </div>
        </div>
    </div>
@endsection
