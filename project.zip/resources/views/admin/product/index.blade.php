@extends('layouts.admin')
@section('title', 'Danh sách sản phẩm')
@section('script')
    <script src="{{ asset('asset_admin/js/index.js') }}"></script>
@endsection
@section('content')
    <div id="content" class="container-fluid">
        @error('action')
            <div class="alert alert-danger text-capitalize font-italic">
                {{ $message }}
            </div>
        @enderror
        @error('id')
            <div class="alert alert-danger text-capitalize font-italic">
                {{ $message }}
            </div>
        @enderror
        @if (session('status'))
            <div class="alert alert-success text-capitalize font-italic">
                {{ session('status') }}
            </div>
        @endif
        <div class="card">
            <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
                <h5 class="m-0 ">Danh sách sản phẩm</h5>
                <div class="form-search form-inline">
                    <form action="#">
                        <input type="text" name="keyword" class="form-control form-search" placeholder="Tìm kiếm">
                        <input type="submit" name="btn-search" value="Tìm kiếm" class="btn btn-primary">
                    </form>
                </div>
            </div>
            <div class="card-body">
                <div class="analytic">
                    <a href="{{ request()->fullUrlWithQuery(['status' => '', 'keyword' => '']) }}" class="text-primary">Tất
                        cả
                        sản phẩm<span class="text-muted">({{ $count[0] }})</span></a>
                    <a href="{{ request()->fullUrlWithQuery(['status' => 'trash', 'keyword' => '']) }}"
                        class="text-primary">Thùng rác<span class="text-muted">({{ $count[1] }})</span></a>
                    {{-- <a href="" class="text-primary">Trạng thái 3<span class="text-muted">(20)</span></a> --}}
                </div>
                <form action="{{ route('admin.product.action') }}" method="post">
                    @csrf
                    @can('admin.product.edit')
                        <div class="form-action form-inline py-3">
                            <select class="form-control mr-1" name="action" id="">
                                <option value="0">Chọn</option>
                                @if (request()->status === 'trash')
                                    <option value="restore">Đưa trở lại</option>
                                    @can('admin.product.destroy')
                                        <option value="forceDelete">Xoá Vĩnh Viễn</option>
                                    @endcan
                                @else
                                    <option value="hide">Chờ duyệt (ẩn)</option>
                                    <option value="active">Còn hàng (hiển thị)</option>
                                    <option value="sold">Hết hàng (hiển thị)</option>
                                    @can('admin.product.destroy')
                                        <option value="delete">Xoá</option>
                                    @endcan
                                @endif
                            </select>
                            <input type="submit" name="btn-search" value="Áp dụng" class="btn btn-primary">
                        </div>
                    @endcan
                    <table class="table table-striped table-checkall">
                        <thead>
                            <tr>
                                @can('admin.product.edit')
                                    <th scope="col">
                                        <input name="checkall" type="checkbox">
                                    </th>
                                @endcan
                                <th scope="col">#</th>
                                <th scope="col">Ảnh</th>
                                <th scope="col">Tên sản phẩm</th>
                                <th scope="col">Giá</th>
                                <th scope="col">Danh mục</th>
                                {{-- <th scope="col">Ngày tạo</th> --}}
                                <th scope="col">Trạng thái</th>
                                @canany(['admin.product.edit', 'admin.page.destroy'])
                                    <th scope="col">Tác vụ</th>
                                @endcanany
                            </tr>
                        </thead>
                        <tbody>
                            @if (isset($data) && $data->count() > 0)
                                @php
                                    $t = 1;
                                @endphp
                                @foreach ($data as $model)
                                    <tr class="">
                                        @can('admin.product.edit')
                                            <td>
                                                <input type="checkbox" name="id[]" value="{{ $model->id }}">
                                            </td>
                                        @endcan
                                        <td>{{ $t++ }}</td>
                                        <td style="width:10%;height:auto"><img style="width:100%;height:auto"
                                                src="{{ asset('uploads/' . $model->thumb) }}" alt=""></td>
                                        <td style="width:30%"><a
                                                href="{{ route('admin.product.edit', ['product' => $model->id]) }}">{{ $model->name }}</a>
                                        </td>
                                        @if ($model->discount > 0)
                                            <td>
                                                <p>{{ number_format($model->discount, 0, '', '.') . ' đ' }}</p>
                                                <small class="text-muted" style="text-decoration:line-through">
                                                    {{ number_format($model->price, 0, '', '.') . ' đ' }}</small>
                                            </td>
                                        @else
                                            <td>{{ number_format($model->price, 0, '', '.') . ' đ' }}</td>
                                        @endif
                                        <td>{{ $model->productCat_name }}</td>
                                        {{-- <td>26:06:2020 14:00</td> --}}
                                        @if ($model->status === '1')
                                            <td><span class="badge badge-success">Còn Hàng</span></td>
                                        @elseif ($model->status === '2')
                                            <td><span class="badge badge-danger">Hết Hàng</span></td>
                                        @else
                                            <td><span class="badge badge-secondary">Chờ duyệt</span></td>
                                        @endif
                                        @canany(['admin.product.edit', 'admin.product.destroy'])
                                            <td>
                                                @can('admin.product.edit')
                                                    @if (request()->status === 'trash')
                                                        <a href="{{ route('admin.product.restore', ['id' => $model->id]) }}"
                                                            class="btn btn-success btn-sm rounded-0 text-white" type="button"
                                                            data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                                class="fas fa-trash-restore"></i></a>
                                                    @else
                                                        <a href="{{ route('admin.product.edit', ['product' => $model->id]) }}"
                                                            class="btn btn-success btn-sm rounded-0 text-white" type="button"
                                                            data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                                class="fa fa-edit"></i></a>
                                                    @endif
                                                @endcan
                                                @can('admin.product.destroy')
                                                    <a href="#" class="btn btn-danger btn-sm rounded-0 text-white delete"
                                                        type="button"
                                                        data-delete="{{ request()->status === 'trash' ? 'xoá vĩnh viễn sản phẩm' : 'xoá sản phẩm' }}"
                                                        data-toggle="tooltip"
                                                        data-route="{{ route('admin.product.destroy', ['product' => $model->id, 'forceDelete' => request()->status === 'trash' ? 'ok' : '']) }}"
                                                        data-placement="top" title="Delete"><i class="fa fa-trash"></i></a>
                                                @endcan
                                            </td>
                                        @endcanany
                                    </tr>
                                @endforeach
                            @else
                                <td colspan="8" class="text-capitalize text-danger text-italic">Không tìm thấy sản phẩm
                                </td>
                            @endif
                        </tbody>
                    </table>
                </form>
                <form action="" id="delete" method="post">
                    @csrf
                    @method('delete')
                </form>
                <nav aria-label="Page navigation example">
                    <div class="d-flex">
                        {{ $data->links() }}
                    </div>
                </nav>
            </div>
        </div>
    </div>
@endsection
