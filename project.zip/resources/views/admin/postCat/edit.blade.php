@extends('layouts.admin')
@section('title', 'Sửa danh mục bài viết')
@section('content')
    <div id="content" class="container-fluid">
        @if (session('status'))
            <div class="alert alert-success text-capitalize">
                {{ session('status') }}
            </div>
        @endif
        <div class="row">
            <div class="col-4">
                <div class="card">
                    <div class="card-header font-weight-bold">
                        Chỉnh sửa danh mục
                    </div>
                    <div class="card-body">
                        <form action="{{ route('admin.postCat.update', ['postCat' => $postCat->id]) }}" method="POST">
                            @csrf
                            @method('put')
                            <div class="form-group">
                                <label for="name">Tên danh mục</label>
                                <input class="form-control" type="text" name="name" value="{{ $postCat->name }}"
                                    id="name">
                                @error('name')
                                    <small class="text-capitalize text-danger">{{ $message }}</small>
                                @enderror
                            </div>
                            <div class="form-group">
                                <label for="">Danh mục cha</label>
                                <select class="form-control" name="parent_id" id="">
                                    <option value="0">Đặt làm danh mục cha</option>
                                    @if (count($data) > 0)
                                        @foreach ($data as $model)
                                            <option value="{{ $model->id }}"
                                                @if ($postCat->parent_id === $model->id) selected @endif>
                                                {{ str_repeat('-', $model->level) . ' ' . $model->name }}</option>
                                        @endforeach
                                    @endif
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Cập nhật</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-8">
                <div class="card">
                    <div class="card-header font-weight-bold">
                        Danh sách
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Tên danh mục bài viết</th>
                                    <th scope="col">Handle</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if (count($data) > 0)
                                    @php
                                        $t = 1;
                                    @endphp
                                    @foreach ($data as $model)
                                        <tr>
                                            <th scope="row">{{ $t++ }}</th>
                                            <td>{{ str_repeat('-', $model->level) . ' ' . $model->name }}</td>
                                            <td class="d-flex"><a
                                                    href="{{ route('admin.postCat.edit', ['postCat' => $model->id]) }}"
                                                    class="btn btn-success btn-sm rounded-0 mr-2" type="button"
                                                    data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                        class="fa fa-edit"></i></a>
                                                <form
                                                    action="{{ route('admin.postCat.destroy', ['postCat' => $model->id]) }}"
                                                    method="post">
                                                    @csrf
                                                    @method('delete')
                                                    <button class="btn btn-danger btn-sm rounded-0" type="submit"
                                                        data-toggle="tooltip" data-placement="top" title="Delete"><i
                                                            class="fa fa-trash"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
