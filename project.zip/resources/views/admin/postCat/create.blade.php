@extends('layouts.admin')
@section('title', 'Tạo danh mục bài viết')
@section('content')
    <div id="content" class="container-fluid">
        @if (session('status'))
            <div class="alert alert-success text-capitalize">
                {{ session('status') }}
            </div>
        @endif
        @if (session('fail'))
            <div class="alert alert-danger text-capitalize">
                {{ session('fail') }}
            </div>
        @endif
        <div class="row">
            <div class="col-4">
                <div class="card">
                    <div class="card-header font-weight-bold">
                        Thêm danh mục
                    </div>
                    <div class="card-body">
                        <form action="{{ route('admin.postCat.store') }}" method="POST">
                            @csrf
                            <div class="form-group">
                                <label for="name">Tên danh mục</label>
                                <input class="form-control" type="text" name="name" id="name">
                                @error('name')
                                    <small class="text-capitalize text-danger">{{ $message }}</small>
                                @enderror
                            </div>
                            <div class="form-group">
                                <label for="">Danh mục cha</label>
                                <select class="form-control" name="parent_id" id="">
                                    <option value="0">Đặt làm danh mục cha</option>
                                    @if (count($data) > 0)
                                        @foreach ($data as $model)
                                            <option value="{{ $model->id }}">
                                                {{ str_repeat('-', $model->level) . ' ' . $model->name }}</option>
                                        @endforeach
                                    @endif
                                </select>
                            </div>
                            {{-- <div class="form-group">
                                <label for="">Trạng thái</label>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1"
                                        value="option1" checked>
                                    <label class="form-check-label" for="exampleRadios1">
                                        Chờ duyệt
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2"
                                        value="option2">
                                    <label class="form-check-label" for="exampleRadios2">
                                        Công khai
                                    </label>
                                </div>
                            </div> --}}
                            <button type="submit" class="btn btn-primary">Thêm mới</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-8">
                <div class="card">
                    <div class="card-header font-weight-bold">
                        Danh sách
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Tên danh mục bài viết</th>
                                    <th scope="col">Handle</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if (count($data) > 0)
                                    @php
                                        $t = 1;
                                    @endphp
                                    @foreach ($data as $model)
                                        <tr>
                                            <th scope="row">{{ $t++ }}</th>
                                            <td>{{ str_repeat('-', $model->level) . ' ' . $model->name }}</td>
                                            <td class="d-flex"><a
                                                    href="{{ route('admin.postCat.edit', ['postCat' => $model->id]) }}"
                                                    class="btn btn-success btn-sm rounded-0 mr-2" type="button"
                                                    data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                        class="fa fa-edit"></i></a>
                                                <form
                                                    action="{{ route('admin.postCat.destroy', ['postCat' => $model->id]) }}"
                                                    method="post">
                                                    @csrf
                                                    @method('delete')
                                                    <button class="btn btn-danger btn-sm rounded-0" type="submit"
                                                        data-toggle="tooltip" data-placement="top" title="Delete"><i
                                                            class="fa fa-trash"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
