@extends('layouts.admin')
@section('title', 'danh sách bài viết')
@section('script')
    <script src="{{ asset('asset_admin/js/index.js') }}"></script>
@endsection
@section('content')
    <div id="content" class="container-fluid">
        @error('action')
            <div class="alert alert-danger text-capitalize font-italic">
                {{ $message }}
            </div>
        @enderror
        @error('id')
            <div class="alert alert-danger text-capitalize font-italic">
                {{ $message }}
            </div>
        @enderror
        @if (session('status'))
            <div class="alert alert-success text-capitalize font-italic">
                {{ session('status') }}
            </div>
        @endif
        <div class="card">
            <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
                <h5 class="m-0 ">Danh sách bài viết</h5>
                <div class="form-search form-inline">
                    <form action="#">
                        <input type="text" name="keyword" class="form-control form-search" placeholder="Tìm kiếm">
                        <input type="hidden" name="status" value="{{ request()->status }}">
                        <input type="submit" name="btn-search" value="Tìm kiếm" class="btn btn-primary">
                    </form>
                </div>
            </div>
            <div class="card-body">
                <div class="analytic">
                    <a href="{{ request()->fullUrlWithQuery(['status' => '', 'keyword' => '']) }}" class="text-primary">
                        Hiện hành<span class="text-muted">({{ $count[0] }})</span></a>
                    <a href="{{ request()->fullUrlWithQuery(['status' => 'trash', 'keyword' => '']) }}"
                        class="text-primary">Thùng rác<span class="text-muted">({{ $count[1] }})</span></a>
                </div>
                <form action="{{ route('admin.post.action') }}" method="post">
                    @csrf
                    @can('admin.post.edit')
                        <div class="form-action form-inline py-3">
                            <select class="form-control mr-1" name="action" id="">
                                <option value="0">-- Chọn Thao tác --</option>
                                @if (request()->status === 'trash')
                                    <option value="restore">Đưa trở lại</option>
                                    <option value="forceDelete">Xoá vĩnh viễn</option>
                                @else
                                    <option value="active">Công Khai</option>
                                    <option value="hide">Chờ Duyệt</option>
                                    <option value="delete">Xoá</option>
                                @endif
                            </select>
                            <input type="submit" name="btn-search" value="Áp dụng" class="btn btn-primary">
                        </div>
                    @endcan
                    <div class="table-responsive">
                        <table class="table table-striped table-checkall">
                            <thead>
                                <tr>
                                    @can('admin.post.edit')
                                        <th scope="col">
                                            <input name="checkall" type="checkbox">
                                        </th>
                                    @endcan
                                    <th scope="col">#</th>
                                    <th scope="col">Ảnh</th>
                                    <th scope="col">Tiêu đề</th>
                                    <th scope="col">Danh mục</th>
                                    <th scope="col">Trạng Thái</th>
                                    <th scope="col">Ngày tạo</th>
                                    @canany(['admin.post.edit', 'admin.post.destroy'])
                                        <th scope="col">Tác vụ</th>
                                    @endcanany
                                </tr>
                            </thead>
                            <tbody>
                                @if ($data->count() > 0)
                                    @php
                                        $t = 1;
                                    @endphp
                                    @foreach ($data as $model)
                                        <tr>
                                            @can('admin.post.edit')
                                                <td>
                                                    <input type="checkbox" name="id[]" value="{{ $model->id }}">
                                                </td>
                                            @endcan
                                            <td scope="row">{{ $t++ }}</td>
                                            <td style="width:15%;height:auto"><img style="width:100%"
                                                    src="{{ asset('uploads/' . $model->thumb) }}" alt=""></td>
                                            <td style="width:30%"><a href="">{{ $model->title }}</a>
                                            </td>
                                            <td>{{ $model->postCat->name }}</td>
                                            <td>
                                                @if ($model->status === '0')
                                                    <span class="text-muted">Chờ Duyệt</span>
                                                @else
                                                    <span class="text-success">Công Khai</span>
                                                @endif
                                            </td>
                                            <td>{{ $model->created_at }}</td>
                                            @canany(['admin.post.edit', 'admin.post.destroy'])
                                                <td>
                                                    @can('admin.post.edit')
                                                        @if (request()->status === 'trash')
                                                            <a href="{{ route('admin.post.restore', ['id' => $model->id]) }}"
                                                                class="btn btn-success btn-sm rounded-0" type="button"
                                                                data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                                    class="fas fa-trash-restore"></i></a>
                                                        @else
                                                            <a href="{{ route('admin.post.edit', ['post' => $model->id]) }}"
                                                                class="btn btn-success btn-sm rounded-0" type="button"
                                                                data-toggle="tooltip" data-placement="top" title="Edit"><i
                                                                    class="fa fa-edit"></i></a>
                                                        @endif
                                                    @endcan
                                                    @can('admin.post.destroy')
                                                        <a href="#" class="btn btn-danger btn-sm rounded-0 delete"
                                                            data-delete="{{ request()->status === 'trash' ? 'xoá vĩnh viễn bài viết' : 'xoá bài viết' }}"
                                                            data-route="{{ route('admin.post.destroy', ['post' => $model->id, 'forceDelete' => request()->status === 'trash' ? 'ok' : '']) }}"
                                                            type="button" data-toggle="tooltip" data-placement="top"
                                                            title="Delete"><i class="fa fa-trash"></i></a>
                                                    @endcan

                                                </td>
                                            @endcanany
                                        </tr>
                                    @endforeach
                                @else
                                    <td colspan="7" class="text-danger font-italic">Không tìm thấy bài viết</td>
                                @endif
                            </tbody>
                        </table>
                    </div>
                </form>
                <form action="" method="post" id="delete">
                    @csrf
                    @method('delete')
                </form>
                <nav aria-label="Page navigation example">
                    <div class="d-flex">
                        {{ $data->links() }}
                    </div>
                </nav>
            </div>
        </div>
    </div>
@endsection
