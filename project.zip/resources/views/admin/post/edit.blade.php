@extends('layouts.admin')
@section('title', 'Chỉnh sửa bài viết')
@section('script')
    <script src="{{ asset('asset_admin/js/page_post_thumb.js') }}"></script>
@endsection
@section('content')
    <div id="content" class="container-fluid">
        <div class="card">
            <div class="card-header font-weight-bold">
                Chỉnh sửa bài viết
            </div>
            <div class="card-body">
                <form action="{{ route('admin.post.update',['post'=>$post->id]) }}" method="post" enctype="multipart/form-data">
                    @csrf
                    @method('put')
                    <div class="form-group">
                        <label for="title">Tiêu đề bài viết</label>
                        <input class="form-control" value="{{ $post->title }}" type="text" name="title"
                            id="title">
                        @error('title')
                            <small class="text-danger text-capitalize font-italic">{{ $message }}</small>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="file_thumb" class="">Ảnh đại diện trang</label>
                        <input type="file" name="file_thumb" class="form-control file_thumb" id="file_thumb">
                        @error('file_thumb')
                            <small class="text-danger text-capitalize font-italic">{{ $message }}</small>
                        @enderror
                    </div>
                    <div class="box_thumb" class="d-flex flex-wrap">
                        <img src="{{ asset('uploads/' . $post->thumb) }}" class="thumb" alt="">
                    </div>
                    <div class="form-group">
                        <label for="">Mô tả ngắn</label>
                        <textarea name="desc" class="form-control" id="" cols="30" rows="10">{{ $post->desc }}</textarea>
                    </div>
                     
                    <div class="form-group">
                        <label for="content">Nội dung bài viết</label>
                        @error('content')
                            <small class="text-danger text-capitalize font-italic">{{ $message }}</small>
                        @enderror
                        <textarea name="content" class="form-control content" style="height: 100rem" id="content" cols="30" rows="5">
                            {!! $post->content !!}
                        </textarea>
                    </div>
                    <div class="form-group">
                        <label for="">Danh mục bài viết</label>
                        <select class="form-control" name="postCat_id">
                            <option value="0">-- Chọn danh mục bài viết --</option>
                            @if (count($data) > 0)
                                @foreach ($data as $model)
                                    <option value="{{ $model->id }}"
                                        @if ($model->id === $post->postCat_id) @selected(true) @endif>
                                        {{ str_repeat('-', $model->level) . ' ' . $model->name }}</option>
                                @endforeach
                            @endif
                        </select>
                        @error('postCat_id')
                            <small class="text-danger text-capitalize font-italic">{{ $message }}</small>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="">Trạng thái</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="status" value="0"
                                @if ($post->status === '0') @checked(true) @endif id="exampleRadios1" value="option1"
                                checked>
                            <label class="form-check-label" for="exampleRadios1">
                                Chờ duyệt
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="status" value="1"
                                @if ($post->status === '1') @checked(true) @endif id="exampleRadios2" value="option2">
                            <label class="form-check-label" for="exampleRadios2">
                                Công khai
                            </label>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Cập Nhật</button>
                </form>
            </div>
        </div>
    </div>
@endsection
