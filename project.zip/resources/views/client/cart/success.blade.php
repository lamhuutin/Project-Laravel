@extends('layouts.client_cart')
@section('title', 'Mua hàng thành công')
@section('content')
    <div id="main-content-wp" class="cart-page">
        <div class="section" id="breadcrumb-wp">
            <div class="wp-inner">
                <div class="section-detail">
                    <ul class="list-item clearfix">
                        <li>
                            <a href="?page=home" title="">Trang chủ</a>
                        </li>
                        <li>
                            <a href="" title="">Đặt Hàng Thành Công</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div></div>
        <div id="wrapper" class="wp-inner clearfix">
            @if (count($order_detail['list_order']) > 0)
                <p style="color:#2ecc71;text-transform:capitalize;font-style:italic;font-size:20px; padding:10px">Chúc Mừng
                    Bạn Đã Đặt Hàng Thành Công, Chúng Tôi Đã Gửi Thông tin Đơn Hàng Vào Email Của bạn!</p>
                <div style="margin: 20px 0;">
                    <h1 style="font-weight:bold; color:#0984e3 ; font-size:20px">Thông tin Khách Hàng</h1>
                    <p><span style="font-weight:bold; color:#999 ; font-size:18px">Tên</span>: {{ $order_detail['name'] }} </p>
                    <p><span style="font-weight:bold; color:#999 ; font-size:18px">Email</span>: {{ $order_detail['email'] }}</p>
                    <p><span style="font-weight:bold; color:#999 ; font-size:18px">Phone</span>: {{ $order_detail['phone'] }}</p>
                    <p><span style="font-weight:bold; color:#999 ; font-size:18px">Địa chỉ</span>: {{ $order_detail['address_shipping'] }}</p>
                </div>
                <div class="section" id="info-cart-wp">
                    <h1 style="font-weight:bold; color:#0984e3 ; font-size:18px; margin-bottom:10px">Chi Tiết Đơn Hàng: </h1>
                    <div class="section-detail table-responsive">
                        <form action="{{ route('checkout') }}" method="get">
                            <table class="table">
                                <thead>
                                    <tr>
                                        {{-- <td>Mã sản phẩm</td> --}}
                                        {{-- <td><input type="checkbox" name="check" id="checkAll"></td> --}}
                                        <td>Ảnh sản phẩm</td>
                                        <td>Tên sản phẩm</td>
                                        <td>Giá sản phẩm</td>
                                        <td>Số lượng</td>
                                        <td colspan="2">Thành tiền</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($order_detail['list_order'] as $model)
                                        <tr>
                                            <td>
                                                <a href="{{ route('productDetail', ['productCatSlug' => Str::slug($model->options->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id]) }}"
                                                    title="" class="thumb">
                                                    <img src="{{ asset('uploads/' . $model->options->thumb) }}"
                                                        alt="">
                                                </a>
                                            </td>
                                            <td>
                                                <a href="{{ route('productDetail', ['productCatSlug' => Str::slug($model->options->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id]) }}"
                                                    title="" class="name-product">{{ $model->name }}</a>
                                            </td>
                                            <td>
                                                @if ($model->options->discount > 0)
                                                    <div class="price">
                                                        <span class="new"
                                                            style="color:black">{{ number_format($model->options->discount, 0, ',', '.') . ' đ' }}</span><br>
                                                        <span class="old"
                                                            style="color:#999; text-decoration:line-through">{{ number_format($model->options->price, 0, ',', '.') . ' đ' }}</span>
                                                    </div>
                                                @else
                                                    <div class="price">
                                                        <span
                                                            class="new">{{ number_format($model->options->price, 0, ',', '.') . ' đ' }}</span>
                                                    </div>
                                                @endif
                                            </td>
                                            <td>

                                                {{ $model->qty }}
                                            </td>
                                            <td id="total-{{ $model->rowId }}">
                                                {{ number_format($model->total, 0, ',', '.') . ' đ' }}</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="7">
                                            <div class="clearfix">
                                                <p style="margin: 10px 0;">Tạm tính: {{ number_format($order_detail['total_price'],0,',','.'). ' đ' }}</p>
                                                <p>Phí Vận Chuyển: 30.000 đ</p>
                                                <p id="total-price">Tổng giá:
                                                    <span>{{ number_format($order_detail['total_price'] + 30000, 0, ',', '.') . ' đ' }}</span>
                                                </p>
                                            </div>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </form>
                    </div>
                </div>
            @else
            @endif
        </div>
    </div>
@endsection
@section('script')
    <script>
        $(document).ready(function() {
            $("#checkAll").click(function() {
                $('input:checkbox').not(this).prop('checked', this.checked);
            });

            $('.plus').click(function() {
                let input_qty = $(this).prev();
                let value = parseInt(input_qty.val());
                value++;
                input_qty.val(value);
                let id = $(this).attr('data-id');
                let rowId = $(this).attr('data-rowId');
                $.ajax({
                    url: "{{ route('updateCart') }}?rowId=" + rowId + "&qty=" + input_qty.val(),
                    method: 'get',
                    dataType: 'json',
                    success: function(data) {
                        $("td#total-" + rowId).text(data.total);
                        $('p#total-price').html(`<span>${data.total_price}</span>`);
                        $('p#total_price_cart').text(data.total_price);
                        $('span#cart_qty_' + id).text(value);
                        $('p#total_qty').html(
                            `<span>Có ${data.total_qty} sản phẩm trong giỏ hàng</span>`);
                        $('span#num').text(data.total_qty);
                    },
                    error: function(xhr, ajaxOptions, thrownError) {
                        alert(xhr.status);
                        alert(thrownError);
                    }
                })
            });
            $('.minus').click(function() {
                let input_qty = $(this).next();
                let value = parseInt(input_qty.val());
                if (value > 1) {
                    value--;
                    input_qty.val(value);
                    let id = $(this).attr('data-id');
                    let rowId = $(this).attr('data-rowId');
                    $.ajax({
                        url: "{{ route('updateCart') }}?rowId=" + rowId + "&qty=" + input_qty
                            .val(),
                        method: 'get',
                        dataType: 'json',
                        success: function(data) {
                            $("td#total-" + rowId).text(data.total);
                            $('p#total-price').html(`<span>${data.total_price}</span>`);
                            $('p#total_price_cart').text(data.total_price);
                            $('span#cart_qty_' + id).text(value);
                            $('p#total_qty').html(
                                `<span>Có ${data.total_qty} sản phẩm trong giỏ hàng</span>`);
                            $('span#num').text(data.total_qty);
                        },
                        error: function(xhr, ajaxOptions, thrownError) {
                            alert(xhr.status);
                            alert(thrownError);
                        }
                    })
                }
            });
        })
    </script>
@endsection
