@extends('layouts.client_cart')
@section('title', 'Thông tin khách hàng')
@section('content')
    <div id="main-content-wp" class="checkout-page">
        <div class="section" id="breadcrumb-wp">
            <div class="wp-inner">
                <div class="section-detail">
                    <ul class="list-item clearfix">
                        <li>
                            <a href="?page=home" title="">Trang chủ</a>
                        </li>
                        <li>
                            <a href="" title="">Thông Tin và Địa Chỉ Giao Hàng</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div>
            <div class="section-detail" style="max-width:720px; margin:0 auto">
                <div class="section-head" style="margin-bottom: 10px">
                    <h1 class="section-title" style="font-size:25px">Thông Tin và Địa Chỉ Giao Hàng</h1>
                </div>
                <form method="POST" action="{{ route('storeInfo') }}" id="form-info" name="form-checkout">
                    @csrf
                    <div class="form-row clearfix">
                        <div class="form-col">
                            @error('name')
                                <p class="error">{{ $message }}</p>
                            @enderror
                            <label for="fullname">Họ tên</label>
                            <input type="text" style="width:100%" name="name" id="fullname">
                        </div>
                    </div>
                    <div class="form-col">
                        @error('email')
                            <p class="error">{{ $message }}</p>
                        @enderror
                        <label for="email">Email</label>
                        <input type="email" style="width:100%" name="email" id="email">
                    </div>
                    <div class="form-col">
                        @error('phone')
                            <p class="error">{{ $message }}</p>
                        @enderror
                        <label for="phone">Số điện thoại</label>
                        <input type="tel" style="width:100%" name="phone" id="phone">
                    </div>
                    <div class="form-row clearfix">
                        <div class="form-col">
                            <div class="form-group">
                                @error('province')
                                    <p class="error">{{ $message }}</p>
                                @enderror
                                <label for="province">Tỉnh/Thành phố</label>
                                <select id="province" name="province" class="form-control address"
                                    data-route="{{ route('changeDistrict') }}">
                                    <option value="0">Chọn một tỉnh</option>
                                    <!-- populate options with data from your database or API -->
                                    @if (count($province) > 0)
                                        @foreach ($province as $model)
                                            <option value="{{ $model->province_id }}">{{ $model->name }}</option>
                                        @endforeach
                                    @endif
                                </select>
                            </div>
                            <div class="form-group">
                                @error('district')
                                    <p class="error">{{ $message }}</p>
                                @enderror
                                <label for="district">Quận/Huyện</label>
                                <select id="district" name="district" class="form-control address"
                                    data-route="{{ route('changeWards') }}">
                                    <option value="0">Chọn một quận/huyện</option>
                                </select>
                            </div>
                            <div class="form-group">
                                @error('wards')
                                    <p class="error">{{ $message }}</p>
                                @enderror
                                <label for="wards">Xã/Phường/Thị Trấn</label>
                                <select id="wards" name="wards" class="form-control address">
                                    <option value="0">Chọn một xã/phường/thị trấn</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-col">
                            <label for="notes">Ghi chú <small style="font-size: 15px">(Địa chỉ cụ thể như tên đường, số
                                    nhà,...)</small></label>
                            <textarea name="note" style="width:100%;resize:none;overflow:auto" rows="8"></textarea>
                        </div>
                    </div>
                    <div class="place-order-wp clearfix">
                        <input type="submit" id="order-now" value="Xác Nhận">
                    </div>
                </form>
            </div>
            {{-- <div class="section" id="order-review-wp">
                <div class="section-head">
                    <h1 class="section-title">Thông tin đơn hàng</h1>
                </div>
                <div class="section-detail">
                    <table class="shop-table">
                        <thead>
                            <th>Ảnh</th>
                            <th style="text-align:center">Sản phẩm</th>
                            <th>Số lượng</th>
                            <th>Tổng</th>
                        </thead>
                        <tbody>
                            @foreach ($data as $model)
                                <tr class="cart-item">
                                    <td style="width:15%; padding:10px"><img
                                            src="{{ asset('uploads/' . $model->options->thumb) }}"
                                            style="width:100%;height:auto" alt=""></td>
                                    <td class="product-name" style="text-align:center">{{ $model->name }}</td>
                                    <td>
                                        <a title="" data-rowId="{{ $model->rowId }}" data-id="{{ $model->id }}"
                                            class="minus"><i class="fa fa-minus"></i></a>
                                        <input style="width:20px" type="text" name="num-order"
                                            value="{{ $model->qty }}" class="num-order">
                                        <a title="" data-rowId="{{ $model->rowId }}" data-id="{{ $model->id }}"
                                            class="plus"><i class="fa fa-plus"></i></a>
                                    </td>
                                    <td class="product-total" id="total-{{ $model->rowId }}">
                                        {{ number_format($model->total, 0, ',', '.') . ' đ' }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                        <tfoot>
                            <tr class="order-total" data-id="{{ json_encode($list_id) }}"
                                data-route="{{ route('updateCheckout') }}">
                                <td>Tổng đơn hàng:</td>
                                <td>
                                    <p class="total-price" id="total-order" style="color:#0984e3">
                                        {{ number_format($total, 0, ',', '.') . ' đ' }}</p>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div> --}}
        </div>
    </div>
@endsection
@section('script')
    <script src="{{ asset('client/js/checkout.js') }}"></script>
@endsection
