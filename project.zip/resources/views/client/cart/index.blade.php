@extends('layouts.client_cart')
@section('title', 'Giỏ Hàng')
@section('content')
    <div id="main-content-wp" class="cart-page">
        <div class="section" id="breadcrumb-wp">
            <div class="wp-inner">
                <div class="section-detail">
                    @if (session('status'))
                        <span
                            style="display:inline-block; font-size:20px; padding:5px; text-transform:capitalize; font-style:italic; color: red">
                            {{ session('status') }}
                        </span>
                    @endif
                    <ul class="list-item clearfix">
                        <li>
                            <a href="?page=home" title="">Trang chủ</a>
                        </li>
                        <li>
                            <a href="" title="">Giỏ hàng</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div id="wrapper" class="wp-inner clearfix">
            @if (Cart::count() > 0)
                <div class="section" id="info-cart-wp">
                    <div class="section-detail table-responsive">
                        <form action="{{ route('checkout') }}" method="get">
                            <table class="table">
                                <thead>
                                    <tr>
                                        {{-- <td>Mã sản phẩm</td> --}}
                                        <td><input type="checkbox" name="check" id="checkAll"></td>
                                        <td>Ảnh sản phẩm</td>
                                        <td>Tên sản phẩm</td>
                                        <td>Giá sản phẩm</td>
                                        <td>Số lượng</td>
                                        <td colspan="2">Thành tiền</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach (Cart::content() as $model)
                                        <tr>
                                            {{-- <td>HCA00031</td> --}}
                                            <td><input type="checkbox" name="id[]" value="{{ $model->id }}"
                                                    id="{{ $model->rowId }}"></td>
                                            <td>
                                                <a href="{{ route('productDetail', ['productCatSlug' => Str::slug($model->options->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id]) }}"
                                                    title="" class="thumb">
                                                    <img src="{{ asset('uploads/' . $model->options->thumb) }}"
                                                        alt="">
                                                </a>
                                            </td>
                                            <td>
                                                <a href="{{ route('productDetail', ['productCatSlug' => Str::slug($model->options->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id]) }}"
                                                    title="" class="name-product">{{ $model->name }}</a>
                                            </td>
                                            <td>
                                                @if ($model->options->discount > 0)
                                                    <div class="price">
                                                        <span class="new"
                                                            style="color:black">{{ number_format($model->options->discount, 0, ',', '.') . ' đ' }}</span><br>
                                                        <span class="old"
                                                            style="color:#999; text-decoration:line-through">{{ number_format($model->options->price, 0, ',', '.') . ' đ' }}</span>
                                                    </div>
                                                @else
                                                    <div class="price">
                                                        <span
                                                            class="new">{{ number_format($model->options->price, 0, ',', '.') . ' đ' }}</span>
                                                    </div>
                                                @endif
                                            </td>
                                            <td>
                                                <a title="" data-rowId="{{ $model->rowId }}"
                                                    data-id="{{ $model->id }}" class="minus"><i
                                                        class="fa fa-minus"></i></a>
                                                <input type="text" name="num-order" value="{{ $model->qty }}"
                                                    class="num-order">
                                                <a title="" data-rowId="{{ $model->rowId }}"
                                                    data-id="{{ $model->id }}" class="plus"><i
                                                        class="fa fa-plus"></i></a>
                                            </td>
                                            <td id="total-{{ $model->rowId }}">
                                                {{ number_format($model->total, 0, ',', '.') . ' đ' }}</td>
                                            <td>
                                                <a href="{{ route('destroyCart', ['rowId' => $model->rowId]) }}"
                                                    title="" class="del-product"><i class="fa fa-trash-o"
                                                        style="font-size: 20px"></i></a>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                                <tfoot>
                                    <tr>

                                        <td colspan="7">
                                            <div class="clearfix">
                                                <p id="total-price" class="">Tổng giá:
                                                    <span>{{ Cart::total() . ' đ' }}</span>
                                                </p>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="7">
                                            <div class="clearfix">
                                                <div class="">
                                                    <button type="submit" title="" id="checkout-cart">Thanh
                                                        toán</button>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </form>
                    </div>
                </div>
                <div class="section" id="action-cart-wp">
                    <div class="section-detail">
                        <a href="?page=home" title="" id="buy-more">Mua tiếp</a><br />
                        <a href="{{ route('destroyCart', ['destroyAll' => 'ok']) }}" title="" id="delete-cart">Xóa
                            giỏ
                            hàng</a>
                    </div>
                </div>
            @else
                <p style="color:red; text-transform:capitalize; font-style: italic">Chưa có sản phẩm trong giỏ hàng, quay
                    lại <a style="font-size: 20px" href="{{ route('home.page') }}">Trang chủ</a> để mua sắm </p>
            @endif
        </div>
    </div>
@endsection
@section('script')
    <script>
        $(document).ready(function() {
            $("#checkAll").click(function() {
                $('input:checkbox').not(this).prop('checked', this.checked);
            });

            $('.plus').click(function() {
                let input_qty = $(this).prev();
                let value = parseInt(input_qty.val());
                value++;
                input_qty.val(value);
                let id = $(this).attr('data-id');
                let rowId = $(this).attr('data-rowId');
                $.ajax({
                    url: "{{ route('updateCart') }}?rowId=" + rowId + "&qty=" + input_qty.val(),
                    method: 'get',
                    dataType: 'json',
                    success: function(data) {
                        $("td#total-" + rowId).text(data.total);
                        $('p#total-price').html(`<span>${data.total_price}</span>`);
                        $('p#total_price_cart').text(data.total_price);
                        $('span#cart_qty_' + id).text(value);
                        $('p#total_qty').html(
                            `<span>Có ${data.total_qty} sản phẩm trong giỏ hàng</span>`);
                        $('span#num').text(data.total_qty);
                    },
                    error: function(xhr, ajaxOptions, thrownError) {
                        alert(xhr.status);
                        alert(thrownError);
                    }
                })
            });
            $('.minus').click(function() {
                let input_qty = $(this).next();
                let value = parseInt(input_qty.val());
                if (value > 1) {
                    value--;
                    input_qty.val(value);
                    let id = $(this).attr('data-id');
                    let rowId = $(this).attr('data-rowId');
                    $.ajax({
                        url: "{{ route('updateCart') }}?rowId=" + rowId + "&qty=" + input_qty
                            .val(),
                        method: 'get',
                        dataType: 'json',
                        success: function(data) {
                            $("td#total-" + rowId).text(data.total);
                            $('p#total-price').html(`<span>${data.total_price}</span>`);
                            $('p#total_price_cart').text(data.total_price);
                            $('span#cart_qty_' + id).text(value);
                            $('p#total_qty').html(
                                `<span>Có ${data.total_qty} sản phẩm trong giỏ hàng</span>`);
                            $('span#num').text(data.total_qty);
                        },
                        error: function(xhr, ajaxOptions, thrownError) {
                            alert(xhr.status);
                            alert(thrownError);
                        }
                    })
                }
            });
        })
    </script>
@endsection
