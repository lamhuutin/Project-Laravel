@extends('layouts.client_cart')
@section('title', 'Thanh toán')
@section('content')
    <div id="main-content-wp" class="checkout-page">
        <div class="section" id="breadcrumb-wp">
            <div class="wp-inner">
                <div class="section-detail">
                    <ul class="list-item clearfix">
                        <li>
                            <a href="?page=home" title="">Trang chủ</a>
                        </li>
                        <li>
                            <a href="" title="">Thanh toán</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div id="wrapper" class="wp-inner clearfix">
            @if (session('fail'))
                <p style="color: red; font-style:italic; text-trasform: capitalize; font-size:25px; padding:20px">
                    {{ session('fail') }}</p>
            @endif
            <div class="section" id="customer-info-wp">
                <div class="section-head">
                    <h1 class="section-title">Thông tin khách hàng</h1>
                </div>
                <div class="section-detail">
                    <form method="POST" action="{{ route('cod-payment') }}" data-route-cod="{{ route('cod-payment') }}"
                        data-route-momo="{{ route('momo-payment') }}" data-route-vnpay="{{ route('vnpay-payment') }}"
                        id="form-pay" name="form-checkout">
                        @csrf
                        <div class="form-row clearfix">
                            <div class="form-col fl-left">
                                @error('name')
                                    <p class="error">{{ $message }}</p>
                                @enderror
                                <label for="fullname">Họ tên</label>
                                <input type="text" name="name"
                                    value="@if (isset($info_customer->name)){{ $info_customer->name }} @endif"
                                    id="fullname">
                            </div>
                            <div class="form-col fl-right">
                                @error('email')
                                    <p class="error">{{ $message }}</p>
                                @enderror
                                <label for="email">Email</label>
                                <input type="email" name="email"
                                    value="@if (isset($info_customer->email)){{ $info_customer->email }} @endif"
                                    id="email">
                            </div>
                        </div>
                        <div class="form-row clearfix">
                            <div class="form-col fl-left">
                                <label for="">Địa Chỉ</label>
                                <div class="form-group">
                                    @error('province')
                                        <p class="error">{{ $message }}</p>
                                    @enderror
                                    <label for="province">Tỉnh/Thành phố</label>
                                    <select id="province" name="province" class="form-control address"
                                        data-route="{{ route('changeDistrict') }}">
                                        <option value="0">Chọn một tỉnh</option>
                                        <!-- populate options with data from your database or API -->
                                        @if (count($province) > 0)
                                            @foreach ($province as $model)
                                                <option value="{{ $model->province_id }}"
                                                    @if (isset($info_customer) && $info_customer->province == $model->name) @selected(true) @endif>
                                                    {{ $model->name }}</option>
                                            @endforeach
                                        @endif
                                    </select>
                                </div>
                                <div class="form-group">
                                    @error('district')
                                        <p class="error">{{ $message }}</p>
                                    @enderror
                                    <label for="district">Quận/Huyện</label>
                                    <select id="district" name="district" class="form-control address"
                                        data-route="{{ route('changeWards') }}">
                                        @if (isset($district))
                                            @foreach ($district as $model)
                                                <option value="{{ $model->district_id }}"
                                                    @if (isset($info_customer) && $model->name == $info_customer->district) @selected(true) @endif>
                                                    {{ $model->name }}</option>
                                            @endforeach
                                        @else
                                            <option value="0">Chọn một quận/huyện</option>
                                        @endif
                                    </select>
                                </div>
                                <div class="form-group">
                                    @error('wards')
                                        <p class="error">{{ $message }}</p>
                                    @enderror
                                    <label for="wards">Phường/Xã</label>
                                    <select id="wards" name="wards" class="form-control address">
                                        @if (isset($wards))
                                            @foreach ($wards as $model)
                                                <option value="{{ $model->wards_id }}"
                                                    @if (isset($info_customer) && $model->name == $info_customer->wards) @selected(true) @endif>
                                                    {{ $model->name }}</option>
                                            @endforeach
                                        @else
                                            <option value="0">Chọn một xã</option>
                                        @endif
                                    </select>
                                </div>
                            </div>
                            <div class="form-col fl-right">
                                @error('phone')
                                    <p class="error">{{ $message }}</p>
                                @enderror
                                <label for="phone">Số điện thoại</label>
                                <input type="tel" name="phone"
                                    value="@if (isset($info_customer->phone)){{ $info_customer->phone }} @endif"
                                    id="phone">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="form-col">
                                <label for="notes">Ghi chú</label>
                                <textarea name="note" class="form-control" style="width:100%;resize:none; overflow:auto">
@if (isset($info_customer->note))
{{ $info_customer->note }}
@endif
</textarea>
                            </div>
                        </div>
                        <div class="form-group" style="margin-top:10px">
                            @error('payment_method')
                                <p class="error">{{ $message }}</p>
                            @enderror
                            <select style="text-align:center" id="payment_method" name="payment_method"
                                class="form-control address">
                                <option value="0">Chọn Phương Thức Thanh Toán</option>
                                <option value="cod-payment">Thanh Toán Khi Nhận Hàng</option>
                                <option value="vnpay-payment">Thanh Toán Qua VNPAY</option>
                                <option value="momo-payment">Thanh Toán Qua Momo (Hỗ trợ thanh toán tối đa 50 triệu)
                                </option>
                            </select>
                        </div>
                        <div class="place-order-wp clearfix">
                            <input type="hidden" name="total_price" value="{{ $total }}" id="payment-vnpay">
                            <input type="hidden" name="list_id" value="{{ json_encode($list_id) }}">
                            <input type="submit" id="order-now" name="redirect" value="Đặt hàng">
                        </div>
                    </form>
                </div>
            </div>
            <div class="section" id="order-review-wp">
                <div class="section-head">
                    <h1 class="section-title">Thông tin đơn hàng</h1>
                </div>
                <div class="section-detail">
                    <table class="shop-table">
                        <thead>
                            <th>Ảnh</th>
                            <th style="text-align:center">Sản phẩm</th>
                            <th>Số lượng</th>
                            <th>Tổng</th>
                        </thead>
                        <tbody>
                            @foreach ($data as $model)
                                <tr class="cart-item">
                                    <td style="width:15%; padding:10px"><img
                                            src="{{ asset('uploads/' . $model->options->thumb) }}"
                                            style="width:100%;height:auto" alt=""></td>
                                    <td class="product-name" style="text-align:center">{{ $model->name }}</td>
                                    <td id="number-order" style="width:20%">
                                        <a title="" data-rowId="{{ $model->rowId }}"
                                            data-id="{{ $model->id }}" class="minus"><i style="line-height:25px"
                                                class="fa fa-minus"></i></a>
                                        <input style="width:20px;text-align: center" type="text" name="num-order"
                                            value="{{ $model->qty }}" class="num-order">
                                        <a title="" data-rowId="{{ $model->rowId }}"
                                            data-id="{{ $model->id }}" class="plus"><i style="line-height:25px"
                                                class="fa fa-plus"></i></a>
                                    </td>
                                    <td class="product-total" id="total-{{ $model->rowId }}">
                                        {{ number_format($model->total, 0, ',', '.') . ' đ' }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                        <tfoot>
                            <tr class="order-total" data-id="{{ json_encode($list_id) }}"
                                data-route="{{ route('updateCheckout') }}">
                                <td>Tổng đơn hàng:</td>
                                <td>
                                    <p class="total-price" id="total-order" style="color:#0984e3">
                                        {{ number_format($total, 0, ',', '.') . ' đ' }}</p>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                {{-- <form action="{{ route('vnpay_payment') }}" method="post">
                    @csrf
                    <input type="hidden" name="name" value="cristiano Ronaldo">
                    <input type="hidden" name="phone" value="1234567890">
                    <input type="hidden" name="email" value="ronaldo@gmail.com">
                    <button type="submit" name="redirect" >Thanh Toán Vnpay</button>
                </form> --}}
            </div>
        </div>
    </div>
@endsection
@section('script')
    <script src="{{ asset('client/js/checkout.js') }}"></script>
@endsection
