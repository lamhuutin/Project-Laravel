@extends('layouts.client')
@section('title', 'Chi Tiết Sản Phẩm')
@section('sidebar')
@endsection
@section('content')
    <div class="section" id="detail-product-wp">
        <div class="section-detail clearfix">
            <div class="thumb-wp fl-left">
                <a href="" title="" id="main-thumb" style="">
                    <img id="zoom" style="max-width:350px; min-height:350px; padding:10px 5px"
                        src="{{ asset('uploads/' . $product->thumb) }}"
                        data-zoom-image="{{ asset('uploads/' . $product->thumb) }}" />
                </a>
                <div id="list-thumb">
                    @foreach ($product->images_detail as $item)
                        <a href="" data-image="{{ asset('uploads/' . $item) }}"
                            data-zoom-image="{{ asset('uploads/' . $item) }}">
                            <img id="zoom" src="{{ asset('uploads/' . $item) }}" />
                        </a>
                    @endforeach
                </div>
            </div>
            <div class="thumb-respon-wp fl-left">
                <img src="{{ asset('uploads/' . $product->thumb) }}" alt="">
            </div>
            <div class="info fl-right">
                <h3 class="product-name">{{ $product->name }}</h3>
                <div class="desc">
                    {!! $product->desc !!}
                </div>
                <div class="num-product">
                    <span class="title">Sản phẩm: </span>
                    @if ($product->status === '2')
                        <span class="status" style="color: red">hết hàng</span>
                    @else
                        <span class="status">Còn hàng</span>
                    @endif
                </div>
                @if ($product->discount > 0)
                    <p class="price" style="font-size:20px">{{ number_format($product->discount, 0, ',', '.') . ' đ' }}
                        <span class="text-muted"
                            style="text-decoration:line-through; color:#999">{{ number_format($product->price, 0, ',', '.') . ' đ' }}</span>
                    </p>
                @else
                    <p class="price" style="font-size:15px">{{ number_format($product->price, 0, ',', '.') . ' đ' }}</p>
                @endif
                @if ($product->status != 2)
                    <div id="num-order-wp">
                        <a title="" id="minus"><i class="fa fa-minus"></i></a>
                        <input type="text" name="num-order" value="1" id="num-order">
                        <a title="" id="plus"><i class="fa fa-plus"></i></a>
                    </div>
                    <button class="add-cart" id="add-cart" data-id="{{ $product->id }}" data-qty="1"
                        data-toggle="modal" data-target="#success_tic">Thêm Giỏ Hàng</button>
                @endif
            </div>
        </div>
    </div>
    <div class="section" id="post-product-wp">
        <div class="section-head">
            <h3 class="section-title">Mô tả sản phẩm</h3>
        </div>
        <div class="section-detail product-content">
            {!! $product->content !!}
        </div>
    </div>
    <div class="section" id="same-category-wp">
        <div class="section-head">
            <h3 class="section-title text-uppercase">sản phẩm cùng danh mục</h3>
        </div>
        <div class="section-detail">
            <ul class="list-item">
                @foreach ($data as $model)
                    <li class="same-category" style="height: 400px">
                        <a href="{{ route('productDetail', ['productCatSlug' => Str::slug($model->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id]) }}"
                            title="" class="thumb img-container">
                            <img src="{{ asset('uploads/' . $model->thumb) }}">
                        </a>
                        <a href="{{ route('productDetail', ['productCatSlug' => Str::slug($model->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id]) }}"
                            title="" class="product-name">{{ $model->name }}</a>
                        @if ($model->discount > 0)
                            <div class="price">
                                <span class="new">{{ number_format($model->discount, 0, ',', '.') . ' đ' }}</span>
                                <span class="old">{{ number_format($model->price, 0, ',', '.') . ' đ' }}</span>
                            </div>
                        @else
                            <div class="price">
                                <span class="new">{{ number_format($model->price, 0, ',', '.') . ' đ' }}</span>
                            </div>
                        @endif
                        @if ($model->status === '2')
                            <div class="price">
                                <span class="text-danger" style="color:red">Hết Hàng</span>
                            </div>
                        @else
                            <div class="action clearfix">
                                <a href="?page=cart" title="Thêm giỏ hàng" class="add-cart fl-left">Thêm
                                    giỏ hàng</a>
                                <a href="?page=checkout" title="Mua ngay" class="buy-now fl-right">Mua
                                    ngay</a>
                            </div>
                        @endif
                    </li>
                @endforeach
            </ul>
        </div>
    </div>
@endsection

