@extends('layouts.client')
@section('title', 'Danh Sách Sản Phẩm')
@section('content')
    <div class="section" id="list-product-wp">
        <div class="section-head clearfix">
            <h3 class="section-title fl-left">{{ isset($productCat_name) ? $productCat_name : 'Danh sách sản phẩm' }}</h3>
            <div class="filter-wp fl-right">
                {{-- <p class="desc">Hiển thị 45 trên 50 sản phẩm</p> --}}
                <div class="form-filter">
                    <form method="" action="">
                        @csrf
                        <input type="hidden" name="data" value="{{ json_encode($data) }}">
                        <select name="action">
                            <option value="0">Sắp xếp</option>
                            <option value="hightolow">Giá cao đến thấp</option>
                            <option value="lowtohigh">Giá thấp đến cao</option>
                        </select>
                        {{-- <button type="submit">Lọc</button> --}}
                    </form>
                </div>
            </div>
        </div>
        <div class="section-detail">
            @if ($data->count() > 0)
                <ul class="list-item clearfix" id="list-products">

                    @foreach ($data as $model)
                        <li>
                            <a href="{{ route('productDetail', ['productCatSlug' => Str::slug($model->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id]) }}"
                                title="" class="thumb img-container">
                                <img src="{{ asset('uploads/' . $model->thumb) }}">
                            </a>
                            <a href="{{ route('productDetail', ['productCatSlug' => Str::slug($model->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id]) }}"
                                title="" class="product-name">{{ $model->name }}</a>
                            @if ($model->discount > 0)
                                <div class="price">
                                    <span class="new">{{ number_format($model->discount, 0, ',', '.') . ' đ' }}</span>
                                    <span class="old">{{ number_format($model->price, 0, ',', '.') . ' đ' }}</span>
                                </div>
                            @else
                                <div class="price">
                                    <span class="new">{{ number_format($model->price, 0, ',', '.') . ' đ' }}</span>
                                </div>
                            @endif
                            @if ($model->status === '2')
                                <div class="price">
                                    <span class="text-danger" style="color:red">Hết Hàng</span>
                                </div>
                            @else
                                <div class="action clearfix">
                                    <button class="add-cart" data-id="{{ $model->id }}" data-toggle="modal"
                                        data-target="#success_tic">Thêm Giỏ Hàng</button>
                                    <a href="{{ route('checkout', ['id' => [$model->id], 'buynow' => 'ok']) }}"
                                        title="Mua ngay" class="buy-now fl-right">Mua
                                        ngay</a>
                                </div>
                            @endif
                            @if ($model->discount>0)
                            <div class="discount-label">
                                <span>-{{  floor((($model->price-$model->discount)/$model->price)*100) }}%</span>
                                <span class="label-text">Giảm giá</span>
                            </div>
                            @endif
                        </li>
                    @endforeach
                </ul>
            @else
                <p class="text-danger text-capitalize font-italic">Không tìm thấy sản phẩm</p>
            @endif
        </div>
    </div>
    <div class="section" id="paging-wp">
        <div class="section-detail">
            <div class="list-item clearfix">
                {{ $data->links() }}
            </div>
        </div>
    </div>
@endsection
@section('script')
    <script>
        $(document).ready(function() {
            var getUrlParameter = function getUrlParameter(sParam) {
                var sPageURL = window.location.search.substring(1),
                    sURLVariables = sPageURL.split('&'),
                    sParameterName,
                    i;

                for (i = 0; i < sURLVariables.length; i++) {
                    sParameterName = sURLVariables[i].split('=');

                    if (sParameterName[0] === sParam) {
                        return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
                    }
                }
                return false;
            };

            if (getUrlParameter('filter')) {
                let filter = getUrlParameter('filter');
                $("select[name='action']").val(filter).change();
                filter_product();
            }

            function filter_product() {
                let action = $("select[name='action']").val();
                let products = $("input[name=data]").val();
                let data = {
                    products: products,
                    action: action,
                }
                $.ajax({
                    url: "{{ route('filterAjax') }}",
                    method: 'post',
                    data: data,
                    dataType: 'json',
                    success: function(data) {
                        $("ul#list-products").html(data);
                    },
                    error: function(xhr, ajaxOptions, thrownError) {
                        alert(xhr.status);
                        alert(thrownError);
                    }
                })
            }

            $("select[name='action']").change(function() {
                let filter = $(this).val();
                if (filter !== '0') {
                    let queryParams = new URLSearchParams(window.location.search);
                    queryParams.set("filter", filter);
                    window.history.replaceState(null, null, "?" + queryParams.toString());
                    filter_product();
                }
            })
        })
    </script>
@endsection
