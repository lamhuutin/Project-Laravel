@extends('layouts.client')
@section('title', 'Chi tiết bài viết')
@section('breadcrumb')
    <div class="secion" id="breadcrumb-wp">
        <div class="secion-detail">
            <ul class="list-item clearfix">
                <li>
                    <a href="{{ route('home.page') }}" title="">Trang chủ</a>
                </li>
                <li>
                    <a href="#">Blog</a>
                </li>
            </ul>
        </div>
    </div>
@endsection
@section('content')
    <div class="section" id="list-blog-wp">
        <div class="section-head clearfix">
            <h3 class="section-title">Blog</h3>
        </div>
        <div class="section-detail">
            <ul class="list-item">
                @if ($data->count() > 0)
                    @foreach ($data as $model)
                        <li class="clearfix">
                            <a href="{{ route('showPost',['postSlug'=>Str::slug($model->title),'id'=>$model->id]) }}" title="" class="thumb fl-left">
                                <img src="{{ asset('uploads/'.$model->thumb) }}" alt="">
                            </a>
                            <div class="info fl-right">
                                <a href="{{ route('showPost',['postSlug'=>Str::slug($model->title),'id'=>$model->id]) }}" title="" class="title">{{ $model->title }}</a>
                                <span class="create-date">{{ $model->created_at }}</span>
                                <p class="desc">{{ $model->desc }}</p>
                            </div>
                        </li>
                    @endforeach
                @else
                    <p class="text-danger text-capitalize font-italic">Không tìm thấy bài viết</p>
                @endif
            </ul>
        </div>
    </div>
    <div class="section" id="paging-wp">
        <div class="section-detail d-fex">
            {{ $data->links() }}
        </div>
    </div>
@endsection
