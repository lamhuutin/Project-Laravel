@extends('layouts.client')
@section('title', 'Trang Chủ')
@section('sidebar')

@endsection
@section('content')
    <div class="section" id="slider-wp">
        <div class="section-detail">
            @foreach ($slides as $model)
            <div class="item">
                <img src="{{ asset('uploads/'.$model->thumb) }}" alt="">
            </div>
            @endforeach
        </div>
    </div>
    <div class="section" id="support-wp">
        <div class="section-detail">
            <ul class="list-item clearfix">
                <li>
                    <div class="thumb">
                        <img src="{{ asset('client/images/icon-1.png') }}">
                    </div>
                    <h3 class="title">Miễn phí vận chuyển</h3>
                    <p class="desc">Tới tận tay khách hàng</p>
                </li>
                <li>
                    <div class="thumb">
                        <img src="{{ asset('client/images/icon-2.png') }}">
                    </div>
                    <h3 class="title">Tư vấn 24/7</h3>
                    <p class="desc">1900.9999</p>
                </li>
                <li>
                    <div class="thumb">
                        <img src="{{ asset('client/images/icon-3.png') }}">
                    </div>
                    <h3 class="title">Tiết kiệm hơn</h3>
                    <p class="desc">Với nhiều ưu đãi cực lớn</p>
                </li>
                <li>
                    <div class="thumb">
                        <img src="{{ asset('client/images/icon-4.png') }}">
                    </div>
                    <h3 class="title">Thanh toán nhanh</h3>
                    <p class="desc">Hỗ trợ nhiều hình thức</p>
                </li>
                <li>
                    <div class="thumb">
                        <img src="{{ asset('client/images/icon-5.png') }}">
                    </div>
                    <h3 class="title">Đặt hàng online</h3>
                    <p class="desc">Thao tác đơn giản</p>
                </li>
            </ul>
        </div>
    </div>
    <div class="section" id="feature-product-wp">
        <div class="section-head">
            <h3 class="section-title">Sản phẩm nổi bật</h3>
        </div>
        <div class="section-detail">
            <ul class="list-item">
                @if ($hotProducts->count() > 0)
                    @foreach ($hotProducts as $model)
                        <li>
                            <a href="{{ route('productDetail', ['productCatSlug' => Str::slug($model->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id]) }}"
                                title="" class="thumb img-container">
                                <img src="{{ asset('uploads/' . $model->thumb) }}">
                            </a>
                            <a href="{{ route('productDetail', ['productCatSlug' => Str::slug($model->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id]) }}"
                                title="" class="product-name">{{ $model->name }}</a>
                            @if ($model->discount > 0)
                                <div class="price">
                                    <span class="new">{{ number_format($model->discount, 0, ',', '.') . ' đ' }}</span>
                                    <span class="old">{{ number_format($model->price, 0, ',', '.') . ' đ' }}</span>
                                </div>
                            @else
                                <div class="price">
                                    <span class="new">{{ number_format($model->price, 0, ',', '.') . ' đ' }}</span>
                                    {{-- <span class="old">8.990.000đđ</span> --}}
                                </div>
                            @endif
                            @if ($model->status === '2')
                                <div class="price">
                                    <span class="text-danger" style="color:red">Hết Hàng</span>
                                </div>
                            @else
                                <div class="action clearfix">
                                    <button class="add-cart" data-id="{{ $model->id }}" data-toggle="modal"
                                        data-target="#success_tic">Thêm Giỏ Hàng</button>
                                    <a href="{{ route('checkout', ['id' => [$model->id], 'buynow' => 'ok']) }}"
                                        title="Mua ngay" class="buy-now fl-right">Mua
                                        ngay</a>
                                </div>
                            @endif
                            @if ($model->discount>0)
                            <div class="discount-label">
                                <span>-{{  floor((($model->price-$model->discount)/$model->price)*100) }}%</span>
                                <span class="label-text">Giảm giá</span>
                            </div>
                            @endif
                        </li>
                    @endforeach
                @endif
            </ul>
        </div>
    </div>
    <div class="section" id="list-product-wp">
        <div class="section-head">
            <h3 class="section-title">Điện thoại</h3>
        </div>
        <div class="section-detail">
            <ul class="list-item clearfix">
                @if ($phones->count() > 0)
                    @foreach ($phones as $model)
                        <li>
                            <a href="{{ route('productDetail', ['productCatSlug' => Str::slug($model->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id]) }}"
                                title="" class="thumb img-container">
                                <img src="{{ asset('uploads/' . $model->thumb) }}">
                            </a>
                            <a href="{{ route('productDetail', ['productCatSlug' => Str::slug($model->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id]) }}"
                                title="" class="product-name">{{ $model->name }}</a>
                            @if ($model->discount > 0)
                                <div class="price">
                                    <span class="new">{{ number_format($model->discount, 0, ',', '.') . ' đ' }}</span>
                                    <span class="old">{{ number_format($model->price, 0, ',', '.') . ' đ' }}</span>
                                </div>
                            @else
                                <div class="price">
                                    <span class="new">{{ number_format($model->price, 0, ',', '.') . ' đ' }}</span>
                                    {{-- <span class="old">8.990.000đđ</span> --}}
                                </div>
                            @endif
                            @if ($model->status === '2')
                                <div class="price">
                                    <span class="text-danger" style="color:red">Hết Hàng</span>
                                </div>
                            @else
                                <div class="action clearfix">
                                    <button class="add-cart" data-id="{{ $model->id }}" data-toggle="modal"
                                        data-target="#success_tic">Thêm Giỏ Hàng</button>
                                    <a href="{{ route('checkout', ['id' => [$model->id], 'buynow' => 'ok']) }}"
                                        title="Mua ngay" class="buy-now fl-right">Mua
                                        ngay</a>
                                </div>
                            @endif

                            @if ($model->discount>0)
                            <div class="discount-label">
                                <span>-{{  floor((($model->price-$model->discount)/$model->price)*100) }}%</span>
                                <span class="label-text">Giảm giá</span>
                            </div>
                            @endif
                        </li>
                    @endforeach
                @endif
            </ul>
        </div>
        <a href="{{ route('productByCat.show', ['slug' => 'dien-thoai', 'id' => 1]) }}" class="all-products">Xem tất cả
            sản phẩm</a>
    </div>

    <div class="section" id="list-product-wp">
        <div class="section-head">
            <h3 class="section-title">Laptop</h3>
        </div>
        <div class="section-detail">
            <ul class="list-item clearfix">
                @if ($laps->count() > 0)
                    @foreach ($laps as $model)
                        <li>
                            <a href="{{ route('productDetail', ['productCatSlug' => Str::slug($model->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id]) }}"
                                title="" class="thumb img-container">
                                <img src="{{ asset('uploads/' . $model->thumb) }}">
                            </a>
                            <a href="{{ route('productDetail', ['productCatSlug' => Str::slug($model->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id]) }}"
                                title="" class="product-name">{{ $model->name }}</a>
                            @if ($model->discount > 0)
                                <div class="price">
                                    <span class="new">{{ number_format($model->discount, 0, ',', '.') . ' đ' }}</span>
                                    <span class="old">{{ number_format($model->price, 0, ',', '.') . ' đ' }}</span>
                                </div>
                            @else
                                <div class="price">
                                    <span class="new">{{ number_format($model->price, 0, ',', '.') . ' đ' }}</span>
                                    {{-- <span class="old">8.990.000đđ</span> --}}
                                </div>
                            @endif
                            @if ($model->status === '2')
                                <div class="price">
                                    <span class="text-danger" style="color:red">Hết Hàng</span>
                                </div>
                            @else
                                <div class="action clearfix">
                                    <button class="add-cart" data-id="{{ $model->id }}" data-toggle="modal"
                                        data-target="#success_tic">Thêm Giỏ Hàng</button>
                                    <a href="{{ route('checkout', ['id' => [$model->id], 'buynow' => 'ok']) }}"
                                        title="Mua ngay" class="buy-now fl-right">Mua
                                        ngay</a>
                                </div>
                            @endif
                            @if ($model->discount>0)
                            <div class="discount-label">
                                <span>-{{  floor((($model->price-$model->discount)/$model->price)*100) }}%</span>
                                <span class="label-text">Giảm giá</span>
                            </div>
                            @endif
                        </li>
                    @endforeach
                @endif
            </ul>
        </div>
        <a href="{{ route('productByCat.show', ['slug' => 'laptop', 'id' => 2]) }}" class="all-products">Xem tất cả sản
            phẩm</a>
    </div>
@endsection

@section('script')
    <script>
        // $(document).ready(function(){
        //     $("button.add-cart").click(function(){
        //         let id = $(this).attr('data-id');
        //         href = "{{ route('checkout')}}?id="+id+"buynow=ok";
        //         $("a#modal-buynow").attr('href',href);
        //     })
        // })
    </script>
@endsection

