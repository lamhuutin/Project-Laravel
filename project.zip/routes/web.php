<?php

use App\Http\Controllers\Admin\AdminOrderController;
use App\Http\Controllers\admin\AdminPageController;
use App\Http\Controllers\admin\AdminPostCatController;
use App\Http\Controllers\admin\AdminPostController;
use App\Http\Controllers\admin\AdminProductCatController;
use App\Http\Controllers\admin\AdminProductController;
use App\Http\Controllers\Admin\AdminRoleController;
use App\Http\Controllers\Admin\AdminSlideController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\admin\UserController;
use App\Http\Controllers\client\CartController;
use App\Http\Controllers\client\CheckoutController;
use App\Http\Controllers\client\HomePageController;
use App\Http\Controllers\client\PaymentController;
use App\Http\Controllers\client\PostController;
use App\Http\Controllers\client\ProductController;
use App\Http\Controllers\client\SeacrhAjaxController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
// phần admin



// Route::get('/', function () {
//     return view('welcome');
// });
// Route::get('/', function () {
//     return view('welcome');
// });

Auth::routes(['verify' => true]);
Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home')->middleware('verified');

//phần danh mục sản phẩm
Route::get('/', [HomePageController::class, 'index'])->name('home.page');


// //phần seach, filter
Route::get('/search-ajax', [SeacrhAjaxController::class, 'searchAjax'])->name('searchAjax');
Route::post('/filter-ajax', [SeacrhAjaxController::class, 'filterAjax'])->name('filterAjax');

Route::get('/danh-muc-san-pham-{slug}-{id}.html', [ProductController::class, 'index'])->name('productByCat.show');
Route::get('/search.html', [ProductController::class, 'search'])->name('search');
Route::get('/danh-muc-{productCatSlug}/{slug}-{id}.html', [ProductController::class, 'productDetail'])->name('productDetail');
Route::get('/trang-{pageSlug}-{id}.html', [PostController::class, 'showPage'])->name('showPage');
Route::get('/bai-viet-{postSlug}-{id}.html', [PostController::class, 'showPost'])->name('showPost');
Route::get('/danh-sach-bai-viet.html', [PostController::class, 'showListPost'])->name('showListPost');
// phần giỏ hàng
Route::get('/gio-hang.html', [CartController::class, 'index'])->name('cart');
Route::get('/them-gio-hang.html', [CartController::class, 'addCart'])->name('addCart');
Route::get('/cap-nhat-gio-hang.html', [CartController::class, 'updateCart'])->name('updateCart');
Route::get('/xoa-san-pham.html', [CartController::class, 'destroyCart'])->name('destroyCart');
Route::get('/thanh-toan.html', [CheckoutController::class, 'checkout'])->name('checkout');
Route::get('/changeDistrict.html', [CheckoutController::class, 'changeDistrict'])->name('changeDistrict');
Route::get('/changeWards.html', [CheckoutController::class, 'changeWards'])->name('changeWards');
// Route::get('/thong-tin-khach-hang', [CheckoutController::class, 'infoCustomer'])->name('infoCustomer');
// Route::post('/luu-thong-tin',[CheckoutController::class, 'store'])->name('storeInfo');
Route::get('/cap-nhat-thanh-toan.html', [CheckoutController::class, 'updateCheckout'])->name('updateCheckout');
//thanh toán vnPay
Route::post('/vnpay-payment.html', [PaymentController::class, 'vnpay_payment'])->name('vnpay-payment');
Route::get('/successVnpay.html', [PaymentController::class, 'orderSuccessVnpay'])->name('orderSuccessVnpay');
//thanh toán khi nhận hàng
Route::post('/cod-payment.html', [PaymentController::class, 'cod_payment'])->name('cod-payment');
//thanh toán Momo
Route::post('/momo-payment.html', [PaymentController::class, 'momo_payment'])->name('momo-payment');
Route::get('/successMomo.html', [PaymentController::class, 'orderSuccessMomo'])->name('orderSuccessMomo');

Route::group(['prefix' => 'admin', 'as' => 'admin.', 'middleware' => ['auth', 'verified']], function () {
    // Phần dashboard
    Route::get('/', [DashboardController::class, 'dashboard'])->name('dashboard');
    //user admin
    Route::get('/user', [UserController::class, 'index'])->name('user.index')->can('admin.user.index');
    Route::get('/user/create', [UserController::class, 'create'])->name('user.create')->can('admin.user.create');
    Route::post('/user/store', [UserController::class, 'store'])->name('user.store')->can('admin.user.create');
    Route::get('/user/edit/{id}', [UserController::class, 'edit'])->name('user.edit')->can('admin.user.edit');
    Route::post('/user/update/{id}', [UserController::class, 'update'])->name('user.update')->can('admin.user.edit');
    Route::get('/user/destroy/{id}', [UserController::class, 'destroy'])->name('user.destroy')->can('admin.user.edit');
    Route::get('/user/restore/{id}', [UserController::class, 'restore'])->name('user.restore')->can('admin.user.edit');
    Route::post('/user/action', [UserController::class, 'action'])->name('user.action')->can('admin.user.edit');
    //phần slide
    Route::resource('/slide', AdminSlideController::class)->except('show');
    Route::get('/slide/restore/{id}', [AdminSlideController::class, 'restore'])->name('slide.restore')->can('admin.slide.edit');
    Route::post('/slide/action', [AdminSlideController::class, 'action'])->name('slide.action')->can('admin.slide.edit');
    //Phần trang
    Route::resource('/page', AdminPageController::class)->except('show');
    Route::post('/page/action', [AdminPageController::class, 'action'])->name('page.action')->can('admin.page.edit');
    Route::get('/page/restore/{id}', [AdminPageController::class, 'restore'])->name('page.restore')->can('admin.page.edit');
    //phần danh mục bài viết
    Route::resource('/postCat', AdminPostCatController::class)->except('index', 'show');
    //phần bài viết
    Route::resource('/post', AdminPostController::class)->except('show');
    Route::post('/post/action', [AdminPostController::class, 'action'])->name('post.action')->can('admin.post.edit');
    Route::get('/post/restore/{id}', [AdminPostController::class, 'restore'])->name('post.restore')->can('admin.post.edit');
    //phần danh mục sản phẩm
    Route::resource('/productCat', AdminProductCatController::class)->except('index', 'show');
    //phần sản phẩm
    Route::resource('/product', AdminProductController::class)->except('show');
    Route::post('/product/action', [AdminProductController::class, 'action'])->name('product.action')->can('admin.product.edit');
    Route::get('/product/restore/{id}', [AdminProductController::class, 'restore'])->name('product.restore')->can('admin.product.edit');
    //phần đơn hàng
    Route::get('/order', [AdminOrderController::class, 'index'])->name('order.index')->can('admin.order.index');
    Route::get('/order/{id}', [AdminOrderController::class, 'edit'])->name('order.edit')->can('admin.order.edit');
    Route::post('/order/{id}', [AdminOrderController::class, 'update'])->name('order.update')->can('admin.order.edit');
    Route::get('/order/destroy/{id}', [AdminOrderController::class, 'destroy'])->name('order.destroy')->can('admin.order.destroy');
    Route::get('/order/restore/{id}', [AdminOrderController::class, 'restore'])->name('order.restore')->can('admin.order.edit');
    Route::post('/order/action', [AdminOrderController::class, 'action'])->name('order.action')->can('admin.order.edit');
    //phần role
    Route::get('/role', [AdminRoleController::class, 'index'])->name('role.index')->can('admin.role.index');
    Route::get('/role/create', [AdminRoleController::class, 'create'])->name('role.create')->can('admin.role.create');
    Route::post('/role/store', [AdminRoleController::class, 'store'])->name('role.store')->can('admin.role.create');
    Route::get('/role/edit/{role}', [AdminRoleController::class, 'edit'])->name('role.edit')->can('admin.role.edit');
    Route::post('/role/update/{role}', [AdminRoleController::class, 'update'])->name('role.update')->can('admin.role.edit');
    Route::get('/role/destroy/{role}', [AdminRoleController::class, 'destroy'])->name('role.destroy')->can('admin.role.destroy');
});
// phần client


//lưu session info customer

//thanh toán thành công
Route::get('/chi-tiet-don-hang.html', [PaymentController::class, 'orderDetailSuccess'])->name('orderDetailSuccess');
Route::group(['prefix' => 'laravel-filemanager', 'middleware' => ['web', 'auth']], function () {
    \UniSharp\LaravelFilemanager\Lfm::routes();
});
