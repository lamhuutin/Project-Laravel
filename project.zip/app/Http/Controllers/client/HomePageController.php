<?php

namespace App\Http\Controllers\client;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductCat;
use App\Models\Slide;
use Gloudemans\Shoppingcart\Facades\Cart;
use Illuminate\Http\Request;

class HomePageController extends Controller
{
    public function index()
    {
        // $response = response('Cookie deleted.')->cookie(
        //     'info_customer', '', -1
        // );
        // return $response;
        $productCats = ProductCat::all(); //lấy danh sách danh mục sản phẩm
        $idCatPhone =  get_list_cat_id($productCats, 1); // lấy danh sách id danh mục sản phẩm điện thoại
        $phones = Product::join('product_cats', 'product_cats.id', '=', 'products.productCat_id')->whereIn('products.productCat_id', $idCatPhone)->whereNotIn('products.status', ['0'])->select('products.id', 'products.name', 'products.price', 'products.discount', 'products.thumb', 'products.status', 'product_cats.name as cat_name')->limit(10)->get(); //lấy danh sách sản phẩm của điện thoại và các danh mục con của nó
        $idCatLap = get_list_cat_id($productCats, 2); // lấy danh sách id danh mục sản phẩm con laptop
        $laps = Product::join('product_cats', 'product_cats.id', '=', 'products.productCat_id')->whereIn('products.productCat_id', $idCatLap)->whereNotIn('products.status', ['0'])->select('products.id', 'products.name', 'products.price', 'products.discount', 'products.thumb', 'products.status', 'product_cats.name as cat_name')->limit(10)->get(); //lấy danh sách sản phẩm của laptop và các danh mục con của nó
        $slides = Slide::withoutTrashed()->where('status','1')->orderBy('display_order','asc')->get();
        return view('client.home', compact('phones', 'laps','slides'));
    }
}
