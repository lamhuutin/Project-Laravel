<?php

namespace App\Http\Controllers\client;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Product;
use Gloudemans\Shoppingcart\Facades\Cart;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Response;
use Nette\Utils\Random;

class CheckoutController extends Controller
{
    public function checkout(Request $request)
    {
        $list_id = $request->id;
        if (!$list_id) return redirect()->route('cart')->with('status', 'Vui bạn chưa có bất kỳ sản phẩm nào trong giỏ hàng');
        $province = DB::table('province')->get();
        $buynow = $request->buynow;
        if ($buynow === 'ok') {
            $product = Product::join('product_cats', 'product_cats.id', '=', 'products.productCat_id')->select('product_cats.name as cat_name', 'products.id', 'products.name', 'products.thumb', 'products.price', 'products.discount')->find($list_id[0]);
            Cart::add([
                'id' => $product->id,
                'cat_name' => $product->cat_name,
                'name' => $product->name,
                'qty' => 1,
                'price' => $product->discount > 0 ? $product->discount : $product->price,
                'options' => ['cat_name' => $product->cat_name, 'thumb' => $product->thumb, 'price' => $product->price, 'discount' => $product->discount]
            ]);
        }
        $data = [];
        $total = 0;
        foreach (Cart::content() as $model) {
            if (in_array($model->id, $list_id)) {
                $data[] = $model;
                $total += $model->total;
            }
        }
        if ($request->hasCookie('info_customer')) {
            $info_customer = json_decode($request->cookie('info_customer'));
            $district = DB::table('district')->get();
            $wards = DB::table('wards')->get();
            return view('client.cart.checkout', compact('data', 'total', 'list_id', 'province','info_customer','district','wards'));
        }
        return view('client.cart.checkout', compact('data', 'total', 'list_id', 'province'));
    }

    public function updateCheckout(Request $request)
    {
        $list_id = json_decode($request->list_id);
        $rowId = $request->rowId;
        $qty = $request->qty;
        if (Cart::content()[$rowId]) {
            Cart::update($rowId, $qty);
            $total = number_format(Cart::content()[$rowId]->total, 0, ',', '.') . ' đ';
            $total_qty = Cart::count();
            $total_price = Cart::total() . ' đ';
            $total_order = 0;
            foreach (Cart::content() as $model) {
                if (in_array($model->id, $list_id)) $total_order += $model->total;
            }
            return json_encode([
                'total' => $total,
                'total_qty' => $total_qty,
                'total_price' => $total_price,
                'total_order' => number_format($total_order, 0, ',', '.') . ' Đ',
                'total_order_original' => $total_order
            ]);
        }
    }

    public function changeDistrict(Request $request)
    {
        $province_id = $request->province_id;
        $district = DB::table('district')->where('province_id', $province_id)->get();
        $data[0] = [
            'id' => 0,
            'name' => 'Chọn một Quận/huyện'
        ];
        foreach ($district as $model) {
            $data[] = [
                'id' => $model->district_id,
                'name' => $model->name
            ];
        }
        return json_encode($data);
    }

    public function changeWards(Request $request)
    {
        $district_id = $request->district_id;
        $wards = DB::table('wards')->where('district_id', $district_id)->get();
        $data[0] = [
            'id' => 0,
            'name' => 'Chọn một xã/phường/Thị Trấn'
        ];
        foreach ($wards as $model) {
            $data[] = [
                'id' => $model->wards_id,
                'name' => $model->name
            ];
        }
        return json_encode($data);
    }
}
//total_price, total_qty, total, total_order