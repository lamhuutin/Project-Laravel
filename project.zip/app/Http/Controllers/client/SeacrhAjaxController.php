<?php

namespace App\Http\Controllers\client;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductCat;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class SeacrhAjaxController extends Controller
{
    public function searchAjax(Request $request)
    {
        $keyword = $request->keyword;
        $data = Product::join('product_cats', 'product_cats.id', '=', 'products.productCat_id')->where('products.name', 'like', "%{$keyword}%")->whereNotIn('products.status', ['0'])->select('products.id', 'products.name', 'products.price', 'products.discount', 'products.thumb', 'products.status', 'product_cats.name as cat_name')->limit(5)->get();
        if ($data->count() === 0) {
            $list_cat = ProductCat::where('name', 'like', "%{$keyword}%")->get();
            $productCats = ProductCat::all();
            $id = [];
            foreach ($list_cat as $cat) {
                $id = array_merge($id, get_list_cat_id($productCats, $cat->id));
            }
            array_unique($id);
            $id = array_unique($id);
            $data = Product::join('product_cats', 'product_cats.id', '=', 'products.productCat_id')->whereIn('products.productCat_id', $id)->whereNotIn('products.status', ['0'])->select('products.id', 'products.name', 'products.price', 'products.discount', 'products.thumb', 'products.status', 'product_cats.name as cat_name')->limit(5)->get();
        }
        if (count($data) > 0) {
            $html = '';
            foreach ($data as $model) {
                $src_thumb = asset('uploads/' . $model->thumb);
                $price = number_format($model->price, 0, ',', '.') . ' đ';
                $discount = number_format($model->discount, 0, ',', '.') . ' đ';
                $href = route('productDetail', ['id' => $model->id, 'slug' => Str::slug($model->name), 'productCatSlug' => Str::slug($model->cat_name)]);
                $html .= "<a href='{$href}' > <div class='media text-dark mb-3' style='margin-bottom:10px; display:flex' ><img width='100px' src='{$src_thumb}' style='margin-right:10px'> <div class='media-body'><h5 style='color:black' >{$model->name}</h5>";
                if ($model->discount > 0) $html .= "<p style='color: #0984e3' >{$discount} <span style='text-decoration: line-through; color: #999'>{$price}</span>";
                else $html .= "<p>{$price}";
                $html .= "</p> </div> </div> </a>";
            }
            if (count($data) === 5) {
                $href_search = route('search', ['keyword' => $keyword]);
                $html .= "<a href='{$href_search}'>Xem tất cả sản phẩm thuộc tìm kiếm</a>";
            }
            return json_encode($html);
        }
        return json_encode('no');
    }

    public function filterAjax(Request $request)
    {
        $action = $request->action;
        $data = json_decode($request->products)->data;
        foreach ($data as $model) {
            if ($model->discount > 0) {
                $model->current_price = $model->discount;
            } else {
                $model->current_price = $model->price;
            }
        }
        for ($i = 0; $i < count($data); $i++) {
            for ($j = $i + 1; $j < count($data); $j++) {
                if ($data[$j]->current_price > $data[$i]->current_price) {
                    $k = $data[$j];
                    $data[$j] = $data[$i];
                    $data[$i] = $k;
                }
            }
        }
        if ($action === 'lowtohigh') $data = array_reverse($data);
        $html = '';
        foreach ($data as $model) {
            $url = route('productDetail', ['productCatSlug' => Str::slug($model->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id]);
            $url_thumb =  asset('uploads/' . $model->thumb);
            $discount = number_format($model->discount, 0, ',', '.') . ' đ';
            $price = number_format($model->price, 0, ',', '.') . ' đ';
            $html .= "<li> <a href='{$url}' class='thumb img-container'> <img src='{$url_thumb}'> </a>";
            $html .= "<a href='{$url}' class='product-name'>{$model->name}</a>";
            if ($model->discount > 0) {
                $html .= "<div class='price'> <span class='new'>{$discount}</span> <span class='old'>{$price}</span> </div>";
            } else {
                $html .= "<div class='price'> <span class='new'>{$price}</span> </div>";
            }
            if ($model->status === '2') {
                $html .= "<div class='price'> <span class='text-danger' style='color:red'>Hết Hàng</span> </div>";
            } else {
                $html .= "<div class='action clearfix'> <a href='?page=cart' title='Thêm giỏ hàng' class='add-cart fl-left'>Thêm giỏ hàng</a> <a href='?page=checkout' title='Mua ngay' class='buy-now fl-right'>Mua ngay</a> </div>";
            }
            if ($model->discount > 0) {
                $percen_discount = floor((($model->price - $model->discount) / $model->price)* 100) ;
                $html .= "<div class='discount-label'>";
                $html .= "<span>-{$percen_discount}%</span>";
                $html .= "<span class='label-text'>Giảm giá</span></div>";
            }
            $html .= "</li>";
        }
        return json_encode($html);
    }
}
