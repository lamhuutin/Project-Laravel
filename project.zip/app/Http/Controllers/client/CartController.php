<?php

namespace App\Http\Controllers\client;

use App\Http\Controllers\Controller;
use App\Mail\orderConfirmMail;
use App\Models\Order;
use App\Models\Product;
use Gloudemans\Shoppingcart\Facades\Cart;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Carbon\Carbon;
use DateTimeZone;

class CartController extends Controller
{
    public function index(Request $request)
    {
        return view('client.cart.index');
    }

    public function addCart(Request $request)
    {
        $id = $request->id;
        $qty = $request->qty;
        $product = Product::join('product_cats', 'product_cats.id', '=', 'products.productCat_id')->select('product_cats.name as cat_name', 'products.id', 'products.name', 'products.thumb', 'products.price', 'products.discount')->find($id);
        if ($product) {
            Cart::add([
                'id' => $product->id,
                'cat_name' => $product->cat_name,
                'name' => $product->name,
                'qty' => $qty,
                'price' => $product->discount > 0 ? $product->discount : $product->price,
                'options' => ['cat_name' => $product->cat_name, 'thumb' => $product->thumb, 'price' => $product->price, 'discount' => $product->discount]
            ]);
            $html = '';
            $t = 0;
            foreach (Cart::content() as $model) {
                $t++;
                if ($t <= 4) {
                    $html .= "<li class='clearfix'>";
                    $url = route('productDetail', ['productCatSlug' => Str::slug($model->options->cat_name), 'slug' => Str::slug($model->name), 'id' => $model->id]);
                    $url_thumb = asset('uploads/' . $model->options->thumb);
                    $html .= "<a href='{$url}' title='' class='thumb fl-left'> <img src='{$url_thumb}' alt=''> </a>";
                    $html .= "<div class='info fl-right'> <a href='' title='' class='product-name'>{$model->name}</a>";
                    $price = number_format($model->options->price, 0, ',', '.') . ' đ';
                    if ($model->options->discount > 0) {
                        $discount =  number_format($model->options->discount, 0, ',', '.') . ' đ';
                        $html .= "<div class='price'><span class='new' style='color:#0984e3'>{$discount}</span><br> <span class='old' style='color:#999; text-decoration:line-through'>{$price}</span> </div>";
                    } else {
                        $html .= "<div class='price'> <span class='new' style='color:#0984e3'>{$price}</span> </div>";
                    }
                    $html .= "<p class='qty'>Số lượng: <span id='cart_qty_{$model->id}'>{$model->qty}</span></p> </div> </li>";
                }
            }
            if ($t > 4) {
                $url_cart = route('cart');
                $html .= "<a href='{$url_cart}'>Xem tất cả sản phẩm....</a>";
            }
            return json_encode(['list_cart' => $html, 'total_price' => Cart::total() . ' đ', 'total_qty' => Cart::count()]);
        }
    }

    public function updateCart(Request $request)
    {
        $rowId = $request->rowId;
        $qty = $request->qty;
        if (Cart::content()[$rowId]) {
            Cart::update($rowId, $qty);
            $total = number_format(Cart::content()[$rowId]->total, 0, ',', '.') . ' đ';
            $total_qty = Cart::count();
            $total_price = Cart::total() . ' đ';
            return json_encode([
                'total' => $total,
                'total_qty' => $total_qty,
                'total_price' => $total_price
            ]);
        }
    }

    public function destroyCart(Request $request)
    {
        $destroyAll = $request->destroyAll;
        if ($destroyAll === 'ok') {
            Cart::destroy();
            $status = 'đã xoá toàn bộ giỏ hàng';
        } else {
            $rowId = $request->rowId;
            if (!Cart::content()[$rowId]) return abort(404);
            Cart::remove($rowId);
            $status = 'đã xoá sản phẩm trong giỏ hàng';
        }
        return redirect()->route('cart')->with('status', $status);
    }
}
