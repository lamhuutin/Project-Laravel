<?php

namespace App\Http\Controllers\client;

use App\Http\Controllers\Controller;
use App\Models\Page;
use App\Models\Post;
use Illuminate\Http\Request;

class PostController extends Controller
{
    public function showPage(Request $request){
        $id = $request->id;
        $data = Page::where('status','1') -> find($id);
        if(!$data) return abort(404);
        $module = 'Trang';
        return view('client.post.index',compact('data','module'));
    }
    public function showPost(Request $request){
        $id = $request -> id;
        $data = Post::where('status','1')->find($id);
        if(!$data) return abort(404);
        return view('client.post.index',compact('data'));

    }
    public function showListPost(Request $request){
        $data = Post::where('status','1') -> paginate(20);
        return view('client.post.listPost',compact('data'));
    }
}
