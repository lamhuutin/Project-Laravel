<?php

namespace App\Http\Controllers\client;

use App\Http\Controllers\Controller;
use App\Mail\orderConfirmMail;
use Illuminate\Http\Request;
use App\Models\Customer;
use App\Models\Order;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Response;
use Gloudemans\Shoppingcart\Facades\Cart;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Carbon\Carbon;
use DateTimeZone;
use Illuminate\Support\Str;

class PaymentController extends Controller
{
    public function cod_payment(Request $request)
    {
        $this->validate_info($request);
        $data = $request->all();
        $list_id = json_decode($data['list_id']);
        $total_price = 0;
        $total_product = 0;
        $list_order = [];
        $code = '#'.Str::random(4);
        foreach (Cart::content() as $model) {
            if (in_array($model->id, $list_id)) {
                $list_order[] = $model;
                $total_product += $model->qty;
                $total_price += $model->total;
                Cart::remove($model->rowId);
            }
        }
        $province = DB::table('province')->where('province_id', $data['province'])->first()->name;
        $district = DB::table('district')->where('district_id', $data['district'])->first()->name;
        $wards = DB::table('wards')->where('wards_id', $data['wards'])->first()->name;
        $timezone = new DateTimeZone('Asia/Ho_Chi_Minh');
        $order_detail = [
            'list_order' => $list_order,
            'total_price' => $total_price,
            'name' => $data['name'],
            'email' => $data['email'],
            'phone' => $data['phone'],
            'address_shipping' => $province . ' - ' . $district . ' - ' . $wards . ', ' . $data['note'],
        ];
        $info_customer = [
            'name' => $data['name'],
            'email' => $data['email'],
            'phone' => $data['phone'],
            'province' => $province,
            'district' => $district,
            'wards' => $wards,
            'note' => $data['note'],
        ];
        //check old customer
        $check_old_customer = Customer::where('email', $info_customer['email'])->first();
        if ($check_old_customer) {
            //update old customer
            Customer::where('email', $info_customer['email'])->update($info_customer);
            $customer = Customer::where('email', $info_customer['email'])->first();
        } else {
            //create new
            $customer = Customer::create($info_customer);
        }
        $info_order = [
            'code'=>$code,
            'name' => $data['name'],
            'email' => $data['email'],
            'phone' => $data['phone'],
            'total_product' => $total_product,
            'total_price' => $total_price,
            'order_detail' => json_encode($order_detail),
            'status' => 'đã xác nhận',
            'address_shipping' => $province . ' - ' . $district . ' - ' . $wards,
            'note' => $data['note'],
            'payment_method' => 'cod-payment'
        ];
        Order::create($info_order);
        Mail::to('lamhuutin6879@gmail.com')->send(new orderConfirmMail(array_merge($order_detail, $info_customer, [
            'code'=>$code,
            'delivery_date' => Carbon::now()->setTimezone($timezone)->addDays(3),
            'today' => Carbon::now()->setTimezone($timezone)->format('Y-m-d H:i:s')
        ])));
        $info_customer = cookie('info_customer', json_encode($customer), 259200);
        return redirect()->route('orderDetailSuccess')->withCookie($info_customer)->with('order_detail', $order_detail);
    }

    public function orderSuccessVnpay(Request $request)
    {
        $data = json_decode($request->vnp_OrderInfo);
        $total_price = $request->vnp_Amount / 100;
        $code = $request -> vnp_TxnRef;
        $list_id = json_decode( json_decode($request->list_id) );
        $list_order = [];
        $total_product = 0;
        foreach (Cart::content() as $model) {
            if (in_array($model->id, $list_id)) {
                $list_order[] = $model;
                $total_product += $model->qty;
                Cart::remove($model->rowId);
            }
        }
        $province = DB::table('province')->where('province_id', $data->province)->first()->name;
        $district = DB::table('district')->where('district_id', $data->district)->first()->name;
        $wards = DB::table('wards')->where('wards_id', $data->wards)->first()->name;
        $timezone = new DateTimeZone('Asia/Ho_Chi_Minh');
        $order_detail = [
            'list_order' => $list_order,
            'total_price' => $total_price,
            'name' => $data->name,
            'email' => $data->email,
            'phone' => $data->phone,
            'address_shipping' => $province . ' - ' . $district . ' - ' . $wards . ', ' . $data->note
        ];

        $info_customer = [
            'name' => $data->name,
            'email' => $data->email,
            'phone' => $data->phone,
            'province' => $province,
            'district' => $district,
            'wards' => $wards,
            'note' => $data->note,
        ];
        //check old customer
        $check_old_customer = Customer::where('email', $info_customer['email'])->first();
        if ($check_old_customer) {
            //update old customer
            Customer::where('email', $info_customer['email'])->update($info_customer);
            $customer = Customer::where('email', $info_customer['email'])->first();
        } else {
            //create new
            $customer = Customer::create($info_customer);
        }
        $info_order = [
            'code' => $code,
            'name' => $data->name,
            'email' => $data->email,
            'phone' => $data->phone,
            'total_product' => $total_product,
            'total_price' => $total_price,
            'order_detail' => json_encode($order_detail),
            'status' => 'đã xác nhận',
            'address_shipping' => $province . ' - ' . $district . ' - ' . $wards,
            'note' => $data->note,
            'payment_method' => 'vnpay-payment'
        ];
        // dd(array_merge($order_detail, $info));
        Order::create($info_order);
        Mail::to('lamhuutin6879@gmail.com')->send(new orderConfirmMail(array_merge($order_detail, $info_customer, [
            'code' => $code,
            'delivery_date' => Carbon::now()->setTimezone($timezone)->addDays(3),
            'today' => Carbon::now()->setTimezone($timezone)->format('Y-m-d H:i:s')
        ])));
        $info_customer = cookie('info_customer', json_encode($customer), 259200);
        return redirect()->route('orderDetailSuccess')->withCookie($info_customer)->with('order_detail', $order_detail);
    }

    public function orderDetailSuccess(Request $request)
    {
        if (!session('order_detail')) return redirect()->route('home.page');
        $order_detail = session('order_detail');
        return view('client.cart.success', compact('order_detail'));
    }

    //thanh toán vnpay
    public function vnpay_payment(Request $request)
    {
        $this->validate_info($request);
        $list_id = json_encode($request->list_id);
        $vnp_Url = "https://sandbox.vnpayment.vn/paymentv2/vpcpay.html";
        $vnp_Returnurl = "http://localhost/Xop-pi.com/public/successVnpay.html?list_id=".$list_id;
        $vnp_TmnCode = "D3T6LA7T"; //Mã website tại VNPAY 
        $vnp_HashSecret = "TOELSCNHVBJUIKSXMLTUSRYQCBNQFDBH"; //Chuỗi bí mật
        $vnp_TxnRef = '#'.Str::random(4); //Mã đơn hàng. Trong thực tế Merchant cần insert đơn hàng vào DB và gửi mã này sang VNPAY
        $vnp_OrderInfo = json_encode($request->only('name', 'email', 'phone', 'province', 'district', 'wards', 'note'));
        $vnp_OrderType = 'Đơn Hàng';
        $vnp_Amount = $request->total_price * 100;
        $vnp_Locale = 'vn';
        $vnp_BankCode = 'NCB';
        $vnp_IpAddr = $_SERVER['REMOTE_ADDR'];
        $inputData = array(
            "vnp_Version" => "2.1.0",
            "vnp_TmnCode" => $vnp_TmnCode,
            "vnp_Amount" => $vnp_Amount,
            "vnp_Command" => "pay",
            "vnp_CreateDate" => date('YmdHis'),
            "vnp_CurrCode" => "VND",
            "vnp_IpAddr" => $vnp_IpAddr,
            "vnp_Locale" => $vnp_Locale,
            "vnp_OrderInfo" => $vnp_OrderInfo,
            "vnp_OrderType" => $vnp_OrderType,
            "vnp_ReturnUrl" => $vnp_Returnurl,
            "vnp_TxnRef" => $vnp_TxnRef,
        );
        if (isset($vnp_BankCode) && $vnp_BankCode != "") {
            $inputData['vnp_BankCode'] = $vnp_BankCode;
        }
        if (isset($vnp_Bill_State) && $vnp_Bill_State != "") {
            $inputData['vnp_Bill_State'] = $vnp_Bill_State;
        }
        //var_dump($inputData);
        ksort($inputData);
        $query = "";
        $i = 0;
        $hashdata = "";
        foreach ($inputData as $key => $value) {
            if ($i == 1) {
                $hashdata .= '&' . urlencode($key) . "=" . urlencode($value);
            } else {
                $hashdata .= urlencode($key) . "=" . urlencode($value);
                $i = 1;
            }
            $query .= urlencode($key) . "=" . urlencode($value) . '&';
        }

        $vnp_Url = $vnp_Url . "?" . $query;
        if (isset($vnp_HashSecret)) {
            $vnpSecureHash =   hash_hmac('sha512', $hashdata, $vnp_HashSecret); //  
            $vnp_Url .= 'vnp_SecureHash=' . $vnpSecureHash;
        }
        $returnData = array(
            'code' => '00', 'message' => 'success', 'data' => $vnp_Url
        );
        if (isset($_POST['redirect'])) {
            header('Location: ' . $vnp_Url);
            die();
        } else {
            echo json_encode($returnData);
        }
        // vui lòng tham khảo thêm tại code demo
    }


    public function validate_info(Request $request)
    {
        return  $request->validate(
            [
                'name' => 'required',
                'email' => 'required|email',
                'phone' => 'required|numeric|regex:/^[0-9]+$/',
                'province' => 'not_in:0',
                'district' => 'not_in:0',
                'wards' => 'not_in:0',
                'payment_method' => 'not_in:0'
            ],
            [
                'required' => ':attribute Không được để trống',
                'email' => 'Email phải có định dạng ACBXYZ@gmal.com',
                'numeric' => 'số điện thoại phải bắt đầu bằng 03,05,07,08,08 và phải có 10 chữ số',
                'regex' => ':attribute chỉ có các số từ 0-9 và không bao gồm ký tự',
                'not_in' => 'vui lòng chọn :attribute'
            ],
            [
                'name' => 'Họ và Tên',
                'email' => 'email',
                'phone' => 'số điện thoại',
                'province' => 'Tỉnh, Thành Phố',
                'district' => 'Quận, Huyện',
                'wards' => 'Xã, Phường, Thị Trấn',
                'payment_method' => 'phương thức thanh toán'
            ]
        );
    }

    public function execPostRequest($url, $data)
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt(
            $ch,
            CURLOPT_HTTPHEADER,
            array(
                'Content-Type: application/json',
                'Content-Length: ' . strlen($data)
            )
        );
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        //execute post
        $result = curl_exec($ch);
        //close connection
        curl_close($ch);
        return $result;
    }

    //Thanh toán momo
    public function momo_payment(Request $request)
    {
        if((int)($request->total_price) > 50000000) return redirect() -> back() -> with('fail','Phương thức Momo chỉ hỗ trợ tối đa 50tr');
        $this->validate_info($request);

        session(['info'=>json_encode(array_merge( $request->only('name', 'email', 'phone', 'province', 'district', 'wards', 'note', 'list_id'),['code'=>'#'.Str::random(4)]))]);
        $endpoint = "https://test-payment.momo.vn/v2/gateway/api/create";
        $partnerCode = 'MOMOBKUN20180529';
        $accessKey = 'klm05TvNBzhg7h7j';
        $secretKey = 'at67qH6mk8w5Y1nAyMoYKMWACiEi2bsa';
        $orderInfo = 'Thanh Toán Thành Công';
        $amount = $request->total_price;
        $orderId = time() . "";
        $redirectUrl = "http://localhost/Xop-pi.com/public/successMomo.html";
        $ipnUrl = "http://localhost/Xop-pi.com/public/successMomo.html";
        $extraData = "";
        $requestId = time() . "";
        $requestType = "payWithATM";
        //before sign HMAC SHA256 signature
        $rawHash = "accessKey=" . $accessKey . "&amount=" . $amount . "&extraData=" . $extraData . "&ipnUrl=" . $ipnUrl . "&orderId=" . $orderId . "&orderInfo=" . $orderInfo . "&partnerCode=" . $partnerCode . "&redirectUrl=" . $redirectUrl . "&requestId=" . $requestId . "&requestType=" . $requestType;
        $signature = hash_hmac("sha256", $rawHash, $secretKey);
        $data = array(
            'partnerCode' => $partnerCode,
            'partnerName' => "Test",
            "storeId" => "MomoTestStore",
            'requestId' => $requestId,
            'amount' => $amount,
            'orderId' => $orderId,
            'orderInfo' => $orderInfo,
            'redirectUrl' => $redirectUrl,
            'ipnUrl' => $ipnUrl,
            'lang' => 'vi',
            'extraData' => $extraData,
            'requestType' => $requestType,
            'signature' => $signature
        );
        $result = $this->execPostRequest($endpoint, json_encode($data));
        // dd($result);
        $jsonResult = json_decode($result, true);  // decode json

        //Just a example, please check more in there
        return redirect()->to($jsonResult['payUrl']);
        // header('Location: ' . $jsonResult['payUrl']);
    }
    
    public function orderSuccessMomo(Request $request){
        $data = json_decode(session('info'));
        session()->forget('info');
        $total_price = $request->amount;
        $list_id = json_decode($data->list_id);
        $code = $data->code;
        $list_order = [];
        $total_product = 0;
        foreach (Cart::content() as $model) {
            if (in_array($model->id, $list_id)) {
                $list_order[] = $model;
                $total_product += $model->qty;
                Cart::remove($model->rowId);
            }
        }
        $province = DB::table('province')->where('province_id', $data->province)->first()->name;
        $district = DB::table('district')->where('district_id', $data->district)->first()->name;
        $wards = DB::table('wards')->where('wards_id', $data->wards)->first()->name;
        $timezone = new DateTimeZone('Asia/Ho_Chi_Minh');
        $order_detail = [
            'list_order' => $list_order,
            'total_price' => $total_price,
            'name' => $data->name,
            'email' => $data->email,
            'phone' => $data->phone,
            'address_shipping' => $province . ' - ' . $district . ' - ' . $wards . ', ' . $data->note
        ];

        $info_customer = [
            'name' => $data->name,
            'email' => $data->email,
            'phone' => $data->phone,
            'province' => $province,
            'district' => $district,
            'wards' => $wards,
            'note' => $data->note,
        ];
        //check old customer
        $check_old_customer = Customer::where('email', $info_customer['email'])->first();
        if ($check_old_customer) {
            //update old customer
            Customer::where('email', $info_customer['email'])->update($info_customer);
            $customer = Customer::where('email', $info_customer['email'])->first();
        } else {
            //create new
            $customer = Customer::create($info_customer);
        }
        $info_order = [
            'code'=>$code,
            'name' => $data->name,
            'email' => $data->email,
            'phone' => $data->phone,
            'total_product' => $total_product,
            'total_price' => $total_price,
            'order_detail' => json_encode($order_detail),
            'status' => 'đã xác nhận',
            'address_shipping' => $province . ' - ' . $district . ' - ' . $wards,
            'note' => $data->note,
            'payment_method' => 'momo-payment'
        ];
        Order::create($info_order);
        // dd(array_merge($order_detail, $info));
        Mail::to('lamhuutin6879@gmail.com')->send(new orderConfirmMail(array_merge($order_detail, $info_customer, [
            'code'=>$code,
            'delivery_date' => Carbon::now()->setTimezone($timezone)->addDays(3),
            'today' => Carbon::now()->setTimezone($timezone)->format('Y-m-d H:i:s')
        ])));
        $info_customer = cookie('info_customer', json_encode($customer), 259200);
        return redirect()->route('orderDetailSuccess')->withCookie($info_customer)->with('order_detail', $order_detail);
    }
}
