<?php

namespace App\Http\Controllers\client;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductCat;
use GuzzleHttp\Handler\Proxy;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        $idCat = $request->id;
        $productCat_name = ProductCat::find($idCat)->name;
        $productCats = ProductCat::all();
        $list_id = get_list_cat_id($productCats, $idCat);
        $data = Product::join('product_cats', 'product_cats.id', '=', 'products.productCat_id')->whereIn('products.productCat_id', $list_id)->whereNotIn('products.status', ['0'])->select('products.id', 'products.name', 'products.price', 'products.discount', 'products.thumb', 'products.status', 'product_cats.name as cat_name')->paginate(20);
        return view('client.product.index', compact('data', 'productCat_name'));
    }

    public function search(Request $request)
    {
        $keyword = $request->keyword;
        $data = Product::join('product_cats', 'product_cats.id', '=', 'products.productCat_id')->where('products.name', 'like', "%{$keyword}%")->whereNotIn('products.status', ['0'])->select('products.id', 'products.name', 'products.price', 'products.discount', 'products.thumb', 'products.status', 'product_cats.name as cat_name')->paginate(20);
        if ($data->count() == 0) {
            $list_cat = ProductCat::where('name', 'like', "%{$keyword}%")->get();
            $productCats = ProductCat::all();
            $id = [];
            foreach ($list_cat as $cat) {
                $id = array_merge($id, get_list_cat_id($productCats, $cat->id));
            }
            array_unique($id);
            $id = array_unique($id);
            $data = Product::join('product_cats', 'product_cats.id', '=', 'products.productCat_id')->whereIn('products.productCat_id', $id)->whereNotIn('products.status', ['0'])->select('products.id', 'products.name', 'products.price', 'products.discount', 'products.thumb', 'products.status', 'product_cats.name as cat_name')->paginate(20);
        }
        return view('client.product.index', compact('data'));
    }

    public function productDetail(Request $request)
    {
        $id = $request->id;
        $product = Product::where('id', $id)->where('status', '!=', '0')->first();
        $product->images_detail  = json_decode($product->images_detail);
        if (!$product) return abort(404);
        $idcat = get_list_cat_id(ProductCat::all(),$product->productCat_id);
        $data = Product::join('product_cats', 'product_cats.id', '=', 'products.productCat_id')->whereIn('products.productCat_id',$idcat)->whereNotIn('products.id', [$product->id])->whereNotIn('products.status', ['0', '2'])->select('products.id', 'products.name', 'products.price', 'products.discount', 'products.thumb', 'products.status', 'product_cats.name as cat_name')->get();
        return view('client.product.detail', compact('product', 'data'));
    }
}
