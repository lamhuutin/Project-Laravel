<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Role;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Gate;


class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            session(['module' => 'user']);
            return $next($request);
        });
    }
    public function index(Request $request)
    {
        $status = $request->status;
        $keyword = $request->keyword;
        if ($status === 'trash') {
            $data = User::onlyTrashed()->where('name', 'like', "%{$keyword}%")->paginate(20);
        } else {
            $data = User::where('name', 'like', "%{$keyword}%")->paginate(20);
        }
        $count = [
            'active' => User::count(),
            'trash' => User::onlyTrashed()->count()
        ];
        return view('admin.user.index', compact('data', 'count'));
    }

    public function create()
    {
        return view('admin.user.create');
    }

    public function store(Request $request)
    {
        $request->validate(
            [
                'name' => 'required|string|max:255',
                'email' => 'required|string|email|max:255|unique:users',
                'password' => 'required|string|min:8|regex:/^[A-Z]{1}([\w_\.!@#$%^&*()]+){7,31}$/|confirmed'
            ],
            [
                'required' => ':attribute Không được để trống',
                'max' => ':attribute có tối đa 255 ký tự',
                'string' => ':attribute phải ở dạng chuỗi ký tự',
                'unique' => ':attribute đã tồn tại',
                'confirmed' => ':attribute Không chính xác',
                'regex' => 'Mật khẩu phải có ký tự đầu là chữ cái in hoa và có ít nhất 8 ký tự'
            ],
            [
                'name' => 'Họ và Tên',
                'email' => 'Địa chỉ Email',
                'password' => 'Mật Khẩu'
            ]
        );
        $user = User::create([
            'name' => $request->name,
            'password' => Hash::make($request->password),
            'email' => $request->email,
        ]);
        $user->sendEmailVerificationNotification();
        return redirect()->back()->with('status', 'Bạn đã thêm user thành công, bạn vui lòng đăng nhập để kích hoạt xác nhận email');
    }

    public function edit($id)
    {
        $data = User::find($id);
        $roles = Role::all();
        return view('admin.user.edit', compact('data', 'roles'));
    }

    public function update(Request $request, $id)
    {
        $user = User::find($id);
        if (Auth::id() === $id) {
            $request->validate(
                [
                    'name' => 'nullable|string|max:255',
                    'password' => 'nullable|string|min:8|confirmed'
                ],
                [
                    'max' => ':attribute có tối đa :max ký tự',
                    'min' => ':attribute có ít nhất :min ký tự',
                    'string' => ':attribute phải ở dạng chuỗi ký tự',
                    'confirmed' => ':attribute xác nhận Không chính xác'
                ],
                [
                    'name' => 'Họ và Tên',
                    'password' => 'Mật Khẩu'
                ]
            );
            $data = ['name' => $request->name];
            if ($request->password) {
                $data['password'] = Hash::make($request->password);
            }
            $user->update($data);
        }
        $user->roles()->sync($request->role);
        return redirect()->route('admin.user.index')->with('status', 'Đã cập nhật thông tin thành công');
    }

    public function destroy(Request $request, $id)
    {
        $user = User::withTrashed()->find($id);
        if (!$user) {
            return redirect()->route('admin.user.index')->with('fail', 'không tìm thấy user có id phù hợp');
        }
        $forceDelete =  $request->forceDelete;
        if ($forceDelete === 'ok') {
            $user->forceDelete();
            return redirect()->route('admin.user.index')->with('status', 'đã xoá vĩnh viến user');
        }
        $user->delete();
        return redirect()->route('admin.user.index')->with('status', 'đã xoá tạm thời user');
        // User::find($id)->delete();
        // return redirect()->back()->with('status', 'Đã Xoá tạm thời user');
    }

    public function restore($id)
    {
        $user = User::onlyTrashed()->find($id);
        if (!$user) {
            return redirect()->route('admin.user.restore')->with('fail', 'không tìm thấy user có id phù hợp để đưa trở lại');
        }
        $user->restore();
        return redirect()->route('admin.user.index')->with('status', 'Đã đưa user trở lại');
    }

    public function action(Request $request)
    {
        $action = $request->action;
        if (!$action) {
            return redirect()->back()->with('fail', 'Vui lòng chọn thao tác bạn muốn thực hiện');
        }
        $id = $request->id;
        if (!$id) {
            return redirect()->back()->with('fail', 'Vui lòng chọn user trước khi thực hiện thao tác');
        }
        if ($action === 'delete') {
            if (! Gate::allows('admin.user.destroy')) {
                abort(403);
            }
            User::withoutTrashed()->whereIn('id', $id)->delete();
            return redirect()->back()->with('status', 'đã xoá tạm thời user');
        }
        if ($action === 'forceDelete') {
            if (! Gate::allows('admin.user.destroy')) {
                abort(403);
            }
            User::onlyTrashed()->whereIn('id', $id)->forceDelete();
            return redirect()->back()->with('status', 'đã xoá vĩnh viễn user');
        }
        if ($action === 'restore') {
            User::onlyTrashed()->whereIn('id', $id)->restore();
            return redirect()->back()->with('status', 'đã đưa user trở lại');
        }
    }
}
