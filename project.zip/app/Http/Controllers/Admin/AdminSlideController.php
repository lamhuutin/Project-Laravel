<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Slide;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;

class AdminSlideController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            session(['module' => 'slide']);
            return $next($request);
        });
    }
    public function index(Request $request)
    {
        if (!Gate::allows('admin.slide.index')) {
            abort(403);
        }
        $status = $request->status;
        $keyword = $request->keyword;
        if ($status === 'trash') {
            $data = Slide::onlyTrashed()->where('name', 'like', "%{$keyword}%")->paginate(20);
        } elseif ($status === 'arrange') {
            $data = Slide::withoutTrashed()->where('status', '1')->where('name', 'like', "%{$keyword}%")->paginate(20);
        } else {
            $data = Slide::where('name', 'like', "%{$keyword}%")->paginate(20);
        }
        $count = [Slide::all()->count(), Slide::onlyTrashed()->count()];
        return view('admin.slide.index', compact('data', 'count'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!Gate::allows('admin.slide.create')) {
            abort(403);
        }
        return view('admin.slide.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (!Gate::allows('admin.slide.create')) {
            abort(403);
        }
        $request->validate(
            [
                'name' => 'required|max:255',
                'file_thumb' => 'required|image|max:2048|dimensions:min_width=878,min_height=370,max_width=1920,max_height=1080|mimes:jpeg,png,jpg,gif'
            ],
            [
                'required' => ':attribute không được để trống',
                'max' => ':attribute có kích thước tối đa :max',
                'image' => 'file upload phải là file ảnh',
                'dimensions' => 'ảnh upload có kích thước bé nhất là 878x370 và lớn nhất là 1920x1080',
                'mines' => 'file ảnh upload có phần đuôi jpeg,png,jpg,gif'
            ],
            [
                'name' => 'Tên Slide',
                'file_thumb' => 'file ảnh upload'
            ]
        );
        $file_thumb = $request->file('file_thumb');
        $extension = $file_thumb->extension();
        $thumb_name = time() . '-slide.' . $extension;
        $request->merge(['thumb' => $thumb_name, 'user_id' => Auth::id()]);
        $file_thumb->move(public_path('uploads'), $thumb_name);
        Slide::create($request->all());
        return redirect()->route('admin.slide.index')->with('status', 'Đã thêm slide thành công');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (!Gate::allows('admin.slide.edit')) {
            abort(403);
        }
        $data = Slide::withoutTrashed()->find($id);
        if (!$data) return abort(404);
        return view('admin.slide.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (!Gate::allows('admin.slide.edit')) {
            abort(403);
        }
        $request->validate(
            [
                'name' => 'required|max:255',
                'file_thumb' => 'image|max:2048|dimensions:min_width=878,min_height=370,max_width=1920,max_height=1080|mimes:jpeg,png,jpg,gif'
            ],
            [
                'required' => ':attribute không được để trống',
                'max' => ':attribute có kích thước tối đa :max',
                'image' => 'file upload phải là file ảnh',
                'dimensions' => 'ảnh upload có kích thước bé nhất là 878x370 và lớn nhất là 1920x1080',
                'mines' => 'file ảnh upload có phần đuôi jpeg,png,jpg,gif'
            ],
            [
                'name' => 'Tên Slide',
                'file_thumb' => 'file ảnh upload'
            ]
        );
        $file_thumb = $request->file('file_thumb');
        if ($file_thumb) {
            $old_thumb = Slide::find($id)->thumb;
            if (file_exists(public_path('uploads/' . $old_thumb))) unlink(public_path('uploads/' . $old_thumb));
            $extension = $file_thumb->extension();
            $thumb_name = time() . '-slide.' . $extension;
            $request->merge(['thumb' => $thumb_name]);
            $file_thumb->move(public_path('uploads'), $thumb_name);
        }
        Slide::find($id)->update($request->all());
        return redirect()->route('admin.slide.index')->with('status', 'đã cập nhật slide thành công');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        if (!Gate::allows('admin.slide.destroy')) {
            abort(403);
        }
        $forceDelete = $request->forceDelete;
        if ($forceDelete === 'ok') {
            $data = Slide::onlyTrashed()->find($id);
            if (!$data) return abort(404);
            unlink(public_path('uploads/' . $data->thumb));
            $data->forceDelete();
            $status = 'đã xoá vĩnh viễn slide';
        } else {
            $data = Slide::withTrashed()->find($id);
            if (!$data) return abort(404);
            $data->delete();
            $status = 'đã chuyển slide vào thùng rác';
        }
        return redirect()->route('admin.slide.index')->with('status', $status);
    }

    public function restore($id)
    {
        if (!Gate::allows('admin.slide.edit')) {
            abort(403);
        }
        $data = Slide::onlyTrashed()->find($id);
        if (!$data) return abort(404);
        $data->restore();
        return redirect()->route('admin.slide.index')->with('status', 'đã đưa slide trở lại');
    }

    public function action(Request $request)
    {
        if (!Gate::allows('admin.slide.edit')) {
            abort(403);
        }
        $request->validate(
            [
                'action' => 'not_in:0',
                'id' => 'required'
            ],
            [
                'not_in' => 'Vui lòng chọn thao tác bạn muốn thực hiện',
                'required' => 'Vui lòng chọn slide bạn muốn thực hiện thao tác'
            ]
        );
        // dd($request->all());
        $action = $request->action;
        $id = $request->id;
        if ($action === 'arrange') {
            foreach ($id as $key => $val) {
                Slide::withoutTrashed()->find($key)->update(['display_order' => $val]);
            }
            $status = 'Đã Cập Nhật Thứ Tự Hiển Thị Cho Slide';
        }
        if ($action === 'active') {
            Slide::withoutTrashed()->whereIn('id', $id)->update(['status' => '1']);
            $status = 'Đã cập nhật trạng thái hiển thị thành công';
        }
        if ($action === 'hide') {
            Slide::withoutTrashed()->whereIn('id', $id)->update(['status' => '0']);
            $status = 'Đã cập nhật trạng thái chờ duyệt thành công';
        }
        if ($action === 'delete') {
            if (!Gate::allows('admin.slide.destroy')) {
                abort(403);
            }
            Slide::withoutTrashed()->whereIn('id', $id)->delete();
            $status = 'Đã chuyển slide vào thùng rác thành công';
        }
        if ($action === 'forceDelete') {
            if (!Gate::allows('admin.slide.destroy')) {
                abort(403);
            }
            foreach ($id as $i) {
                $data = Slide::onlyTrashed()->find($i);
                unlink(public_path('uploads/' . $data->thumb));
            }
            Slide::onlyTrashed()->whereIn('id', $id)->forceDelete();
            $status = 'Đã chuyển xoá vĩnh viễn slide thành công';
        }
        if ($action === 'restore') {
            Slide::onlyTrashed()->whereIn('id', $id)->restore();
            $status = 'Đã đưa slide trở lại thành công';
        }
        return redirect()->route('admin.slide.index')->with('status', $status);
    }

    public function arrange(Request $request)
    {
        if (!Gate::allows('admin.slide.edit')) {
            abort(403);
        }
        $data = Slide::withTrashed()->where('status', '1')->paginate(20);
        $count = [Slide::all()->count(), Slide::onlyTrashed()->count()];
        return view('admin.slide.arrange', compact('data', 'count'));
    }
}
