<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Post;
use App\Models\PostCat;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Gate;

class AdminPostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            session(['module' => 'post']);
            return $next($request);
        });
    }
    public function index(Request $request)
    {
        if (!Gate::allows('admin.post.index')) {
            abort(403);
        }
        $status = $request->status;
        $keyword = $request->keyword;
        $count = [Post::all()->count(), Post::onlyTrashed()->count()];
        if ($status === 'trash') {
            $data = Post::onlyTrashed()->where('title', 'like', "%{$keyword}%")->with(['user', 'postCat'])->paginate(20);
        } else {
            $data = Post::where('title', 'like', "%{$keyword}%")->with(['user', 'postCat'])->paginate(20);
        }
        return view('admin.post.index', compact('data', 'count'));
        // $data = Post::where('title', 'like', "%%")->with(['user','postCat'])->paginate(20);
        // $posts = Post::with(['user' => function ($query) {
        //     $query->select('id', 'name', 'email');
        // }, 'postCat' => function ($query) {
        //     $query->select('id', 'name');
        // },])->first();
        // return $posts->user;
        // $data = Post::where('title', 'like', "% %") -> with(['user','postCat']) -> paginate(20);
        // return $data;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!Gate::allows('admin.post.create')) {
            abort(403);
        }
        $postCats = PostCat::all();
        $data = data_tree($postCats);
        return view('admin.post.create', compact('data'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (!Gate::allows('admin.post.create')) {
            abort(403);
        }
        $request->validate(
            [
                'title' => 'required|max:255',
                'file_thumb' => 'required|image|mimes:png,jpg,jpeg,gif|max:2048',
                'desc' => 'required|max:400',
                'content' => 'required',
                'postCat_id' => 'not_in:0'
            ],
            [
                'required' => ':attribute không được để trống',
                'image' => ':attribute không phải file ảnh',
                'mimes' => ':attribute phải có đuôi png, jpg, jpeg, gif',
                'max' => ':attribute có tối đa :max ký tự',
                'not_in' => 'bạn chưa chọn danh mục bài viết'
            ],
            [
                'title' => 'Tiêu đề bài viết',
                'file_thumb' => 'file tải lên',
                'desc' => 'mô tả ngắn',
                'content' => 'nội dung bài viết'
            ]
        );
        $file_thumb = $request->file('file_thumb');
        $extension = $file_thumb->extension();
        $thumb_name = time() . '-' . 'post.' . $extension;
        $request->merge(['thumb' => $thumb_name, 'user_id' => Auth::id()]);
        $file_thumb->move(public_path('uploads'), $thumb_name);
        Post::create($request->all());
        return redirect()->route('admin.post.index')->with('status', 'Đã thêm bài viết thành công');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (!Gate::allows('admin.post.edit')) {
            abort(403);
        }
        $post = Post::find($id);
        if (!$post) return abort(404);
        $postCats = PostCat::all();
        $data = data_tree($postCats);
        return view('admin.post.edit', compact('post', 'data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (!Gate::allows('admin.post.edit')) {
            abort(403);
        }
        $request->validate(
            [
                'title' => 'required|max:255',
                'file_thumb' => 'image|mimes:png,jpg,jpeg,gif|max:2048',
                'desc' => 'required|max:400',
                'content' => 'required',
                'postCat_id' => 'not_in:0'
            ],
            [
                'required' => ':attribute không được để trống',
                'image' => ':attribute không phải file ảnh',
                'mimes' => ':attribute phải có đuôi png, jpg, jpeg, gif',
                'max' => ':attribute có tối đa :max ký tự',
                'not_in' => 'bạn chưa chọn danh mục bài viết'
            ],
            [
                'title' => 'Tiêu đề bài viết',
                'file_thumb' => 'file tải lên',
                'desc' => 'mô tả ngắn',
                'content' => 'nội dung bài viết'
            ]
        );
        $file_thumb = $request->file('file_thumb');
        if ($file_thumb) {
            $old_file = Post::find($id);
            $path = public_path('uploads/' . $old_file->thumb);
            if (file_exists($path)) unlink($path);
            $extension = $file_thumb->extension();
            $thumb_name = time() . '-' . 'post.' . $extension;
            $request->merge(['thumb' => $thumb_name]);
            $file_thumb->move(public_path('uploads'), $thumb_name);
        }
        Post::find($id)->update($request->all());
        return redirect()->route('admin.post.index')->with('status', 'Đã cập nhật bài viết thành công');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        if (!Gate::allows('admin.post.destroy')) {
            abort(403);
        }
        $forceDelete = $request->forceDelete;
        if ($forceDelete === 'ok') {
            Post::onlyTrashed()->find($id)->forceDelete();
            return redirect()->route('admin.post.index')->with('status', 'Đã xoá vĩnh viễn bài viết');
        }
        Post::withoutTrashed()->find($id)->delete();
        return redirect()->route('admin.post.index')->with('status', 'Đã chuyển bài viết vào thùng rác');
    }

    public function action(Request $request)
    {
        if (!Gate::allows('admin.post.edit')) {
            abort(403);
        }
        $request->validate(
            [
                'action' => 'not_in:0',
                'id' => 'required'
            ],
            [
                'required' => 'vui lòng chọn bài viết bạn muốn thực hiện',
                'not_in' => 'vui lòng chọn thao tác bạn muốn thực hiện'
            ],
        );
        $action = $request->action;
        $id = $request->id;
        if ($action === 'active') {
            Post::whereIn('id', $id)->update(['status' => '1']);
            $status = 'cập nhật trạng thái hiển thị';
        }
        if ($action === 'hide') {
            Post::whereIn('id', $id)->update(['status' => '0']);
            $status = 'cập nhật trạng thái chờ duyệt';
        }
        if ($action === 'delete') {
            if (!Gate::allows('admin.post.destroy')) {
                abort(403);
            }
            Post::withoutTrashed()->whereIn('id', $id)->delete();
            $status = 'Đã chuyển bài viết vào thùng rác';
        }
        if ($action === 'restore') {
            Post::onlyTrashed()->whereIn('id', $id)->restore();
            $status = 'Đã đưa bài viết trở lại';
        }
        if ($action === 'forceDelete') {
            if (!Gate::allows('admin.post.destroy')) {
                abort(403);
            }
            Post::onlyTrashed()->whereIn('id', $id)->forceDelete();
            $status = 'Đã xoá vĩnh viễn viết';
        }
        return redirect()->route('admin.post.index')->with('status', $status);
    }

    public function restore($id)
    {
        if (!Gate::allows('admin.post.edit')) {
            abort(403);
        }
        $post = Post::onlyTrashed()->find($id);
        if (!$post) return abort(404);
        $post->restore();
        return redirect()->route('admin.post.index')->with('status', 'Đã đưa bài viết trở lại');
    }
}
