<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\ProductCat;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class AdminProductCatController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            session(['module' => 'product']);
            return $next($request);
        });
    }
    public function index()
    {
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!Gate::allows('admin.product.create')) {
            abort(403);
        }
        $productCats = ProductCat::all();
        $data = data_tree($productCats);
        return view('admin.productCat.create', compact('data'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (!Gate::allows('admin.product.create')) {
            abort(403);
        }
        $request->validate(
            [
                'name' => 'required|max:255',
            ],
            [
                'required' => ':attribute Không được để trống',
                'max' => ':attribute có tối đa :max ký tự'
            ],
            [
                'name' => 'tên danh mục sản phẩm'
            ]
        );
        ProductCat::create($request->all());
        return redirect()->route('admin.productCat.create')->with('status', 'Đã thêm thành công danh mục sản phẩm');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (!Gate::allows('admin.product.create')) {
            abort(403);
        }
        $productCat = ProductCat::find($id);
        if (!$productCat) return abort(404);
        $productCats = ProductCat::all();
        $data = data_tree($productCats);
        return view('admin.productCat.edit', compact('data', 'productCat'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (!Gate::allows('admin.product.create')) {
            abort(403);
        }
        $request->validate(
            [
                'name' => 'required|max:255',
            ],
            [
                'required' => ':attribute Không được để trống',
                'max' => ':attribute có tối đa :max ký tự'
            ],
            [
                'name' => 'tên danh mục sản phẩm'
            ]
        );
        ProductCat::find($id)->update($request->all());
        return redirect()->route('admin.productCat.create')->with('status', 'Đã cập nhật danh mục bài viết thành công');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (!Gate::allows('admin.product.create')) {
            abort(403);
        }
        $productCats = ProductCat::all();
        if (has_child($productCats, $id)) return redirect()->route('admin.productCat.create')->with('fail', 'Không thể xoá danh mục sản phẩm này vì vẫn còn danh mục con thuộc danh mục này');
        ProductCat::find($id)->delete();
        return redirect()->route('admin.productCat.create')->with('status', 'đã xoá danh mục sản phẩm thành công');
    }
}
