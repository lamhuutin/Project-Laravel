<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Permission;
use App\Models\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
class AdminRoleController extends Controller
{
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            session(['module' => 'role']);
            return $next($request);
        });
    }
    public function index(Request $request)
    {
        $roles = Role::all();
        return view('admin.role.index', compact('roles'));
    }
    public function create(Request $request)
    {
        $permissions = Permission::all()->groupBy(function ($permission) {
            return explode('.', $permission)[1];
        });
        return view('admin.role.create', compact('permissions'));
    }
    public function store(Request $request)
    {
        $request->validate(
            [
                'name' => 'required|max:255|unique:roles,name',
                'desc' => 'required'
            ],
            [
                'name.required' => 'tên vai trò Không được để trống',
                'desc.required' => 'mô tả Không được để trống',
                'max' => ':attribute có tối đa :max ký tự',
                'unique' => 'tên vai trò đã tồn tại'
            ]
        );
        // dd($request->permission_id);
        $role = Role::create($request->only('name', 'desc'));
        $role->permissions()->attach($request->permission_id);
        return redirect()->back()->with('status', 'Đã Tạo Vai Trò Thành Công');
    }
    public function edit(Request $request, Role $role)
    {
        $permissions = Permission::all()->groupBy(function ($permission) {
            return explode('.', $permission)[1];
        });
        // dd($role->permissions->pluck('id')->toArray());
        return view('admin.role.edit', compact('role', 'permissions'));
    }
    public function update(Request $request, Role $role)
    {
        $request->validate(
            [
                'name' => 'required|max:255|unique:roles,name,' . $role->id,
                'desc' => 'required'
            ],
            [
                'name.required' => 'tên vai trò Không được để trống',
                'desc.required' => 'mô tả Không được để trống',
                'max' => ':attribute có tối đa :max ký tự',
                'unique' => 'tên vai trò đã tồn tại'
            ]
        );
        $role->update($request->only('name', 'desc'));
        $role->permissions()->sync($request->permission_id);
        return redirect()->back()->with('status', 'Đã chỉnh sửa vai trò thành công');
    }
    public function destroy(Role $role){
        $role->delete();
        return redirect()->route('admin.role.index')->with('status','đã xoá quyền thành công');
    }
}
