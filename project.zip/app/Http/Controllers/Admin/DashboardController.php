<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Permission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class DashboardController extends Controller
{
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            session(['module' => 'dashboard']);
            return $next($request);
        });
    }
    function dashboard(Request $request)
    {
        $count =[
          Order::withTrashed()->where('status','đã xác nhận')->count(),
          Order::withTrashed()->where('status','đang vận chuyển')->count(),
          Order::withTrashed()->where('status','hoàn thành')->sum('total_price'),
          Order::withTrashed()->where('status','đã huỷ')->count()
        ];
        $data = Order::where('status','đã xác nhận')-> orderby('id','desc') -> paginate(20);
        return view('admin.dashboard',compact('data','count'));
    }
}
