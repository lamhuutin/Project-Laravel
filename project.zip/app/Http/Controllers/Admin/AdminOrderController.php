<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;

use function PHPSTORM_META\map;

class AdminOrderController extends Controller
{
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            session(['module' => 'order']);
            return $next($request);
        });
    }
    public function index(Request $request)
    {
        $status = $request->status;
        $keyword = $request->keyword;
        $order_type = $request->order_type;
        $count = [
            Order::all()->count(),
            Order::withTrashed()->where('status', 'đã xác nhận')->count(),
            Order::withTrashed()->where('status', 'đang vận chuyển')->count(),
            Order::withTrashed()->where('status', 'hoàn thành')->count(),
            Order::withTrashed()->where('status', 'đã huỷ')->count(),
            Order::onlyTrashed()->count()
        ];
        if ($order_type) {
            $data = Order::withTrashed()->where('status', $order_type)->where(function ($query) use ($keyword) {
                $query->where('code', 'like', "%{$keyword}%")
                    ->orWhere('name', 'like', "%{$keyword}%");
            })->orderBy('id', 'desc')->paginate(20);
        } else {
            if ($status === 'trash') {
                $data =  Order::onlyTrashed()->where(function ($query) use ($keyword) {
                    $query->where('code', 'like', "%{$keyword}%")
                        ->orWhere('name', 'like', "%{$keyword}%");
                })->orderBy('id', 'desc')->paginate(20);
            } else {
                $data = Order::withoutTrashed()->where(function ($query) use ($keyword) {
                    $query->where('code', 'like', "%{$keyword}%")
                        ->orWhere('name', 'like', "%{$keyword}%");
                })->orderBy('id', 'desc')->paginate(20);
            }
        }
        return view('admin.order.index', compact('data', 'count'));
    }

    public function edit(Request $request, $id)
    {
        $data = Order::withoutTrashed()->find($id);
        if (!$data) return abort(404);
        $data->order_detail = json_decode($data->order_detail);
        return view('admin.order.edit', compact('data'));
    }

    public function update(Request $request, $id)
    {
        $data = Order::withoutTrashed()->find($id);
        if (!$data) return abort(404);
        $data->status = $request->status;
        $data->save();
        return redirect()->route('admin.order.index')->with('status', 'đã cập nhật trạng thái đơn hàng thành công');
    }

    public function destroy(Request $request, $id)
    {
        $forceDelete = $request->forceDelete;
        if ($forceDelete === 'ok') {
            $data = Order::onlyTrashed()->find($id);
            if (!$data) return abort(404);
            $data->forceDelete();
            $status = 'đã xoá vĩnh viễn đơn hàng';
        } else {
            $data = Order::withoutTrashed()->find($id);
            if (!$data) return abort(404);
            if (!in_array($data->status, ['hoàn thành', 'đã huỷ'])) return redirect()->route('admin.order.index')->with('fail', 'chỉ được xoá đơn hàng đã hoàn thành hoặc đã huỷ');
            $data->delete();
            $status = 'đã chuyển đơn hàng vào thùng rác';
        }
        return redirect()->route('admin.order.index')->with('status', $status);
    }
    public function restore($id)
    {
        $data = Order::onlyTrashed()->find($id);
        if (!$data) return abort(404);
        $data->restore();
        return redirect()->route('admin.order.index')->with('status', 'đã đưa đơn hàng trở lại');
    }
    public function action(Request $request)
    {
        $request->validate(
            [
                'action' => 'not_in:0',
                'id' => 'required'
            ],
            [
                'not_in' => 'Vui lòng chọn thao tác bạn muốn thao tác',
                'required' => 'Vui lòng chọn đơn hàng bạn muốn thao tác'
            ]
        );
        $action = $request->action;
        $id = $request->id;
        if ($action === 'đã xác nhận') {
            Order::withoutTrashed()->whereIn('id', $id)->update(['status' => 'đã xác nhận']);
            $status = 'đã thay đổi trạng thái đơn hàng thành công';
        }
        if ($action === 'đang vận chuyển') {
            Order::withoutTrashed()->whereIn('id', $id)->update(['status' => 'đang vận chuyển']);
            $status = 'đã thay đổi trạng thái đơn hàng thành công';
        }
        if ($action === 'hoàn thành') {
            Order::withoutTrashed()->whereIn('id', $id)->update(['status' => 'hoàn thành']);
            $status = 'đã thay đổi trạng thái đơn hàng thành công';
        }
        if ($action === 'đã huỷ') {
            Order::withoutTrashed()->whereIn('id', $id)->update(['status' => 'đã huỷ']);
            $status = 'đã thay đổi trạng thái đơn hàng thành công';
        }
        if ($action === 'delete') {
            Order::withoutTrashed()->whereNotIn('status', ['đã xác nhận', 'đang vận chuyển'])->whereIn('id', $id)->delete();
            $status = 'đã chuyển đơn hàng đã hoàn thành hoặc đã xoá vào thùng rác';
        }
        if ($action === 'restore') {
            Order::onlyTrashed()->whereIn('id', $id)->restore();
            $status = 'đã chuyển đơn hàng đã hoàn thành hoặc đã xoá vào thùng rác';
        }
        if ($action === 'forceDelete') {
            Order::onlyTrashed()->whereIn('id', $id)->forceDelete();
            $status = 'Xoá vĩnh viễn đơn hàng';
        }
        return redirect()->route('admin.order.index')->with('status', $status);
    }
}
