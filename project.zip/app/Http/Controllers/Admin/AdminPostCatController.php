<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Page;
use App\Models\Post;
use App\Models\PostCat;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class AdminPostCatController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            session(['module' => 'post']);
            return $next($request);
        });
    }
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!Gate::allows('admin.post.create')) {
            abort(403);
        }
        $postCats = PostCat::all();
        $data = data_tree($postCats);
        return view('admin.postCat.create', compact('data'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (!Gate::allows('admin.post.create')) {
            abort(403);
        }
        $request->validate(
            [
                'name' => 'required|max:255'
            ],
            [
                'required' => ':attribute không đươc để trống',
                'max' => ':attribute có tối đa :max ký tự',
            ],
            [
                'name' => 'Tên danh mục'
            ]
        );
        PostCat::create($request->all());
        return redirect()->back()->with('status', 'Đã thêm danh mục bài viết thành công');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (!Gate::allows('admin.post.create')) {
            abort(403);
        }
        $postCat = PostCat::find($id);
        if (!$postCat) return abort(404);
        $postCats = PostCat::all();
        $data = data_tree($postCats);
        return view('admin.postCat.edit', compact('postCat', 'data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (!Gate::allows('admin.post.create')) {
            abort(403);
        }
        $request->validate(
            [
                'name' => 'required|max:255'
            ],
            [
                'required' => ':attribute không đươc để trống',
                'max' => ':attribute có tối đa :max ký tự',
            ],
            [
                'name' => 'Tên danh mục'
            ]
        );
        PostCat::find($id)->update($request->all());
        return redirect()->route('admin.postCat.create')->with('status', 'Đã cập nhật danh mục thành công');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (!Gate::allows('admin.post.create')) {
            abort(403);
        }
        $postCats = PostCat::all();
        if (has_child($postCats, $id)) return redirect()->route('admin.postCat.create')->with('fail', 'Không thể xoá danh mục này vì vẫn còn danh mục con thuộc danh mục này');
        if (Post::where('postCat_id', $id)->get()->count()) return redirect()->route('admin.postCat.create')->with('fail', 'Không thể xoá danh mục này vì vẫn còn bài viết thuộc danh mục này');
        PostCat::find($id)->delete();
        return redirect()->route('admin.postCat.create')->with('status', 'đã xoá thành công danh mục bài viết');
    }
}
