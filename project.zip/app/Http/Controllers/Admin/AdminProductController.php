<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductCat;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;

class AdminProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            session(['module' => 'product']);
            return $next($request);
        });
    }
    public function index(Request $request)
    {
        if (!Gate::allows('admin.product.index')) {
            abort(403);
        }
        $status = $request->status;
        $keyword = $request->keyword;
        $count = [Product::all()->count(), Product::onlyTrashed()->count()];
        if ($status == 'trash') {
            $data = Product::onlyTrashed()->join('product_cats', 'product_cats.id', '=', 'products.productCat_id')->select('products.*', 'product_cats.name as productCat_name')->where('products.name', 'like', "%{$keyword}%")->paginate(20);
        } else {
            $data = Product::join('product_cats', 'product_cats.id', '=', 'products.productCat_id')->select('products.*', 'product_cats.name as productCat_name')->where('products.name', 'like', "%{$keyword}%")->paginate(20);
        }
        return view('admin.product.index', compact('data', 'count'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!Gate::allows('admin.product.create')) {
            abort(403);
        }
        $productCats = ProductCat::all();
        $data = data_tree($productCats);
        return view('admin.product.create', compact('data'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (!Gate::allows('admin.product.create')) {
            abort(403);
        }
        $request->validate(
            [
                'name' => 'required|string|max:255',
                'price' => 'required|regex:/^[0-9]+$/|min:0',
                'discount' => 'nullable|regex:/^[0-9]+$/|min:0',
                'file_thumb' => 'required|image|mimes:jpeg,jpg,png,gif|max:2048',
                'images.*' => 'image|mimes:jpeg,jpg,png,gif|max:2048',
                'desc' => 'max:500',
            ],
            [
                'required' => ':attribute Không được để trống',
                'string' => ':attribute phải ở dạng chuỗi',
                'name.max' => ':attribute có tối đa :max ký tự',
                'desc.max' => ':attribute có tối đa :max ký tự',
                'regex' => ':attribute chỉ có các số từ 0-9 và không bao gồm ký tự',
                'max' => ':attribute có kích thước tối đa :max byte',
                'numberic' => ':attribute phải ở dạng số',
                'min' => ':attribute có giá trị nhỏ nhất là :min',
                'image' => ':attribute không phải ảnh',
                'mimes' => ':attribute phải có đuôi jpeg,jpg,png,gif'
            ],
            [
                'name' => 'Tên sản phẩm',
                'price' => 'giá sản phẩm',
                'discount' => 'giá khuyến mãi',
                'file_thumb' => 'ảnh đại diện của sản phẩm',
                'images.*' => 'ảnh chi tiết của sản phẩm',
                'desc' => 'mô tả ngắn của sản phẩm',
                'content' => 'chi tiết sản phẩm',
            ]
        );
        $images = $request->file('images');
        if ($images) {
            $images_detail = [];
            $t = 1;
            foreach ($images as $item) {
                $extension = $item->extension();
                $image_name = $t++ . '-' . time() . '-' . 'product-detail.' . $extension;
                $item->move(public_path('uploads'), $image_name);
                $images_detail[] = $image_name;
            }
            $images_detail = json_encode($images_detail);
            $request->merge(['images_detail' => $images_detail]);
        }
        $file_thumb = $request->file('file_thumb');
        $extension = $file_thumb->extension();
        $thumb_name = time() . '-' . 'product-thumb.' . $extension;
        $file_thumb->move(public_path('uploads'), $thumb_name);
        $request->merge(['thumb' => $thumb_name, 'user_id' => Auth::id()]);
        Product::create($request->all());
        return redirect()->route('admin.product.create')->with('status', 'Đã thêm sản phẩm mới thành công');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (!Gate::allows('admin.product.edit')) {
            abort(403);
        }
        $product = Product::withoutTrashed()->find($id);
        if (!$product) return abort(404);
        $productCats = ProductCat::all();
        $data = data_tree($productCats);
        $product->images_detail = json_decode($product->images_detail);
        return view('admin.product.edit', compact('data', 'product'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (!Gate::allows('admin.product.edit')) {
            abort(403);
        }
        $request->validate(
            [
                [
                    'name' => 'required|string|max:255',
                    'price' => 'required|regex:/^[0-9]+$/|min:0',
                    'discount' => 'nullable|regex:/^[0-9]+$/|min:0',
                    'file_thumb' => 'image|mimes:jpeg,jpg,png,gif|max:2048',
                    'images.*' => 'image|mimes:jpeg,jpg,png,gif|max:2048',
                    'desc' => 'max:500',
                ],
                [
                    'required' => ':attribute Không được để trống',
                    'string' => ':attribute phải ở dạng chuỗi',
                    'name.max' => ':attribute có tối đa :max ký tự',
                    'desc.max' => ':attribute có tối đa :max ký tự',
                    'regex' => ':attribute chỉ có các số từ 0-9 và không bao gồm ký tự',
                    'max' => ':attribute có kích thước tối đa :max byte',
                    'numberic' => ':attribute phải ở dạng số',
                    'min' => ':attribute có giá trị nhỏ nhất là :min',
                    'image' => ':attribute không phải ảnh',
                    'mimes' => ':attribute phải có đuôi jpeg,jpg,png,gif'
                ],
                [
                    'name' => 'Tên sản phẩm',
                    'price' => 'giá sản phẩm',
                    'discount' => 'giá khuyến mãi',
                    'file_thumb' => 'ảnh đại diện của sản phẩm',
                    'images.*' => 'ảnh chi tiết của sản phẩm',
                    'desc' => 'mô tả ngắn của sản phẩm',
                    'content' => 'chi tiết sản phẩm',
                ]
            ]
        );

        $product = Product::find($id);
        $file_thumb = $request->file('file_thumb');
        if ($file_thumb) {
            $path_old_thumb = public_path('uploads/' . $product->thumb);
            if (file_exists($path_old_thumb)) unlink($path_old_thumb);
            $extension = $file_thumb->extension();
            $thumb_name = time() . '-' . 'product-thumb.' . $extension;
            $file_thumb->move(public_path('uploads'), $thumb_name);
            $request->merge(['thumb' => $thumb_name]);
        }
        $file_images = $request->file('images');
        if ($file_images) {
            $product->images_detail = json_decode($product->images_detail);
            foreach ($product->images_detail as $old_image) {
                $path_old_image_detail = public_path('uploads/' . $old_image);
                if (file_exists($path_old_image_detail)) unlink($path_old_image_detail);
            }
            $images_detail = [];
            $t = 1;
            foreach ($file_images as $new_image) {
                $extension = $new_image->extension();
                $image_detail_item = $t++ . '-' . time() . '-' . 'product-detail.' . $extension;
                $new_image->move(public_path('uploads'), $image_detail_item);
                $images_detail[] = $image_detail_item;
            }
            $request->merge(['images_detail' => json_encode($images_detail)]);
        }
        $product->update($request->all());
        return redirect()->route('admin.product.index')->with('status', 'đã chỉnh sửa sản phẩm thành công');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        if (!Gate::allows('admin.product.destroy')) {
            abort(403);
        }
        $forceDelete = $request->forceDelete;
        if ($forceDelete === 'ok') {
            $product =  Product::onlyTrashed()->find($id);
            if (file_exists('uploads/' . $product->thumb)) unlink(public_path('uploads/' . $product->thumb));
            $images_detail = json_decode($product->images_detail, true);
            foreach ($images_detail as $image) {
                if (file_exists(public_path('uploads/' . $image))) unlink(public_path('uploads/' . $image));
            }
            Product::onlyTrashed()->find($id)->forceDelete();
            $status = 'Đã xoá vĩnh viễn sản phẩm';
        } else {
            Product::withoutTrashed()->find($id)->delete();
        }
        $status = 'đã chuyển sản phẩm vào thùng rác';
        return redirect()->route('admin.product.index')->with('status', $status);
    }

    public function action(Request $request)
    {
        if (!Gate::allows('admin.product.edit')) {
            abort(403);
        }
        $request->validate(
            [
                'action' => 'not_in:0',
                'id' => 'required'
            ],
            [
                'required' => 'vui lòng chọn sản phẩm bạn muốn thực hiện',
                'not_in' => 'vui lòng chọn thao tác bạn muốn thực hiện'
            ],
        );
        $action = $request->action;
        $id = $request->id;
        if ($action === 'active') {
            Product::withTrashed()->whereIn('id', $id)->update(['status' => '1']);
            $status = 'đã cập nhật trạng thái còn hàng';
        }
        if ($action === 'hide') {
            Product::withTrashed()->whereIn('id', $id)->update(['status' => '0']);
            $status = 'đã cập nhật trạng thái chờ duyệt';
        }
        if ($action === 'sold') {
            Product::withTrashed()->whereIn('id', $id)->update(['status' => '2']);
            $status = 'đã cập nhật trạng thái hết hàng';
        }
        if ($action === 'restore') {
            Product::onlyTrashed()->whereIn('id', $id)->restore();
            $status = 'đưa sản phẩm trở lại';
        }
        if ($action === 'delete') {
            if (!Gate::allows('admin.product.destroy')) {
                abort(403);
            }
            Product::withoutTrashed()->whereIn('id', $id)->delete();
            $status = 'đã chuyển sản phẩm vào thùng rác';
        }
        if ($action === 'forceDelete') {
            if (!Gate::allows('admin.product.destroy')) {
                abort(403);
            }
            foreach ($id as $i) {
                $product =  Product::onlyTrashed()->find($i);
                if (file_exists('uploads/' . $product->thumb)) unlink(public_path('uploads/' . $product->thumb));
                $images_detail = json_decode($product->images_detail, true);
                foreach ($images_detail as $image) {
                    if (file_exists(public_path('uploads/' . $image))) unlink(public_path('uploads/' . $image));
                }
            }
            Product::onlyTrashed()->whereIn('id', $id)->forceDelete();
            $status = 'đã xoá vĩnh viễn sản phẩm';
        }
        return redirect()->route('admin.product.index')->with('status', $status);
    }
    public function restore($id)
    {
        if (!Product::onlyTrashed()->find($id)) return abort(404);
        Product::onlyTrashed()->find($id)->restore();
        return redirect()->route('admin.product.index')->with('status', 'đã đưa sản phẩm trở lại');
    }
}
