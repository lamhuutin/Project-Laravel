<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Page;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;

class AdminPageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            session(['module' => 'page']);
            return $next($request);
        });
    }
    public function index(Request $request)
    {
        if (!Gate::allows('admin.page.index')) {
            abort(403);
        }
        $status = $request->status;
        $keyword = $request->keyword;
        $count = [Page::all()->count(), Page::onlyTrashed()->count()];
        if ($status === 'trash') {
            $data = Page::onlyTrashed()->where('title', 'like', "%{$keyword}%")->paginate(20);
        } else {
            $data = Page::where('title', 'like', "%{$keyword}%")->paginate(20);
        }
        return view('admin.page.index', compact('data', 'count'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!Gate::allows('admin.page.create')) {
            abort(403);
        }
        return view('admin.page.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (!Gate::allows('admin.page.create')) {
            abort(403);
        }
        $request->validate(
            [
                'title' => 'required|max:255',
                'file_thumb' => 'required|image|mimes:png,jpg,jpeg,gif|max:2048',
                'content' => 'required'
            ],
            [
                'required' => ':attribute không được để trống',
                'image' => ':attribute không phải file ảnh',
                'mimes' => ':attribute phải có đuôi png, jpg, jpeg, gif',
                'max' => ':attribute có tối đa :max ký tự'
            ],
            [
                'title' => 'Tiêu đề trang',
                'file_thumb' => 'file tải lên',
                'content' => 'nội dung trang'
            ]
        );
        $file_thumb = $request->file('file_thumb');
        $file_extension = $file_thumb->extension();
        $thumb_name = time() . '-' . 'page.' . $file_extension;
        $request->merge(['thumb' => $thumb_name, 'user_id' => Auth::id()]);
        $file_thumb->move(public_path('uploads'), $thumb_name);
        Page::create($request->all());
        return redirect()->back()->with('status', 'bạn vừa tạo trang thành công');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (!Gate::allows('admin.page.edit')) {
            abort(403);
        }
        $data = Page::join('users', 'users.id', '=', 'pages.user_id')->where('pages.id', $id)->select('pages.*', 'users.name')->first();
        if (!$data) return abort(404);
        // route('admin.page.index')->with('fail', 'không tìm thấy bài viết nào có ID phù hợp');
        return view('admin.page.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (!Gate::allows('admin.page.edit')) {
            abort(403);
        }
        $request->validate(
            [
                'title' => 'required|max:255',
                'file_thumb' => 'image|mimes:png,jpg,jpeg,gif|max:2048',
                'content' => 'required'
            ],
            [
                'required' => ':attribute không được để trống',
                'image' => ':attribute không phải file ảnh',
                'mimes' => ':attribute phải có đuôi png, jpg, jpeg, gif',
                'max' => ':attribute có tối đa :max ký tự'
            ],
            [
                'title' => 'Tiêu đề trang',
                'file_thumb' => 'file tải lên',
                'content' => 'nội dung trang'
            ]
        );
        $file_thumb = $request->file_thumb;
        if ($file_thumb) {
            $old_thumb = Page::find($id)->thumb;
            $path = public_path('uploads/' . $old_thumb);
            if (file_exists($path)) unlink($path);
            $file_extension = $file_thumb->extension();
            $thumb_name = time() . '-' . 'page.' . $file_extension;
            $file_thumb->move(public_path('uploads'), $thumb_name);
            $request->merge(['thumb' => $thumb_name]);
        }
        Page::find($id)->update($request->all());
        return redirect()->route('admin.page.index')->with('status', 'đã chỉnh sửa bài viết thành công');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        if (!Gate::allows('admin.page.destroy')) {
            abort(403);
        }
        $forceDelete = $request->forceDelete;
        if ($forceDelete === 'ok') {
            Page::onlyTrashed()->find($id)->forceDelete();
            return redirect()->route('admin.page.index')->with('status', 'Đã xoá vĩnh viễn bài viết');
        }
        Page::withoutTrashed()->find($id)->delete();
        return redirect()->route('admin.page.index')->with('status', 'đã chuyển bài viết vào thùng rác');
    }

    public function action(Request $request)
    {
        if (!Gate::allows('admin.page.edit')) {
            abort(403);
        }
        $request->validate(
            [
                'action' => 'not_in:0',
                'id' => 'required'
            ],
            [
                'required' => 'vui lòng chọn bài viết bạn muốn thực hiện',
                'not_in' => 'vui lòng chọn thao tác bạn muốn thực hiện'
            ],
        );
        $action = $request->action;
        $id = $request->id;
        if ($action === 'active') {
            Page::whereIn('id', $id)->update(['status' => '1']);
            $status = 'cập nhật trạng thái hiển thị';
        }
        if ($action === 'hide') {
            Page::whereIn('id', $id)->update(['status' => '0']);
            $status = 'cập nhật trạng thái chờ duyệt';
        }
        if ($action === 'delete') {
            if (!Gate::allows('admin.page.destroy')) {
                abort(403);
            }
            Page::withoutTrashed()->whereIn('id', $id)->delete();
            $status = 'Đã chuyển bài viết vào thùng rác';
        }
        if ($action === 'restore') {
            Page::onlyTrashed()->whereIn('id', $id)->restore();
            $status = 'Đã đưa bài viết trở lại';
        }
        if ($action === 'forceDelete') {
            if (!Gate::allows('admin.page.destroy')) {
                abort(403);
            }
            Page::onlyTrashed()->whereIn('id', $id)->forceDelete();
            $status = 'Đã xoá vĩnh viễn viết';
        }
        return redirect()->route('admin.page.index')->with('status', $status);
    }
    public function restore($id)
    {
        $data = Page::onlyTrashed()->find($id);
        if (!$data) return abort(404);
        $data->restore();
        return redirect()->route('admin.page.index')->with('status', 'Đã đưa bài viết trở lại');
    }
}
