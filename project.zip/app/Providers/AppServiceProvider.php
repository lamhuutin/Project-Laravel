<?php

namespace App\Providers;

use App\Models\Product;
use App\Models\ProductCat;
use Illuminate\Support\ServiceProvider;
use Illuminate\Pagination\Paginator;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\View;
use Gloudemans\Shoppingcart\Facades\Cart;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Paginator::useBootstrap();
        $productCats = ProductCat::all();
        $menu = render_menu($productCats);
        $hotProducts = Product::join('product_cats', 'product_cats.id', '=', 'products.productCat_id')->whereNotIn('products.status', ['0'])->select('products.id', 'products.name', 'products.price', 'products.discount', 'products.thumb', 'products.status', 'product_cats.name as cat_name')->orderby('id','desc')->limit(10)->get();
        // View::share('hotProducts',$hotProducts);
        // View::share('menu',$menu);
        View::share(['menu'=>$menu,'hotProducts'=>$hotProducts]);
    }
}
