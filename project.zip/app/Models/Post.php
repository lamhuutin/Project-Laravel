<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\PostCat;
use App\Models\User;
class Post extends Model
{
    use HasFactory, SoftDeletes;
    protected $fillable = ['user_id','postCat_id','title','thumb','desc','content','status'];
    public function postCat(){
        return $this -> belongsTo(PostCat::class,'postCat_id','id'); 
    }
    public function user(){
        return $this -> belongsTo(User::class,'user_id','id');
    }
}
