<?php
function data_tree($data, $parent_id = 0, $level = 0)
{
    // if (!is_array($data)) return false;
    $result = [];
    foreach ($data as $model) {
        if ($model->parent_id == $parent_id) {
            $model->level = $level;
            $result[] = $model;
            if (has_child($data, $model->id)) {
                $child = data_tree($data, $model->id, $level + 1);
                $result = array_merge($result, $child);
            }
        }
    }
    return $result;
}

function has_child($data, $parent_id)
{
    foreach ($data as $model) {
        if ($model->parent_id == $parent_id) return true;
    }
    return false;
}

function get_list_cat_id($data, $parent_id, $child = 0)
{
    if($child === 0) $result = [(int)$parent_id];
    else $result = [];
    foreach ($data as $model) {
        if ($model->parent_id == $parent_id) {
            $result[] = $model->id;
            if (has_child($data, $model->id)) {
                $child = get_list_cat_id($data, $model->id, $child+1);
                $result = array_merge($result, $child);
            }
        }
    }
    return $result;
}

function create_slug($string)
{
    $search = array(
        '#(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)#',
        '#(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)#',
        '#(ì|í|ị|ỉ|ĩ)#',
        '#(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)#',
        '#(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)#',
        '#(ỳ|ý|ỵ|ỷ|ỹ)#',
        '#(đ)#',
        '#(À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ)#',
        '#(È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ)#',
        '#(Ì|Í|Ị|Ỉ|Ĩ)#',
        '#(Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ)#',
        '#(Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ)#',
        '#(Ỳ|Ý|Ỵ|Ỷ|Ỹ)#',
        '#(Đ)#',
        "/[^a-zA-Z0-9\-\_]/",
    );
    $replace = array(
        'a',
        'e',
        'i',
        'o',
        'u',
        'y',
        'd',
        'A',
        'E',
        'I',
        'O',
        'U',
        'Y',
        'D',
        '-',
    );
    $string = preg_replace($search, $replace, $string);
    $string = preg_replace('/(-)+/', '-', $string);
    $string = strtolower($string);
    return $string;
}

function render_menu($data = null, $parent_id = 0, $level = 0)
{
    if ($level == 0) $result = "<ul class='list-item'>";
    else  $result = "<ul class='sub-menu'>";
    foreach ($data as $model) {
        if ($model->parent_id == $parent_id) {
            // $model->level = $level;
            $url = url('/danh-muc-san-pham-' . create_slug($model->name) . '-' . $model->id . '.html');
            $result .= "<li> <a href='{$url}' title>{$model->name}</a>";
            if (has_child($data, $model->id)) {
                $child = render_menu($data, $model->id, $level + 1);
                $result .= $child;
            }
            $result .= "</li>";
        }
    }
    $result .= "</ul>";
    return $result;
}
